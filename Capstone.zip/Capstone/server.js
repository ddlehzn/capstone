require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const XLSX = require('xlsx');
const InventoryMonitor = require('./services/InventoryMonitor');

const app = express();
const port = process.env.PORT || 3000;

// CORS configuration - Allow all origins for development
const corsOptions = {
  origin: true, // Allow all origins for development
  credentials: true, // needed for cookies
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // Handle preflight

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Static files for uploads
// Serve static files
app.use(express.static(__dirname));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// MySQL connection - Using environment variables
const db = mysql.createConnection({
  host: process.env.DB_HOST || 'yamabiko.proxy.rlwy.net',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'QoccRevvUaMJIwMZxuqmPRNLTWkbmKOy',
  database: process.env.DB_NAME || 'railway',
  port: parseInt(process.env.DB_PORT) || 25331,
  connectTimeout: 60000, // 60 seconds timeout
  ssl: false
});

db.connect(err => {
  if (err) {
    console.error('MySQL connection error:', err);
    process.exit(1);
  }
  console.log('Connected to MySQL');
  
  // Create monthly_sales table if it doesn't exist
  createMonthlySalesTable().catch(console.error);
});

// Function to create monthly_sales table
async function createMonthlySalesTable() {
  try {
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS monthly_sales (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sales_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
        expenses_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
        profit_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
        created_at DATE NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_month_year (created_at)
      )
    `;
    
    await new Promise((resolve, reject) => {
      db.execute(createTableSQL, (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    });
    
    console.log('Monthly sales table ready');
  } catch (error) {
    console.error('Error creating monthly_sales table:', error);
  }
}

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  }
});

const upload = multer({ storage: storage });

// Authentication middleware
const authenticateToken = (req, res, next) => {
  // Try cookie first, then Authorization header
  let token = req.cookies.authToken;
  
  if (!token) {
    const authHeader = req.headers['authorization'];
    token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN
  }
  
  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ error: 'Invalid token.' });
  }
};

// ===== AUTHENTICATION ROUTES =====

// Login endpoint
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  // Validate email format (must contain @ symbol)
  if (!username.includes('@')) {
    return res.status(400).json({ error: 'Please enter a valid email address as your username' });
  }

  try {
    db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }

      if (results.length === 0) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const user = results[0];
      const isValidPassword = await bcrypt.compare(password, user.password_hash);

      if (!isValidPassword) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign(
        { 
          id: user.id, 
          username: user.username, 
          role: user.role 
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN }
      );

      res.cookie('authToken', token, {
        httpOnly: true,
        secure: false, // false for localhost development
        sameSite: 'lax', // more permissive for development
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });

      res.json({
        message: 'Login successful',
        user: {
          id: user.id,
          username: user.username,
          role: user.role
        },
        token: process.env.NODE_ENV === 'development' ? token : undefined // Include token in development
      });
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get current user endpoint
app.get('/api/auth/me', authenticateToken, (req, res) => {
  res.json({
    user: {
      id: req.user.id,
      username: req.user.username,
      role: req.user.role
    }
  });
});

// Logout endpoint
app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('authToken');
  res.json({ message: 'Logout successful' });
});

// ===== CHAT ROUTES =====

// Get chat sessions (history)
app.get('/api/chat/sessions', authenticateToken, (req, res) => {
  const { id: user_id } = req.user;
  
  db.query(
    'SELECT id, title, created_at, updated_at FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC',
    [user_id],
    (err, results) => {
      if (err) {
        console.error('Error fetching chat sessions:', err);
        return res.status(500).json({ error: 'Failed to fetch chat sessions' });
      }
      res.json({ sessions: results });
    }
  );
});

// Create new chat session
app.post('/api/chat/sessions', authenticateToken, (req, res) => {
  const { id: user_id } = req.user;
  const { title = 'New Chat' } = req.body;
  
  db.query(
    'INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)',
    [user_id, title],
    (err, result) => {
      if (err) {
        console.error('Error creating chat session:', err);
        return res.status(500).json({ error: 'Failed to create chat session' });
      }
      
      const newSession = {
        id: result.insertId,
        title,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      res.status(201).json({ message: 'Session created successfully', session: newSession });
    }
  );
});

// Get messages for a specific session
app.get('/api/chat/sessions/:sessionId/messages', authenticateToken, (req, res) => {
  const { sessionId } = req.params;
  const { id: user_id } = req.user;
  const { limit = 50, offset = 0 } = req.query;
  
  // First verify the session belongs to the user
  db.query(
    'SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?',
    [sessionId, user_id],
    (err, sessionResults) => {
      if (err) {
        console.error('Error verifying session:', err);
        return res.status(500).json({ error: 'Failed to verify session' });
      }
      
      if (sessionResults.length === 0) {
        return res.status(404).json({ error: 'Session not found or access denied' });
      }
      
      // Get messages for this session
      db.query(
        'SELECT id, user_id, username, message, message_type, timestamp FROM chat_messages WHERE session_id = ? ORDER BY timestamp ASC LIMIT ? OFFSET ?',
        [sessionId, parseInt(limit), parseInt(offset)],
        (err, results) => {
          if (err) {
            console.error('Error fetching session messages:', err);
            return res.status(500).json({ error: 'Failed to fetch messages' });
          }
          
          res.json({ messages: results });
        }
      );
    }
  );
});

// Get chat messages (backward compatibility - gets latest session)
app.get('/api/chat/messages', authenticateToken, (req, res) => {
  const { id: user_id } = req.user;
  
  // Get the most recent session for this user
  db.query(
    'SELECT id FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1',
    [user_id],
    (err, sessionResults) => {
      if (err) {
        console.error('Error finding latest session:', err);
        return res.status(500).json({ error: 'Failed to find session' });
      }
      
      if (sessionResults.length === 0) {
        return res.json({ messages: [] });
      }
      
      const sessionId = sessionResults[0].id;
      const { limit = 50, offset = 0 } = req.query;
      
      db.query(
        'SELECT id, user_id, username, message, message_type, timestamp FROM chat_messages WHERE session_id = ? ORDER BY timestamp ASC LIMIT ? OFFSET ?',
        [sessionId, parseInt(limit), parseInt(offset)],
        (err, results) => {
          if (err) {
            console.error('Error fetching chat messages:', err);
            return res.status(500).json({ error: 'Failed to fetch messages' });
          }
          
          res.json({ messages: results, sessionId });
        }
      );
    }
  );
});

// Send a new chat message
app.post('/api/chat/messages', authenticateToken, (req, res) => {
  const { message, message_type = 'user', session_id } = req.body;
  
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message content is required' });
  }
  
  if (!session_id) {
    return res.status(400).json({ error: 'Session ID is required' });
  }
  
  const { id: user_id, username } = req.user;
  
  // First verify the session belongs to the user
  db.query(
    'SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?',
    [session_id, user_id],
    (err, sessionResults) => {
      if (err) {
        console.error('Error verifying session:', err);
        return res.status(500).json({ error: 'Failed to verify session' });
      }
      
      if (sessionResults.length === 0) {
        return res.status(400).json({ error: 'Invalid session or access denied' });
      }
      
      // Save the message
      db.query(
        'INSERT INTO chat_messages (user_id, username, message, message_type, session_id) VALUES (?, ?, ?, ?, ?)',
        [user_id, username, message.trim(), message_type, session_id],
        (err, result) => {
          if (err) {
            console.error('Error saving chat message:', err);
            return res.status(500).json({ error: 'Failed to save message' });
          }
          
          // Update session timestamp
          db.query(
            'UPDATE chat_sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [session_id],
            (updateErr) => {
              if (updateErr) {
                console.error('Error updating session timestamp:', updateErr);
              }
            }
          );
          
          const newMessage = {
            id: result.insertId,
            user_id,
            username,
            message: message.trim(),
            message_type,
            session_id,
            timestamp: new Date().toISOString()
          };
          
          res.status(201).json({ message: 'Message sent successfully', data: newMessage });
        }
      );
    }
  );
});

// Update chat session (rename)
app.put('/api/chat/sessions/:sessionId', authenticateToken, (req, res) => {
  const { sessionId } = req.params;
  const { title } = req.body;
  const { id: user_id } = req.user;
  
  if (!title || !title.trim()) {
    return res.status(400).json({ error: 'Session title is required' });
  }
  
  // Verify the session belongs to the user and update it
  db.query(
    'UPDATE chat_sessions SET title = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?',
    [title.trim(), sessionId, user_id],
    (err, result) => {
      if (err) {
        console.error('Error updating session:', err);
        return res.status(500).json({ error: 'Failed to update session' });
      }
      
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Session not found or access denied' });
      }
      
      res.json({ message: 'Session updated successfully' });
    }
  );
});

// Bulk delete chat sessions
app.delete('/api/chat/sessions/bulk', authenticateToken, (req, res) => {
  const { sessionIds } = req.body;
  const { id: user_id } = req.user;
  
  console.log('Bulk delete request received:', { sessionIds, user_id });
  
  if (!sessionIds || !Array.isArray(sessionIds) || sessionIds.length === 0) {
    console.log('Invalid session IDs provided:', sessionIds);
    return res.status(400).json({ error: 'Session IDs are required' });
  }
  
  // First verify all sessions belong to the user
  const placeholders = sessionIds.map(() => '?').join(',');
  db.query(
    `SELECT id FROM chat_sessions WHERE id IN (${placeholders}) AND user_id = ?`,
    [...sessionIds, user_id],
    (err, sessionResults) => {
      if (err) {
        console.error('Error verifying sessions:', err);
        return res.status(500).json({ error: 'Failed to verify sessions' });
      }
      
      console.log('Session verification results:', { 
        requested: sessionIds.length, 
        found: sessionResults.length,
        sessionIds: sessionIds,
        foundIds: sessionResults.map(r => r.id)
      });
      
      if (sessionResults.length !== sessionIds.length) {
        console.log('Session count mismatch - some sessions not found or access denied');
        return res.status(403).json({ error: 'Some sessions not found or access denied' });
      }
      
      // Delete messages first (due to foreign key constraint)
      db.query(
        `DELETE FROM chat_messages WHERE session_id IN (${placeholders})`,
        sessionIds,
        (err) => {
          if (err) {
            console.error('Error deleting messages:', err);
            return res.status(500).json({ error: 'Failed to delete session messages' });
          }
          
          console.log('Messages deleted successfully, now deleting sessions...');
          
          // Now delete the sessions
          db.query(
            `DELETE FROM chat_sessions WHERE id IN (${placeholders}) AND user_id = ?`,
            [...sessionIds, user_id],
            (err, result) => {
              if (err) {
                console.error('Error deleting sessions:', err);
                return res.status(500).json({ error: 'Failed to delete sessions' });
              }
              
              console.log('Bulk delete completed successfully:', { 
                affectedRows: result.affectedRows,
                sessionIds: sessionIds 
              });
              
              res.json({ 
                message: `${result.affectedRows} session(s) deleted successfully`,
                deletedCount: result.affectedRows
              });
            }
          );
        }
      );
    }
  );
});

// Delete chat session
app.delete('/api/chat/sessions/:sessionId', authenticateToken, (req, res) => {
  const { sessionId } = req.params;
  const { id: user_id } = req.user;
  
  // First verify the session belongs to the user
  db.query(
    'SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?',
    [sessionId, user_id],
    (err, sessionResults) => {
      if (err) {
        console.error('Error verifying session:', err);
        return res.status(500).json({ error: 'Failed to verify session' });
      }
      
      if (sessionResults.length === 0) {
        return res.status(404).json({ error: 'Session not found or access denied' });
      }
      
      // Delete messages first (due to foreign key constraint)
      db.query(
        'DELETE FROM chat_messages WHERE session_id = ?',
        [sessionId],
        (err) => {
          if (err) {
            console.error('Error deleting messages:', err);
            return res.status(500).json({ error: 'Failed to delete session messages' });
          }
          
          // Now delete the session
          db.query(
            'DELETE FROM chat_sessions WHERE id = ? AND user_id = ?',
            [sessionId, user_id],
            (err, result) => {
              if (err) {
                console.error('Error deleting session:', err);
                return res.status(500).json({ error: 'Failed to delete session' });
              }
              
              res.json({ message: 'Session deleted successfully' });
            }
          );
        }
      );
    }
  );
});

// ===== PRODUCT ROUTES =====

// Get all products
app.get('/api/products', authenticateToken, (req, res) => {
  console.log('=== PRODUCTS API CALLED ===');
  console.log('User ID:', req.user ? req.user.id : 'No user');
  console.log('User role:', req.user ? req.user.role : 'No role');
  console.log('Fetching products from database...');
  db.query('SELECT * FROM products ORDER BY quantity DESC', (err, results) => {
    if (err) {
      console.error('Error fetching products:', err);
      return res.status(500).json({ error: err.message });
    }
    console.log('Products fetched successfully:', results.length, 'products');
    console.log('Sample products:', results.slice(0, 3));
    res.json(results);
  });
});

// Debug endpoint to check products without auth (temporary)
app.get('/api/products-debug', (req, res) => {
  console.log('=== DEBUG: Fetching products without auth ===');
  db.query('SELECT * FROM products ORDER BY quantity DESC', (err, results) => {
    if (err) {
      console.error('Debug: Error fetching products:', err);
      return res.status(500).json({ error: err.message });
    }
    console.log('Debug: Products fetched successfully:', results.length, 'products');
    res.json({ count: results.length, products: results });
  });
});

// Add product endpoint
app.post('/api/products', (req, res) => {
  const { name, quantity, price } = req.body;
  
  if (!name || !quantity || !price) {
    return res.status(400).json({ error: 'Missing product information.' });
  }
  
  db.query(
    'INSERT INTO products (name, quantity, price) VALUES (?, ?, ?)',
    [name, quantity, price],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      
      const productId = result.insertId;
      const qty = parseInt(quantity);
      
      // Automatically create reorder threshold for the new product
      // Set smart defaults based on initial quantity
      let minimumStock, reorderQuantity;
      
      if (qty === 0) {
        minimumStock = 10;
        reorderQuantity = 50;
      } else if (qty < 50) {
        minimumStock = 20;
        reorderQuantity = 100;
      } else {
        minimumStock = Math.max(10, Math.floor(qty * 0.2));
        reorderQuantity = Math.max(50, Math.floor(qty * 0.5));
      }
      
      // Insert reorder threshold
      db.query(
        'INSERT INTO reorder_thresholds (product_id, minimum_stock, reorder_quantity, auto_reorder_enabled) VALUES (?, ?, ?, TRUE)',
        [productId, minimumStock, reorderQuantity],
        (thresholdErr) => {
          if (thresholdErr) {
            console.error('Error creating reorder threshold:', thresholdErr);
            // Don't fail the product creation if threshold fails
          } else {
            console.log(`✅ Auto-created reorder threshold for product ${name} (ID: ${productId})`);
            console.log(`   Minimum Stock: ${minimumStock}, Reorder Quantity: ${reorderQuantity}`);
          }
        }
      );
      
      res.json({ 
        id: productId, 
        name, 
        quantity: qty, 
        price: parseFloat(price)
      });
    }
  );
});

// Update a product
app.put('/api/products/:id', authenticateToken, (req, res) => {
  const { name, quantity, price } = req.body;
  const { id } = req.params;
  
  console.log('Updating product with ID:', id, 'Data:', { name, quantity, price });
  
  db.query(
    'UPDATE products SET name=?, quantity=?, price=? WHERE id=?',
    [name, quantity, price, id],
    (err, result) => {
      if (err) {
        console.error('Error updating product:', err);
        return res.status(500).json({ error: err.message });
      }
      console.log('Product updated successfully');
      res.json({ success: true });
    }
  );
});

// Delete product
app.delete('/api/products/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  console.log('Deleting product with ID:', id);
  db.query('DELETE FROM products WHERE id=?', [id], (err, result) => {
    if (err) {
      console.error('Error deleting product:', err);
      return res.status(500).json({ error: err.message });
    }
    console.log('Product deleted successfully');
    res.json({ success: true });
  });
});

// ===== SUPPLIER ROUTES =====

// Get available suppliers for a product
app.get('/api/suppliers/available', authenticateToken, (req, res) => {
  const { product } = req.query;
  
  if (!product) {
    return res.status(400).json({ error: 'Product parameter is required' });
  }
  
  // Get suppliers that have this product in their catalog or all suppliers as fallback
  const query = `
    SELECT DISTINCT s.id, s.name, s.email, s.phone, s.priority, s.contact_person
    FROM suppliers s
    LEFT JOIN supplier_products sp ON s.id = sp.supplier_id
    WHERE (sp.product_name LIKE ? OR sp.product_name IS NULL) 
      AND s.is_active = TRUE
    ORDER BY s.priority ASC, s.name ASC
  `;
  
  db.query(query, [`%${product}%`], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ suppliers: results });
  });
});

// Get all suppliers
app.get('/api/suppliers', authenticateToken, (req, res) => {
  db.query('SELECT * FROM suppliers WHERE is_active = TRUE ORDER BY priority ASC, name ASC', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ suppliers: results });
  });
});

// ===== NOTIFICATION ROUTES =====

// Send SMS notification
app.post('/api/notifications/sms', authenticateToken, async (req, res) => {
  const { phoneNumber, message, type } = req.body;
  
  if (!phoneNumber || !message) {
    return res.status(400).json({ error: 'Phone number and message are required' });
  }
  
  try {
    // Import NotificationService dynamically to avoid circular dependencies
    const NotificationService = require('./services/NotificationService');
    const notificationService = new NotificationService();
    
    // Wait for initialization
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const result = await notificationService.sendSMSNotification(phoneNumber, message);
    
    if (result.success) {
      res.json({ 
        success: true, 
        messageId: result.sid,
        message: 'SMS sent successfully' 
      });
    } else {
      res.status(500).json({ 
        success: false, 
        error: result.error || 'Failed to send SMS' 
      });
    }
  } catch (error) {
    console.error('Error sending SMS:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Send Email notification
app.post('/api/notifications/email', authenticateToken, async (req, res) => {
  const { to, subject, message, isHTML = false, type } = req.body;
  
  if (!to || !subject || !message) {
    return res.status(400).json({ error: 'To, subject, and message are required' });
  }
  
  try {
    // Import NotificationService dynamically to avoid circular dependencies
    const NotificationService = require('./services/NotificationService');
    const notificationService = new NotificationService();
    
    // Wait for initialization
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const result = await notificationService.sendEmailNotification(to, subject, message, null, isHTML);
    
    if (result.success) {
      res.json({ 
        success: true, 
        messageId: result.messageId,
        message: 'Email sent successfully' 
      });
    } else {
      res.status(500).json({ 
        success: false, 
        error: result.error || 'Failed to send email' 
      });
    }
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// ===== USER PROFILE ROUTES =====

// Get user profile
app.get('/api/user/profile', authenticateToken, (req, res) => {
  const userId = req.user.id;
  
  db.query(
    'SELECT id, username, email, phone, first_name, last_name FROM users WHERE id = ?',
    [userId],
    (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      if (results.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
      res.json({ user: results[0] });
    }
  );
});

// Serve index.html for the root path
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
app.listen(port, async () => {
  console.log(`Server running at http://localhost:${port}`);
  
  // Create data table metadata table if it doesn't exist
  const createMetadataTable = `
    CREATE TABLE IF NOT EXISTS data_table_metadata (
      id INT AUTO_INCREMENT PRIMARY KEY,
      table_name VARCHAR(255) NOT NULL,
      file_name VARCHAR(255) NOT NULL,
      row_count INT NOT NULL,
      column_count INT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `;
  
  db.query(createMetadataTable, (err) => {
    if (err) {
      console.error('Error creating data_table_metadata table:', err);
    } else {
      console.log('Data table metadata table ready');
    }
  });
  
  // Clean up old daily tables on server start
  console.log('Cleaning up old daily tables...');
  await cleanupAllOldDailyTables();
  
  // Start Inventory Monitoring System
  console.log('\n🚀 Starting Inventory Monitoring System...');
  try {
    const inventoryMonitor = new InventoryMonitor();
    // Wait for initialization
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Start monitoring with periodic checks every 0.5 minutes (30 seconds)
    inventoryMonitor.startMonitoring(0.5);
    console.log('✅ Inventory monitoring started successfully');
    console.log('📧 Email notifications will be sent to:', process.env.EMAIL_USER);
    console.log('🔄 Checking inventory every 30 seconds\n');
  } catch (error) {
    console.error('❌ Failed to start inventory monitoring:', error);
  }
});

// ===== SALES API (Dash + Sales Management) =====

// Get monthly sales from database
app.get('/api/sales/monthly', authenticateToken, async (req, res) => {
  try {
    // First, find the most recent monthly data table
    const tablesQuery = `
      SELECT TABLE_NAME, CREATE_TIME
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME LIKE 'monthly_data_%'
      ORDER BY CREATE_TIME DESC 
      LIMIT 1
    `;
    
    db.query(tablesQuery, async (err, tables) => {
      if (err) {
        console.error('Error finding monthly tables:', err);
        return res.status(500).json({ error: 'Failed to find monthly data tables' });
      }
      
      if (tables.length === 0) {
        // No monthly data tables found, try the old monthly_sales table
        db.query(`
          SELECT 
            MONTH(created_at) as month,
            SUM(sales_amount) as sales,
            SUM(expenses_amount) as expenses,
            SUM(profit_amount) as profit
          FROM monthly_sales 
          WHERE YEAR(created_at) = 2025
          GROUP BY MONTH(created_at)
          ORDER BY MONTH(created_at)
        `, (err, rows) => {
          if (err) {
            console.error('Error fetching monthly sales:', err);
            return res.status(500).json({ error: 'Failed to fetch monthly sales' });
          }
          
          console.log('Monthly sales query result (old table):', rows);
          
          const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
          const sales = new Array(12).fill(0);
          
          if (rows && Array.isArray(rows)) {
            rows.forEach(row => {
              const monthIndex = row.month - 1; // Convert 1-12 to 0-11
              sales[monthIndex] = row.sales || 0;
            });
          }
          
          const response = {
            labels: labels,
            data: sales
          };
          
          console.log('Monthly sales API response (old table):', response);
          res.json(response);
        });
        return;
      }
      
      // Get data from the most recent monthly table
      const tableName = tables[0].TABLE_NAME;
      const createTime = tables[0].CREATE_TIME;
      console.log('Selected monthly table:', tableName, 'created at:', createTime);
      const dataQuery = `SELECT month, sales FROM \`${tableName}\` ORDER BY monthNum LIMIT 12`;
      
      db.query(dataQuery, (err, results) => {
        if (err) {
          console.error('Error fetching monthly data:', err);
          return res.status(500).json({ error: 'Failed to fetch monthly data' });
        }
        
        console.log('Raw database results:', results);
        
        if (results.length === 0) {
          // No data in table, return empty data
          const response = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            data: new Array(12).fill(0)
          };
          return res.json(response);
        }
        
        // Use the same simple pattern as weekly API
        const response = {
          labels: results.map(row => row.month),
          data: results.map(row => parseFloat(row.sales))
        };
        
        console.log('Monthly API response (dynamic table):', response);
        res.json(response);
      });
    });
  } catch (error) {
    console.error('Error fetching monthly sales:', error);
    res.status(500).json({ error: 'Failed to fetch monthly sales data' });
  }
});

// Get daily sales data
app.get('/api/sales/daily', authenticateToken, async (req, res) => {
  try {
    console.log('Fetching daily sales data from uploaded_data table (same source as uploaded data table)...');
    
    // Check if uploaded_data table exists
    const tableExistsQuery = `
      SELECT COUNT(*) as count
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME = 'uploaded_data'
    `;
    
    const tableExists = await new Promise((resolve, reject) => {
      db.query(tableExistsQuery, (error, results) => {
        if (error) reject(error);
        else resolve(results[0].count > 0);
      });
    });
    
    if (!tableExists) {
      console.log('uploaded_data table does not exist, returning empty data');
      const emptyData = {
        labels: [],
        data: []
      };
      return res.json(emptyData);
    }
    
    // Fetch data from uploaded_data table (same as uploaded data table)
    const dataQuery = `
      SELECT column1 as date_time, column2 as sales
      FROM uploaded_data
      WHERE column1 IS NOT NULL AND column2 IS NOT NULL
      AND column1 != 'Date' AND column2 != 'Sales'
      ORDER BY CAST(column1 AS UNSIGNED) ASC
      LIMIT 100
    `;
    
    const dataResult = await new Promise((resolve, reject) => {
      db.query(dataQuery, (error, results) => {
        if (error) reject(error);
        else resolve(results);
      });
    });
    
    console.log('Raw daily data from uploaded_data table:', dataResult);
    
    if (dataResult.length === 0) {
      console.log('No daily data found in uploaded_data table, returning empty data');
      const emptyData = {
        labels: [],
        data: []
      };
      return res.json(emptyData);
    }
    
    // Convert to chart format - handle both Excel serial numbers and date strings
    const labels = [];
    const data = [];
    
    dataResult.forEach(row => {
      let date;
      let salesValue;
      
      // Handle Excel serial numbers (numbers > 25569)
      if (!isNaN(row.date_time) && parseFloat(row.date_time) > 25569) {
        const excelDate = new Date((parseFloat(row.date_time) - 25569) * 86400 * 1000);
        date = excelDate;
      } else {
        // Handle regular date strings
        date = new Date(row.date_time);
      }
      
      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.log(`Invalid date: ${row.date_time}`);
        return; // Skip this row
      }
      
      // Parse sales value
      salesValue = parseFloat(row.sales);
      if (isNaN(salesValue)) {
        console.log(`Invalid sales value: ${row.sales}`);
        return; // Skip this row
      }
      
      labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
      data.push(salesValue);
    });
    
    const response = {
      labels: labels,
      data: data
    };
    
    console.log('Daily API response from uploaded_data table:', response);
    res.json(response);
    
  } catch (error) {
    console.error('Error fetching daily sales:', error);
    res.status(500).json({ error: 'Failed to fetch daily sales data' });
  }
});

// Get sales by product
app.get('/api/sales/by-product', authenticateToken, async (req, res) => {
  try {
    // First, try to find the most recent product data table
    const tablesQuery = `
      SELECT TABLE_NAME, CREATE_TIME
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME LIKE 'product_data_%'
      ORDER BY CREATE_TIME DESC 
      LIMIT 1
    `;
    
    db.query(tablesQuery, async (err, tables) => {
      if (err) {
        console.error('Error finding product tables:', err);
        return res.status(500).json({ error: 'Failed to find product data tables' });
      }
      
      if (tables.length > 0) {
        // Get data from the most recent product table
        const tableName = tables[0].TABLE_NAME;
        const createTime = tables[0].CREATE_TIME;
        console.log('Selected product table:', tableName, 'created at:', createTime);
        
        const dataQuery = `SELECT Product, Sales FROM \`${tableName}\` ORDER BY Sales DESC LIMIT 20`;
        
        db.query(dataQuery, (err, rows) => {
          if (err) {
            console.error('Error fetching product data:', err);
            return res.status(500).json({ error: 'Failed to fetch product data' });
          }
          
          console.log('Product API response:', {
            labels: rows.map(r => r.Product),
            data: rows.map(r => Number(r.Sales))
          });
          
          res.json({ 
            labels: rows.map(r => r.Product), 
            data: rows.map(r => Number(r.Sales)) 
          });
        });
      } else {
        // No product data tables found, return empty data
        console.log('No product data tables found, returning empty data');
        const emptyData = {
          labels: [],
          data: []
        };
        return res.json(emptyData);
      }
    });
  } catch (error) {
    console.error('Error fetching sales by product:', error);
    res.status(500).json({ error: 'Failed to fetch sales by product data' });
  }
});

// Get weekly sales data from database
app.get('/api/sales/weekly', authenticateToken, async (req, res) => {
  try {
    // First, find the most recent weekly data table
    const tablesQuery = `
      SELECT TABLE_NAME, CREATE_TIME
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME LIKE 'weekly_data_%'
      ORDER BY CREATE_TIME DESC 
      LIMIT 1
    `;
    
    db.query(tablesQuery, async (err, tables) => {
      if (err) {
        console.error('Error finding weekly tables:', err);
        return res.status(500).json({ error: 'Failed to find weekly data tables' });
      }
      
      if (tables.length === 0) {
        // No weekly data tables found, return empty data
        const emptyData = {
          labels: [],
          data: []
        };
        return res.json(emptyData);
      }
      
      // Get data from the most recent weekly table
      const tableName = tables[0].TABLE_NAME;
      const createTime = tables[0].CREATE_TIME;
      console.log('Selected weekly table:', tableName, 'created at:', createTime);
      const dataQuery = `SELECT day, sales FROM \`${tableName}\` ORDER BY id LIMIT 7`;
      
      db.query(dataQuery, (err, results) => {
        if (err) {
          console.error('Error fetching weekly data:', err);
          return res.status(500).json({ error: 'Failed to fetch weekly data' });
        }
        
        if (results.length === 0) {
          // No data in table, return sample data
          const sampleData = {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            data: [120, 150, 130, 170, 200, 220, 180]
          };
          return res.json(sampleData);
        }
        
        const response = {
          labels: results.map(row => row.day),
          data: results.map(row => parseFloat(row.sales))
        };
        
        console.log('Weekly API response:', response);
        res.json(response);
      });
    });
  } catch (error) {
    console.error('Error fetching weekly sales:', error);
    res.status(500).json({ error: 'Failed to fetch weekly sales data' });
  }
});

// Get list of uploaded data tables
app.get('/api/sales/tables', authenticateToken, (req, res) => {
  const sql = `
    SELECT TABLE_NAME, CREATE_TIME, TABLE_ROWS 
    FROM information_schema.TABLES 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME LIKE '%_data_%'
    ORDER BY CREATE_TIME DESC
  `;
  db.query(sql, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ tables: rows });
  });
});

// Get data from a specific uploaded table
app.get('/api/sales/table/:tableName', authenticateToken, (req, res) => {
  const { tableName } = req.params;
  
  // Sanitize table name to prevent SQL injection
  if (!/^[a-zA-Z0-9_]+$/.test(tableName)) {
    return res.status(400).json({ error: 'Invalid table name' });
  }
  
  const sql = `SELECT * FROM \`${tableName}\` ORDER BY created_at DESC LIMIT 100`;
  db.query(sql, (err, rows) => {
    if (err) {
      console.error('Error fetching table data:', err);
      return res.status(500).json({ error: 'Failed to fetch table data' });
    }
    res.json({ data: rows, tableName });
  });
});

// Clean up all old daily tables endpoint (for debugging)
app.post('/api/sales/cleanup-daily', authenticateToken, async (req, res) => {
  try {
    await cleanupAllOldDailyTables();
    res.json({ message: 'All old daily tables cleaned up successfully' });
  } catch (error) {
    console.error('Error cleaning up daily tables:', error);
    res.status(500).json({ error: 'Failed to clean up daily tables' });
  }
});

// Clean up all old daily tables endpoint (for debugging)
app.post('/api/sales/cleanup-daily', authenticateToken, async (req, res) => {
  try {
    await cleanupAllOldDailyTables();
    res.json({ message: 'All old daily tables cleaned up successfully' });
  } catch (error) {
    console.error('Error cleaning up daily tables:', error);
    res.status(500).json({ error: 'Failed to clean up daily tables' });
  }
});

// Helper function to clean up ALL old daily tables (for fresh start)
async function cleanupAllOldDailyTables() {
  try {
    // Get all daily tables
    const cleanupQuery = `
      SELECT TABLE_NAME
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME LIKE 'daily_data_%'
    `;
    
    const oldTables = await new Promise((resolve, reject) => {
      db.query(cleanupQuery, (error, results) => {
        if (error) reject(error);
        else resolve(results);
      });
    });
    
    console.log(`Found ${oldTables.length} daily tables to clean up:`, oldTables.map(t => t.TABLE_NAME));
    
    // Drop each old table
    for (const table of oldTables) {
      const dropQuery = `DROP TABLE IF EXISTS \`${table.TABLE_NAME}\``;
      await new Promise((resolve, reject) => {
        db.query(dropQuery, (error, results) => {
          if (error) reject(error);
          else resolve(results);
        });
      });
      console.log(`Dropped daily table: ${table.TABLE_NAME}`);
    }
    
    console.log('All old daily tables cleaned up successfully');
    
  } catch (error) {
    console.error('Error cleaning up old daily tables:', error);
  }
}

// Helper function to clean up ALL old daily tables (for fresh start)
async function cleanupAllOldDailyTables() {
  try {
    // Get all daily tables
    const cleanupQuery = `
      SELECT TABLE_NAME
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME LIKE 'daily_data_%'
    `;
    
    const oldTables = await new Promise((resolve, reject) => {
      db.query(cleanupQuery, (error, results) => {
        if (error) reject(error);
        else resolve(results);
      });
    });
    
    console.log(`Found ${oldTables.length} daily tables to clean up:`, oldTables.map(t => t.TABLE_NAME));
    
    // Drop each old table
    for (const table of oldTables) {
      const dropQuery = `DROP TABLE IF EXISTS \`${table.TABLE_NAME}\``;
      await new Promise((resolve, reject) => {
        db.query(dropQuery, (error, results) => {
          if (error) reject(error);
          else resolve(results);
        });
      });
      console.log(`Dropped daily table: ${table.TABLE_NAME}`);
    }
    
    console.log('All old daily tables cleaned up successfully.');
  } catch (error) {
    console.error('Error cleaning up old daily tables:', error);
  }
}

// Helper function to clean up old daily tables
async function cleanupOldDailyTables(currentTableName) {
  try {
    // Get all daily tables except the current one
    const cleanupQuery = `
      SELECT TABLE_NAME
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_SCHEMA = DATABASE() 
      AND TABLE_NAME LIKE 'daily_data_%' 
      AND TABLE_NAME != ?
    `;
    
    const oldTables = await new Promise((resolve, reject) => {
      db.query(cleanupQuery, [currentTableName], (error, results) => {
        if (error) reject(error);
        else resolve(results);
      });
    });
    
    console.log(`Found ${oldTables.length} old daily tables to clean up:`, oldTables.map(t => t.TABLE_NAME));
    
    // Drop each old table
    for (const table of oldTables) {
      const dropQuery = `DROP TABLE \`${table.TABLE_NAME}\``;
      await new Promise((resolve, reject) => {
        db.query(dropQuery, (error, results) => {
          if (error) reject(error);
          else resolve(results);
        });
      });
      console.log(`Dropped old daily table: ${table.TABLE_NAME}`);
    }
    
  } catch (error) {
    console.error('Error cleaning up old daily tables:', error);
    // Don't throw error here, just log it
  }
}

// Helper function to create dynamic table based on Excel structure
async function createDynamicTable(tableName, sampleRow, targetType) {
  return new Promise((resolve, reject) => {
    // Analyze the sample row to determine column types and names
    const columns = [];
    const keys = Object.keys(sampleRow);
    
    // Always add id and timestamps
    columns.push('id INT AUTO_INCREMENT PRIMARY KEY');
    columns.push('created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
    columns.push('updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
    
    // Analyze each column in the sample row
    keys.forEach(key => {
      const value = sampleRow[key];
      let columnDef = '';
      
      // Skip empty columns or very generic names
      if (!value || value === '' || key.startsWith('__EMPTY') || key.toLowerCase().includes('total')) {
        return;
      }
      
      // Determine column type based on value
      if (typeof value === 'number' || (!isNaN(value) && value !== '')) {
        columnDef = `\`${key}\` DECIMAL(15,2) DEFAULT 0`;
      } else {
        // For text values, determine appropriate length
        const textLength = String(value).length;
        const maxLength = Math.max(textLength * 2, 255); // Allow some padding
        columnDef = `\`${key}\` VARCHAR(${Math.min(maxLength, 1000)}) DEFAULT ''`;
      }
      
      columns.push(columnDef);
    });
    
    // Add index on created_at for performance
    columns.push('INDEX idx_created_at (created_at)');
    
    const createTableSQL = `CREATE TABLE IF NOT EXISTS \`${tableName}\` (${columns.join(', ')});`;
    
    console.log(`Creating dynamic table ${tableName}:`, createTableSQL);
    
    db.query(createTableSQL, (err, result) => {
      if (err) {
        console.error(`Error creating table ${tableName}:`, err);
        reject(err);
      } else {
        console.log(`Dynamic table ${tableName} created successfully`);
        resolve(result);
      }
    });
  });
}

// Helper function to insert data into dynamic table
async function insertIntoDynamicTable(tableName, rows, sampleRow) {
  return new Promise((resolve, reject) => {
    if (rows.length === 0) {
      resolve(0);
      return;
    }
    
    const keys = Object.keys(sampleRow).filter(key => 
      sampleRow[key] !== '' && 
      !key.startsWith('__EMPTY') && 
      !key.toLowerCase().includes('total')
    );
    
    console.log(`Inserting into ${tableName} with keys:`, keys);
    console.log(`Sample row:`, sampleRow);
    console.log(`Total rows to insert:`, rows.length);
    
    const columns = keys.map(key => `\`${key}\``).join(', ');
    const placeholders = keys.map(() => '?').join(', ');
    
    const insertSQL = `INSERT INTO \`${tableName}\` (${columns}) VALUES (${placeholders})`;
    console.log(`Insert SQL:`, insertSQL);
    
    let insertedCount = 0;
    const insertPromises = rows.map((row, index) => {
      return new Promise((resolveInsert) => {
        const values = keys.map(key => {
          const value = row[key];
          return (typeof value === 'number' || (!isNaN(value) && value !== '')) ? Number(value) : String(value || '');
        });
        
        console.log(`Inserting row ${index}:`, { row, values });
        
        db.query(insertSQL, values, (err) => {
          if (err) {
            console.error(`Error inserting row ${index} into ${tableName}:`, err);
            console.error(`Row data:`, row);
            console.error(`Values:`, values);
          } else {
            insertedCount++;
            console.log(`Successfully inserted row ${index}`);
          }
          resolveInsert();
        });
      });
    });
    
    Promise.all(insertPromises).then(() => {
      console.log(`Total inserted: ${insertedCount} out of ${rows.length}`);
      resolve(insertedCount);
    }).catch(reject);
  });
}

// Upload Excel for sales import
const uploadExcel = multer({ storage });
app.post('/api/sales/upload', authenticateToken, uploadExcel.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    const targetType = (req.body.type || 'monthly').toLowerCase();
    let workbook;
    try {
      workbook = XLSX.readFile(req.file.path);
    } catch (e) {
      return res.status(400).json({ 
        error: 'Unable to read file. Please upload a valid Excel/CSV file.',
        newRecordsCount: newRecordsCount || 0,
        skippedRecordsCount: skippedRecordsCount || 0
      });
    }
    const sheetName = workbook.SheetNames[0];
    let json = [];
    try {
      json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' });
    } catch (e) {
      return res.status(400).json({ 
        error: 'Unable to parse sheet contents.',
        newRecordsCount: newRecordsCount || 0,
        skippedRecordsCount: skippedRecordsCount || 0
      });
    }
    
    console.log(`Uploading ${targetType} data with ${json.length} rows`);
    console.log('Sample row:', json[0]);
    
    // Create dynamic table name based on upload type and full timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const tableName = `${targetType}_data_${timestamp}`;
    
    // For monthly data, keep the existing logic but use dynamic table
    if (targetType === 'monthly') {
      console.log('Monthly upload - raw JSON:', JSON.stringify(json.slice(0, 3), null, 2));
      const rows = [];
      const toNumber = (val) => {
        if (val === '-' || val === '' || val == null) return 0;
        const s = String(val).replace(/[^0-9.\-]/g, '');
        const n = Number(s);
        return isNaN(n) ? 0 : n;
      };
      
      json.forEach((r, idx) => {
        console.log(`Row ${idx}:`, r);
        // Get all keys for debugging
        const keys = Object.keys(r);
        console.log(`Keys: ${keys.join(', ')}`);
        
        // Try multiple ways to get month column - including __EMPTY columns
        const month = r.MONTHS || r.Month || r.MONTH || r.month || r['MONTHS'] || 
                     r.__EMPTY || r.__EMPTY_1 || r.__EMPTY_2 ||
                     r[keys.find(k => k.toLowerCase().includes('month'))] || 
                     r[keys[0]]; // fallback to first column
        
        if (!month || String(month).toLowerCase().includes('total') || String(month).toLowerCase().includes('summary') || String(month).toLowerCase().includes('expenses') || String(month).toLowerCase().includes('sales') || String(month).toLowerCase().includes('profit')) return;
        
        // Try multiple ways to get sales column - prioritize __EMPTY_4 (where sales data is)
        const sales = toNumber(r.SALES || r.Sales || r.sales || r.Sale || r.Total || r[' SALES'] || 
                              r.__EMPTY_4 || r.__EMPTY_3 || r.__EMPTY_5 ||
                              r[keys.find(k => k.toLowerCase().includes('sales'))] ||
                              r[keys[2]] || r[keys[1]]); // fallback positions
        
        // Try multiple ways to get expenses column - prioritize __EMPTY_3 (where expenses data is)
        const expenses = toNumber(r.EXPENSES || r.Expenses || r.expenses || 
                                 r.__EMPTY_3 || r.__EMPTY_4 || r.__EMPTY_5 ||
                                 r[keys.find(k => k.toLowerCase().includes('expense'))] ||
                                 r[keys[1]]);
        
        // Try multiple ways to get profit column - prioritize __EMPTY_5 (where profit data is)
        const profit = toNumber(r.PROFIT || r.Profit || r.profit || 
                               r.__EMPTY_5 || r.__EMPTY_4 || r.__EMPTY_3 ||
                               r[keys.find(k => k.toLowerCase().includes('profit'))] ||
                               r[keys[3]]);
        
        console.log(`Parsed: month=${month}, sales=${sales}, expenses=${expenses}, profit=${profit}`);
        
        // Parse month and year from the string
        const monthStr = String(month).trim().toUpperCase();
        let monthNum = 0;
        let yearNum = new Date().getFullYear();
        
        // Extract year if present
        const yearMatch = monthStr.match(/(\d{4})/);
        if (yearMatch) {
          yearNum = parseInt(yearMatch[1]);
        }
        
        // Map month names to numbers
        const monthMap = {
          'JANUARY': 1, 'FEBRUARY': 2, 'MARCH': 3, 'APRIL': 4,
          'MAY': 5, 'JUNE': 6, 'JULY': 7, 'AUGUST': 8,
          'SEPTEMBER': 9, 'OCTOBER': 10, 'NOVEMBER': 11, 'DECEMBER': 12
        };
        
        for (const [monthName, monthNumber] of Object.entries(monthMap)) {
          if (monthStr.includes(monthName)) {
            monthNum = monthNumber;
            break;
          }
        }
        
        if (monthNum > 0) {
          rows.push({ 
            month: monthStr, 
            monthNum: monthNum,
            year: yearNum,
            sales, 
            expenses, 
            profit 
          });
          console.log(`Parsed: month=${monthStr}, monthNum=${monthNum}, year=${yearNum}, sales=${sales}, expenses=${expenses}, profit=${profit}`);
        }
      });
      
      console.log('Final rows:', rows);
      
      // Save to database using dynamic table
      let importedCount = 0;
      if (rows.length > 0) {
        try {
          // Create dynamic table for this upload
          await createDynamicTable(tableName, rows[0], targetType);
          
          // Insert data into the dynamic table
          importedCount = await insertIntoDynamicTable(tableName, rows, rows[0]);
          
          console.log(`Successfully imported ${importedCount} rows into ${tableName}`);
        } catch (error) {
          console.error('Error saving to dynamic table:', error);
          return res.status(500).json({ error: 'Failed to save data to database' });
        }
      }
      
      const response = { 
        type: 'monthly', 
        imported: importedCount, 
        tableName: tableName,
        labels: rows.map(r => r.month), 
        sales: rows.map(r => r.sales), 
        expenses: rows.map(r => r.expenses), 
        profit: rows.map(r => r.profit) 
      };
      console.log('Server response:', response);
      return res.json(response);
    }

    // For weekly data, add specific handling similar to monthly
    if (targetType === 'weekly') {
      console.log('Weekly upload - raw JSON:', JSON.stringify(json.slice(0, 3), null, 2));
      const rows = [];
      const toNumber = (val) => {
        if (val === '-' || val === '' || val == null) return 0;
        const s = String(val).replace(/[^0-9.\-]/g, '');
        const n = Number(s);
        return isNaN(n) ? 0 : n;
      };
      
      json.forEach((r, idx) => {
        console.log(`Row ${idx}:`, r);
        const keys = Object.keys(r);
        console.log(`Keys: ${keys.join(', ')}`);
        
        // Try to find day/week columns
        const day = r.Day || r.DAY || r.day || r.Weekday || r.WEEKDAY || r.weekday ||
                   r.__EMPTY || r.__EMPTY_1 || r.__EMPTY_2 ||
                   r[keys.find(k => k.toLowerCase().includes('day') || k.toLowerCase().includes('week'))] ||
                   r[keys[0]]; // fallback to first column
        
        if (!day || String(day).toLowerCase().includes('total') || String(day).toLowerCase().includes('summary')) return;
        
        // Try to find sales/amount columns
        const sales = toNumber(r.Sales || r.SALES || r.sales || r.Amount || r.AMOUNT || r.amount || r.Total || r.TOTAL ||
                              r.__EMPTY_1 || r.__EMPTY_2 || r.__EMPTY_3 || r.__EMPTY_4 ||
                              r[keys.find(k => k.toLowerCase().includes('sales') || k.toLowerCase().includes('amount'))] ||
                              r[keys[1]] || r[keys[2]]); // fallback positions
        
        console.log(`Parsed: day=${day}, sales=${sales}`);
        
        if (sales > 0) {
          rows.push({ 
            day: String(day).trim(), 
            sales: sales
          });
        }
      });
      
      console.log('Final weekly rows:', rows);
      
      // Save to database using dynamic table
      let importedCount = 0;
      if (rows.length > 0) {
        try {
          // Create dynamic table for this upload
          await createDynamicTable(tableName, rows[0], targetType);
          
          // Insert data into the dynamic table
          importedCount = await insertIntoDynamicTable(tableName, rows, rows[0]);
          
          console.log(`Successfully imported ${importedCount} rows into ${tableName}`);
        } catch (error) {
          console.error('Error saving to dynamic table:', error);
          return res.status(500).json({ error: 'Failed to save data to database' });
        }
      }
      
      const response = { 
        type: 'weekly', 
        imported: importedCount, 
        tableName: tableName,
        labels: rows.map(r => r.day), 
        data: rows.map(r => r.sales)
      };
      console.log('Server response:', response);
      return res.json(response);
    }

    // For daily data, add specific handling
    if (targetType === 'daily') {
      console.log('Daily upload - raw JSON:', JSON.stringify(json.slice(0, 3), null, 2));
      const rows = [];
      const toNumber = (val) => {
        if (val === '-' || val === '' || val == null) return 0;
        const s = String(val).replace(/[^0-9.\-]/g, '');
        const n = Number(s);
        return isNaN(n) ? 0 : n;
      };
      
      json.forEach((r, idx) => {
        console.log(`Row ${idx}:`, r);
        const keys = Object.keys(r);
        console.log(`Keys: ${keys.join(', ')}`);
        
        // Try to find date/time columns (for daily data, this should be Date)
        const dateTime = r.Date || r.DATE || r.date || r.Time || r.TIME || r.time ||
                        r.__EMPTY || r.__EMPTY_1 || r.__EMPTY_2 ||
                        r[keys.find(k => k.toLowerCase().includes('date') || k.toLowerCase().includes('time'))] ||
                        r[keys[0]]; // fallback to first column

        // Try to find sales columns
        const sales = toNumber(r.Sales || r.SALES || r.sales || r.Amount || r.AMOUNT || r.amount ||
                              r.__EMPTY_1 || r.__EMPTY_2 || r.__EMPTY_3 ||
                              r[keys.find(k => k.toLowerCase().includes('sales') || k.toLowerCase().includes('amount'))] ||
                              r[keys[1]]); // fallback to second column

        console.log(`Parsed - Date: "${dateTime}", Sales: ${sales}`);
        
        if (dateTime && dateTime !== '' && sales > 0) {
          // Convert date to a proper datetime format for storage
          let formattedDateTime = '';
          
          // Check if it's an Excel date number
          if (typeof dateTime === 'number' || (!isNaN(dateTime) && !isNaN(parseFloat(dateTime)))) {
            // Excel date serial number conversion
            const excelSerial = parseFloat(dateTime);
            
            // Excel's epoch is 1900-01-01, but Excel incorrectly treats 1900 as a leap year
            // So we need to account for this bug
            const excelEpoch = new Date(1900, 0, 1);
            
            // Excel serial number 1 = 1900-01-01, but we need to account for the leap year bug
            let daysSinceEpoch;
            if (excelSerial <= 59) {
              // For dates before March 1, 1900, Excel has the leap year bug
              daysSinceEpoch = excelSerial - 1;
            } else {
              // For dates on or after March 1, 1900, account for the leap year bug
              daysSinceEpoch = excelSerial - 2;
            }
            
            // Add one more day to correct the off-by-one error
            daysSinceEpoch = daysSinceEpoch + 1;
            
            const date = new Date(excelEpoch.getTime() + daysSinceEpoch * 24 * 60 * 60 * 1000);
            formattedDateTime = date.toISOString().slice(0, 19).replace('T', ' '); // Format as 'YYYY-MM-DD HH:MM:SS'
          } else {
            // Try parsing as string
            let dateStr = String(dateTime).trim();
            
            // If it's a full datetime, keep it as is
            if (dateStr.includes(' ')) {
              formattedDateTime = dateStr;
            } else {
              // If it's just a date, add a default time
              formattedDateTime = dateStr + ' 00:00:00';
            }
            
            // If it's in YYYY-MM-DD format, convert to proper datetime
            if (formattedDateTime.match(/^\d{4}-\d{2}-\d{2}$/)) {
              formattedDateTime = formattedDateTime + ' 00:00:00';
            }
          }
          
          rows.push({ date_time: formattedDateTime, sales: sales });
        }
      });
      
      console.log('Final daily rows:', rows);
      
      // Save to database using dynamic table
      let importedCount = 0;
      if (rows.length > 0) {
        try {
          // Create dynamic table for this upload
          await createDynamicTable(tableName, rows[0], targetType);
          
          // Insert data into the dynamic table
          importedCount = await insertIntoDynamicTable(tableName, rows, rows[0]);
          
          console.log(`Successfully imported ${importedCount} rows into ${tableName}`);
          
          // Clean up old daily tables (keep only the latest one)
          await cleanupOldDailyTables(tableName);
          
        } catch (error) {
          console.error('Error saving to dynamic table:', error);
          return res.status(500).json({ error: 'Failed to save data to database' });
        }
      }
      
      const response = { 
        type: 'daily', 
        imported: importedCount, 
        tableName: tableName,
        labels: rows.map(r => {
          const date = new Date(r.date_time);
          return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        }), 
        data: rows.map(r => r.sales)
      };
      console.log('Server response:', response);
      return res.json(response);
    }

    // For any other data type, use dynamic table creation
    if (json.length > 0) {
      try {
        // Filter out empty rows and rows with only empty values
        const validRows = json.filter(row => {
          const values = Object.values(row);
          return values.some(value => value !== '' && value != null);
        });
        
        if (validRows.length === 0) {
          return res.json({ 
            imported: 0, 
            type: targetType, 
            tableName: tableName,
            preview: [],
            message: 'No valid data found in the uploaded file' 
          });
        }
        
        // Create dynamic table for this upload
        await createDynamicTable(tableName, validRows[0], targetType);
        
        // Insert data into the dynamic table
        const importedCount = await insertIntoDynamicTable(tableName, validRows, validRows[0]);
        
        console.log(`Successfully imported ${importedCount} rows into ${tableName}`);
        
        // Return preview of first few rows
        const preview = validRows.slice(0, 5).map(row => {
          const previewRow = {};
          Object.keys(row).forEach(key => {
            if (row[key] !== '' && !key.startsWith('__EMPTY')) {
              previewRow[key] = row[key];
            }
          });
          return previewRow;
        });
        
        return res.json({ 
          imported: importedCount, 
          type: targetType, 
          tableName: tableName,
          preview: preview,
          message: `Successfully imported ${importedCount} rows into table ${tableName}` 
        });
        
      } catch (error) {
        console.error('Error processing dynamic upload:', error);
        return res.status(500).json({ error: 'Failed to process uploaded data' });
      }
    }
    
    return res.json({ 
      imported: 0, 
      type: targetType, 
      tableName: tableName,
      preview: [],
      message: 'No data found in the uploaded file' 
    });
  } catch (e) {
    console.error('Excel upload error:', e);
    return res.status(500).json({ error: e.message });
  }
});

// Parse and save Excel file for data table display (with database storage)
app.post('/api/sales/parse-file', authenticateToken, uploadExcel.single('file'), async (req, res) => {
  // Initialize variables outside try block to prevent undefined errors
  let newRecordsCount = 0;
  let skippedRecordsCount = 0;
  
  try {
    if (!req.file) {
      return res.status(400).json({ 
        error: 'No file uploaded',
        newRecordsCount: newRecordsCount || 0,
        skippedRecordsCount: skippedRecordsCount || 0
      });
    }

    let workbook;
    try {
      workbook = XLSX.readFile(req.file.path);
    } catch (e) {
      return res.status(400).json({ 
        error: 'Unable to read file. Please upload a valid Excel/CSV file.',
        newRecordsCount: newRecordsCount || 0,
        skippedRecordsCount: skippedRecordsCount || 0
      });
    }

    const sheetName = workbook.SheetNames[0];
    let json = [];
    try {
      json = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '', header: 1 });
    } catch (e) {
      return res.status(400).json({ 
        error: 'Unable to parse sheet contents.',
        newRecordsCount: newRecordsCount || 0,
        skippedRecordsCount: skippedRecordsCount || 0
      });
    }

    // Check if we should use existing table or create new one
    let tableName;
    let isIncremental = false;
    let existingData = [];
    const firstRow = json.length > 0 ? json[0] : null;
    
    if (json.length > 0) {
      
      // Check if there's an existing data table with the same column structure
      const existingTablesQuery = `
        SELECT table_name, column_count 
        FROM data_table_metadata 
        WHERE column_count = ? 
        ORDER BY created_at DESC 
        LIMIT 1
      `;
      
      const existingTableResult = await new Promise((resolve, reject) => {
        db.query(existingTablesQuery, [firstRow.length], (err, result) => {
          if (err) reject(err);
          else resolve(result);
        });
      });
      
      if (existingTableResult.length > 0) {
        // Use existing table for incremental upload
        tableName = existingTableResult[0].table_name;
        isIncremental = true;
        
        // Get existing data to compare against
        const existingDataQuery = `SELECT * FROM ${tableName} ORDER BY id DESC`;
        existingData = await new Promise((resolve, reject) => {
          db.query(existingDataQuery, (err, result) => {
            if (err) reject(err);
            else resolve(result);
          });
        });
        
        console.log(`Using existing table ${tableName} for incremental upload. Existing records: ${existingData.length}`);
      } else {
        // Create new table
        const timestamp = new Date().toISOString().replace(/[:.-]/g, '_').replace('T', '_').replace('Z', '');
        tableName = `data_table_${timestamp}`;
        
        const columnDefinitions = firstRow.map((_, index) => `col_${index + 1} TEXT`).join(', ');
        const createTableQuery = `CREATE TABLE ${tableName} (id INT AUTO_INCREMENT PRIMARY KEY, ${columnDefinitions}, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`;
        
        await new Promise((resolve, reject) => {
          db.query(createTableQuery, (err) => {
            if (err) reject(err);
            else resolve();
          });
        });
        
        console.log(`Created new table ${tableName}`);
      }
      
      // Helper function to convert Excel date serial number to readable date
      const toReadableDate = (excelDate) => {
        if (typeof excelDate === 'number' && excelDate > 25569) { // Excel date threshold
          // Excel date conversion (1900-01-01 is day 1, but Excel has a leap year bug)
          const date = new Date((excelDate - 25569) * 86400 * 1000);
          return date.toISOString().split('T')[0]; // Return YYYY-MM-DD format
        }
        return excelDate;
      };

      // Process and insert new data rows
      
      for (let i = 0; i < json.length; i++) {
        const row = json[i];
        // Convert Excel dates in the first column to readable dates
        const processedRow = row.map((val, index) => {
          if (index === 0) { // Assuming first column contains dates
            return toReadableDate(val);
          }
          return val;
        });
        
        // For incremental uploads, check if this record already exists or if it's truly new/changed
        if (isIncremental && existingData.length > 0) {
          // Create a unique key from the first column (usually date) for faster comparison
          const recordKey = processedRow[0] || 'unknown';
          
          const existingRecord = existingData.find(existingRecord => {
            const existingKey = existingRecord.col_1 || 'unknown';
            return existingKey === recordKey;
          });
          
          if (existingRecord) {
            // Check if the record has actually changed (compare all columns except ID and created_at)
            const hasChanges = processedRow.some((value, index) => {
              const colName = `col_${index + 1}`;
              const existingValue = existingRecord[colName] || '';
              const newValue = String(value || '');
              return existingValue !== newValue;
            });
            
            if (hasChanges) {
              // Update the existing record instead of inserting a new one
              const updateValues = processedRow.map(val => String(val || '')).map(val => val.replace(/'/g, "''"));
              const updateColumns = firstRow.map((_, index) => `col_${index + 1} = ?`).join(', ');
              const updateQuery = `UPDATE ${tableName} SET ${updateColumns} WHERE col_1 = ?`;
              
              await new Promise((resolve, reject) => {
                db.query(updateQuery, [...updateValues, recordKey], (err) => {
                  if (err) reject(err);
                  else resolve();
                });
              });
              
              newRecordsCount++;
              console.log(`Updated existing record: ${recordKey}`);
            } else {
              skippedRecordsCount++;
              console.log(`No changes detected for record: ${recordKey}`);
            }
            continue;
          }
        }
        
        const values = processedRow.map(val => String(val || '')).map(val => val.replace(/'/g, "''")); // Escape single quotes
        const placeholders = values.map(() => '?').join(', ');
        const insertQuery = `INSERT INTO ${tableName} (${firstRow.map((_, index) => `col_${index + 1}`).join(', ')}) VALUES (${placeholders})`;
        
        await new Promise((resolve, reject) => {
          db.query(insertQuery, values, (err) => {
            if (err) reject(err);
            else resolve();
          });
        });
        
        newRecordsCount++;
      }
      
      // Store metadata in a separate table (only for new tables)
      if (!isIncremental) {
        const metadataQuery = `INSERT INTO data_table_metadata (table_name, file_name, row_count, column_count, created_at) VALUES (?, ?, ?, ?, NOW())`;
        await new Promise((resolve, reject) => {
          db.query(metadataQuery, [tableName, req.file.originalname, json.length, firstRow.length], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });
      }
      
      console.log(`Upload complete: ${newRecordsCount} new records added, ${skippedRecordsCount} duplicates skipped`);
    }

    // Store uploaded data in uploaded_data table for the "Uploaded Data" section
    let uploadedDataStored = false;
    let validRecordsCount = 0;
    let skippedDuplicatesCount = 0;
    if (json.length > 0 && firstRow && firstRow.length >= 2) {
      try {
        // Create uploaded_data table if it doesn't exist
        const createUploadedDataTableSQL = `
          CREATE TABLE IF NOT EXISTS uploaded_data (
            id INT AUTO_INCREMENT PRIMARY KEY,
            file_name VARCHAR(255) NOT NULL,
            column1 VARCHAR(255),
            column2 VARCHAR(255),
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_file_name (file_name),
            INDEX idx_uploaded_at (uploaded_at)
          )
        `;
        
        await new Promise((resolve, reject) => {
          db.query(createUploadedDataTableSQL, (err) => {
            if (err) reject(err);
            else resolve();
          });
        });
        
        // Get existing data for this file to check for duplicates
        const existingDataQuery = `SELECT column1, column2 FROM uploaded_data WHERE file_name = ?`;
        const existingData = await new Promise((resolve, reject) => {
          db.query(existingDataQuery, [req.file.originalname], (err, result) => {
            if (err) reject(err);
            else resolve(result);
          });
        });
        
        console.log(`Found ${existingData.length} existing records for file: ${req.file.originalname}`);
        
        // Insert the data (using first two columns) - filter out empty records and duplicates
        
        for (let i = 1; i < json.length; i++) { // Skip header row
          const row = json[i];
          if (!row || row.length < 2) continue;
          
          // Check if both columns have valid data
          const col1 = String(row[0] || '').trim();
          const col2 = String(row[1] || '').trim();
          
          if (col1 === '' || col2 === '') {
            console.log(`Skipping empty record at row ${i}: col1='${col1}', col2='${col2}'`);
            continue;
          }
          
          // Check if this record already exists (based on column1 value - the date)
          const existingRecord = existingData.find(existingRecord => {
            return existingRecord.column1 === col1;
          });
          
          if (existingRecord) {
            // Check if the sales value has changed
            if (existingRecord.column2 === col2) {
              console.log(`Skipping unchanged record: ${col1} -> ${col2}`);
              skippedDuplicatesCount++;
            } else {
              // Update the existing record with new sales value
              const updateQuery = `UPDATE uploaded_data SET column2 = ? WHERE file_name = ? AND column1 = ?`;
              await new Promise((resolve, reject) => {
                db.query(updateQuery, [col2, req.file.originalname, col1], (err) => {
                  if (err) reject(err);
                  else {
                    validRecordsCount++;
                    console.log(`Updated record: ${col1} -> ${existingRecord.column2} (old) -> ${col2} (new)`);
                    resolve();
                  }
                });
              });
            }
          } else {
            // Insert new record
            const insertQuery = `INSERT INTO uploaded_data (file_name, column1, column2) VALUES (?, ?, ?)`;
            await new Promise((resolve, reject) => {
              db.query(insertQuery, [req.file.originalname, col1, col2], (err) => {
                if (err) reject(err);
                else {
                  validRecordsCount++;
                  console.log(`Added new record: ${col1} -> ${col2}`);
                  resolve();
                }
              });
            });
          }
        }
        
        uploadedDataStored = true;
        console.log(`Incremental upload complete for ${req.file.originalname}: ${validRecordsCount} records processed (new/updated), ${skippedDuplicatesCount} unchanged records skipped`);
      } catch (error) {
        console.error('Error storing uploaded data:', error);
      }
    }

    // Note: Daily data is now handled by the uploaded_data table
    // Both the uploaded data table and daily sales chart use the same data source

    // Clean up the uploaded file
    fs.unlinkSync(req.file.path);

    // Return the parsed data with incremental upload information
    res.json({
      success: true,
      data: json,
      fileName: req.file.originalname,
      rowCount: json.length,
      tableName: tableName,
      columnCount: json.length > 0 ? json[0].length : 0,
      isIncremental: true, // Always incremental for uploaded_data table
      newRecordsCount: newRecordsCount || 0,
      skippedRecordsCount: skippedRecordsCount || 0,
      uploadedDataStored: uploadedDataStored,
      uploadedDataIncremental: uploadedDataStored,
      uploadedDataNewCount: validRecordsCount || 0,
      uploadedDataSkippedCount: skippedDuplicatesCount || 0,
      message: uploadedDataStored ? 
        `Incremental upload: ${validRecordsCount || 0} records processed (new/updated), ${skippedDuplicatesCount || 0} unchanged records skipped` : 
        'File parsed and saved successfully'
    });

  } catch (e) {
    console.error('File parsing error:', e);
    return res.status(500).json({ 
      error: e.message,
      newRecordsCount: newRecordsCount || 0,
      skippedRecordsCount: skippedRecordsCount || 0
    });
  }
});

// Get uploaded data for the "Uploaded Data" section
app.get('/api/sales/uploaded-data', authenticateToken, async (req, res) => {
  try {
    console.log('=== UPLOADED DATA API ENDPOINT CALLED ===');
    
    // Check if uploaded_data table exists first
    const checkTableQuery = `SHOW TABLES LIKE 'uploaded_data'`;
    const tableExists = await new Promise((resolve, reject) => {
      db.query(checkTableQuery, (err, results) => {
        if (err) reject(err);
        else resolve(results.length > 0);
      });
    });
    
    console.log('Uploaded data table exists:', tableExists);
    
    if (!tableExists) {
      return res.json({
        success: true,
        data: [],
        fileName: null,
        message: 'No uploaded data table found'
      });
    }
    
    // Get the most recent uploaded data
    const query = `
      SELECT file_name, column1, column2, uploaded_at 
      FROM uploaded_data 
      ORDER BY CAST(column1 AS UNSIGNED) ASC 
      LIMIT 100
    `;
    
    console.log('Executing query:', query);
    
    const results = await new Promise((resolve, reject) => {
      db.query(query, (err, results) => {
        if (err) reject(err);
        else resolve(results);
      });
    });
    
    console.log('Query results:', results.length, 'records found');
    
    if (results.length === 0) {
      return res.json({
        success: true,
        data: [],
        fileName: null,
        message: 'No uploaded data found'
      });
    }
    
    // Get the latest file name
    const latestFile = results[0].file_name;
    const fileData = results.map(row => ({
      date: row.column1,
      sales: row.column2
    }));
    
    console.log('Returning data for file:', latestFile, 'with', fileData.length, 'records');
    
    res.json({
      success: true,
      data: fileData,
      fileName: latestFile,
      rowCount: fileData.length,
      message: 'Uploaded data retrieved successfully'
    });
    
  } catch (error) {
    console.error('Error fetching uploaded data:', error);
    res.status(500).json({ error: 'Failed to fetch uploaded data: ' + error.message });
  }
});

// Get the latest uploaded data table
app.get('/api/sales/data-table', authenticateToken, async (req, res) => {
  try {
    // Get the latest data table metadata
    const metadataQuery = `SELECT * FROM data_table_metadata ORDER BY created_at DESC LIMIT 1`;
    
    const [metadata] = await new Promise((resolve, reject) => {
      db.query(metadataQuery, (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });

    if (!metadata || metadata.length === 0) {
      return res.json({
        success: true,
        data: null,
        message: 'No data table found'
      });
    }

    const latestTable = metadata[0];
    
    // Get the data from the latest table
    const dataQuery = `SELECT * FROM ${latestTable.table_name} ORDER BY id`;
    
    const [data] = await new Promise((resolve, reject) => {
      db.query(dataQuery, (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });

    // Convert back to array format for frontend
    const convertedData = data.map(row => {
      const convertedRow = [];
      for (let i = 1; i <= latestTable.column_count; i++) {
        convertedRow.push(row[`col_${i}`] || '');
      }
      return convertedRow;
    });

    res.json({
      success: true,
      data: convertedData,
      fileName: latestTable.file_name,
      rowCount: latestTable.row_count,
      message: 'Data table retrieved successfully'
    });

  } catch (e) {
    console.error('Error retrieving data table:', e);
    return res.status(500).json({ error: e.message });
  }
});

// ==================== USER/STAFF MANAGEMENT API ENDPOINTS ====================

// GET /api/users - Fetch all users/staff
app.get('/api/users', authenticateToken, (req, res) => {
  const { role, status, search } = req.query;
  
  let query = `
    SELECT 
      id, username, email, phone, first_name, last_name, role, status,
      created_at, updated_at
    FROM users 
    WHERE 1=1
  `;
  
  const params = [];
  
  // Filter by role
  if (role && role !== 'All') {
    query += ' AND role = ?';
    params.push(role.toLowerCase());
  }
  
  // Filter by status
  if (status && status !== 'All') {
    query += ' AND status = ?';
    params.push(status);
  }
  
  // Search functionality
  if (search && search.trim()) {
    query += ' AND (username LIKE ? OR email LIKE ? OR first_name LIKE ? OR last_name LIKE ?)';
    const searchTerm = `%${search.trim()}%`;
    params.push(searchTerm, searchTerm, searchTerm, searchTerm);
  }
  
  query += ' ORDER BY created_at DESC';
  
  db.query(query, params, (err, results) => {
    if (err) {
      console.error('Error fetching users:', err);
      return res.status(500).json({ error: 'Failed to fetch users' });
    }
    
    // Format the results
    const formattedUsers = results.map(user => ({
      id: user.id,
      name: user.first_name && user.last_name ? `${user.first_name} ${user.last_name}` : user.username,
      username: user.username,
      email: user.email || 'N/A',
      phone: user.phone || 'N/A',
      role: user.role.charAt(0).toUpperCase() + user.role.slice(1),
      status: user.status,
      created_at: user.created_at,
      updated_at: user.updated_at
    }));
    
    res.json({ users: formattedUsers });
  });
});

// POST /api/users - Create new user/staff
app.post('/api/users', authenticateToken, async (req, res) => {
  try {
    const { username, email, phone, firstName, lastName, role, password, status } = req.body;
    
    // Use email as username for login (email is required and must be unique)
    const loginUsername = email || username;
    
    // Validate required fields
    if (!loginUsername || !role || !password) {
      return res.status(400).json({ error: 'Email, role, and password are required' });
    }
    
    // Validate email format
    if (!loginUsername.includes('@')) {
      return res.status(400).json({ error: 'Valid email address is required' });
    }
    
    // Check if email/username already exists
    const [existingUsers] = await new Promise((resolve, reject) => {
      db.query('SELECT id FROM users WHERE username = ?', [loginUsername], (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });
    
    if (existingUsers.length > 0) {
      return res.status(400).json({ error: 'Email already exists' });
    }
    
    // Hash password
    const saltRounds = parseInt(process.env.BCRYPT_ROUNDS || '10', 10);
    const passwordHash = await bcrypt.hash(password, saltRounds);
    
    // Insert new user with email as username
    const insertQuery = `
      INSERT INTO users (username, password_hash, email, phone, first_name, last_name, role, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    await new Promise((resolve, reject) => {
      db.query(insertQuery, [loginUsername, passwordHash, loginUsername, phone, firstName, lastName, role.toLowerCase(), status || 'Active'], (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    });
    
    res.json({ 
      message: 'User created successfully',
      user: {
        username: loginUsername,
        email: loginUsername,
        phone: phone || 'N/A',
        name: firstName && lastName ? `${firstName} ${lastName}` : loginUsername,
        role: role.charAt(0).toUpperCase() + role.slice(1),
        status: 'Active'
      }
    });
    
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

// Reset user password (Admin only) - MUST come before /api/users/:id routes
app.post('/api/users/:id/reset-password', authenticateToken, async (req, res) => {
  console.log('Reset password route hit for user ID:', req.params.id);
  try {
    const userId = req.params.id;
    const { newPassword } = req.body;
    
    // Validate required fields
    if (!newPassword) {
      return res.status(400).json({ error: 'New password is required' });
    }
    
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }
    
    // Check if user is admin
    const requestingUser = req.user;
    console.log('Requesting user role:', requestingUser.role);
    console.log('Requesting user:', requestingUser);
    if (requestingUser.role && requestingUser.role.toLowerCase() !== 'admin') {
      return res.status(403).json({ error: 'Only admin users can reset passwords' });
    }
    
    // Prevent admin from resetting their own password via this endpoint
    if (requestingUser.id == userId) {
      return res.status(400).json({ error: 'Cannot reset your own password via this endpoint' });
    }
    
    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    // Update the user's password
    const updateQuery = 'UPDATE users SET password_hash = ? WHERE id = ?';
    await new Promise((resolve, reject) => {
      db.query(updateQuery, [hashedPassword, userId], (error, results) => {
        if (error) {
          reject(error);
        } else {
          resolve(results);
        }
      });
    });
    
    // Fetch updated user details
    const selectQuery = 'SELECT id, username, email, phone, first_name, last_name, role, status FROM users WHERE id = ?';
    const userResult = await new Promise((resolve, reject) => {
      db.query(selectQuery, [userId], (error, results) => {
        if (error) {
          reject(error);
        } else {
          resolve(results);
        }
      });
    });
    
    if (userResult.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const user = userResult[0];
    
    res.json({ 
      message: 'Password reset successfully',
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        phone: user.phone,
        firstName: user.first_name,
        lastName: user.last_name,
        name: user.first_name && user.last_name ? `${user.first_name} ${user.last_name}` : user.username,
        role: user.role,
        status: user.status
      }
    });
    
  } catch (error) {
    console.error('Error resetting password:', error);
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

// PUT /api/users/:id - Update user/staff
app.put('/api/users/:id', authenticateToken, async (req, res) => {
  try {
    const userId = req.params.id;
    const { username, email, phone, firstName, lastName, role, password, status } = req.body;
    
    // Validate required fields
    if (!username || !role) {
      return res.status(400).json({ error: 'Username and role are required' });
    }
    
    // Check if username already exists for other users
    const [existingUsers] = await new Promise((resolve, reject) => {
      db.query('SELECT id FROM users WHERE username = ? AND id != ?', [username, userId], (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });
    
    if (existingUsers.length > 0) {
      return res.status(400).json({ error: 'Username already exists' });
    }
    
    // Prepare update query
    let updateQuery = `
      UPDATE users 
      SET username = ?, email = ?, phone = ?, first_name = ?, last_name = ?, role = ?, status = ?, updated_at = CURRENT_TIMESTAMP
    `;
    const params = [username, email, phone, firstName, lastName, role.toLowerCase(), status || 'Active'];
    
    // Include password update if provided
    if (password && password.trim()) {
      const saltRounds = parseInt(process.env.BCRYPT_ROUNDS || '10', 10);
      const passwordHash = await bcrypt.hash(password, saltRounds);
      updateQuery += ', password_hash = ?';
      params.push(passwordHash);
    }
    
    updateQuery += ' WHERE id = ?';
    params.push(userId);
    
    // Execute update
    const [result] = await new Promise((resolve, reject) => {
      db.query(updateQuery, params, (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ 
      message: 'User updated successfully',
      user: {
        id: userId,
        username,
        email: email || 'N/A',
        phone: phone || 'N/A',
        name: firstName && lastName ? `${firstName} ${lastName}` : username,
        role: role.charAt(0).toUpperCase() + role.slice(1),
        status: 'Active'
      }
    });
    
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// DELETE /api/users/bulk - Delete multiple users
app.delete('/api/users/bulk', authenticateToken, async (req, res) => {
  try {
    const { userIds } = req.body;
    
    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ error: 'User IDs are required' });
    }
    
    // Prevent deleting admin user
    const filteredIds = userIds.filter(id => id !== '1' && id !== 1);
    
    if (filteredIds.length === 0) {
      return res.status(400).json({ error: 'Cannot delete admin user' });
    }
    
    // Delete users
    const placeholders = filteredIds.map(() => '?').join(',');
    const [result] = await new Promise((resolve, reject) => {
      db.query(`DELETE FROM users WHERE id IN (${placeholders})`, filteredIds, (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });
    
    res.json({ 
      message: `${result.affectedRows} user(s) deleted successfully`,
      deletedCount: result.affectedRows
    });
    
  } catch (error) {
    console.error('Error deleting users:', error);
    res.status(500).json({ error: 'Failed to delete users' });
  }
});

// DELETE /api/users/:id - Delete user/staff
app.delete('/api/users/:id', authenticateToken, async (req, res) => {
  try {
    const userId = req.params.id;
    
    // Prevent deleting the admin user (assuming ID 1 is admin)
    if (userId === '1') {
      return res.status(400).json({ error: 'Cannot delete admin user' });
    }
    
    const [result] = await new Promise((resolve, reject) => {
      db.query('DELETE FROM users WHERE id = ?', [userId], (err, results) => {
        if (err) reject(err);
        else resolve([results]);
      });
    });
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ message: 'User deleted successfully' });
    
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});
