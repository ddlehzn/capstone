// Test SMS Mode Script
// Run this with: node test_sms_mode.js

require('dotenv').config();
const NotificationService = require('./services/NotificationService');

async function testSMSMode() {
  console.log('🧪 Testing SMS Mode...\n');
  
  const notificationService = new NotificationService();
  
  // Wait for initialization
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  console.log('\n📱 Testing SMS to supplier...');
  const supplierResult = await notificationService.sendSMSNotification(
    '+1234567890', // Supplier phone
    'Hello Supplier, we need to restock Product X. Do you have it available?',
    null
  );
  
  console.log('Supplier SMS Result:', supplierResult);
  
  console.log('\n📱 Testing SMS to user...');
  const userResult = await notificationService.sendSMSNotification(
    '+0987654321', // User phone
    'Payment Required: Order confirmed with Supplier A for Product X. Please process payment.',
    null
  );
  
  console.log('User SMS Result:', userResult);
  
  console.log('\n✅ SMS Test Mode Demo Complete!');
  console.log('\nTo enable real SMS:');
  console.log('1. Get Twilio credentials from https://console.twilio.com/');
  console.log('2. Add to .env file:');
  console.log('   SMS_TEST_MODE=false');
  console.log('   TWILIO_ACCOUNT_SID=AC...');
  console.log('   TWILIO_AUTH_TOKEN=...');
  console.log('   TWILIO_PHONE_NUMBER=+1234567890');
  console.log('3. Restart your server');
}

testSMSMode().catch(console.error);
