require('dotenv').config();
const mysql = require('mysql2/promise');

class ChatIntegrationService {
  constructor() {
    this.dbConnection = null;
    this.init();
  }

  async init() {
    try {
      // Initialize database connection
      this.dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306
      });

      console.log('✓ ChatIntegrationService initialized successfully');
    } catch (error) {
      console.error('❌ Error initializing ChatIntegrationService:', error);
    }
  }

  /**
   * Create or get the system monitoring chat session
   */
  async getSystemMonitoringSession() {
    try {
      // Get admin user(s)
      const [adminUsers] = await this.dbConnection.execute(`
        SELECT id FROM users WHERE role = 'admin' LIMIT 1
      `);

      if (adminUsers.length === 0) {
        console.error('❌ No admin user found for system monitoring session');
        return null;
      }

      const adminUserId = adminUsers[0].id;

      // Check if system monitoring session already exists
      const [existingSessions] = await this.dbConnection.execute(`
        SELECT id FROM chat_sessions 
        WHERE user_id = ? AND title = 'System Monitoring - AI Inventory Management'
        LIMIT 1
      `, [adminUserId]);

      if (existingSessions.length > 0) {
        return existingSessions[0].id;
      }

      // Create new system monitoring session
      const [result] = await this.dbConnection.execute(`
        INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)
      `, [adminUserId, 'System Monitoring - AI Inventory Management']);

      console.log('✓ Created new system monitoring chat session');
      return result.insertId;

    } catch (error) {
      console.error('❌ Error getting system monitoring session:', error);
      return null;
    }
  }

  /**
   * Log AI inventory activity to chat
   */
  async logInventoryActivity(activityType, message, details = null, priority = 'info') {
    try {
      const sessionId = await this.getSystemMonitoringSession();
      if (!sessionId) {
        console.error('❌ Could not get monitoring session');
        return;
      }

      // Get or create system user
      const [systemUsers] = await this.dbConnection.execute(`
        SELECT id FROM users WHERE username = 'system' LIMIT 1
      `);
      
      let systemUserId;
      if (systemUsers.length === 0) {
        // Create system user if it doesn't exist
        const [result] = await this.dbConnection.execute(`
          INSERT INTO users (username, email, password_hash, role, first_name, last_name)
          VALUES ('system', 'system@inventory.local', 'none', 'admin', 'Inventory', 'System')
        `);
        systemUserId = result.insertId;
      } else {
        systemUserId = systemUsers[0].id;
      }

      // Format the message based on activity type
      const formattedMessage = this.formatInventoryMessage(activityType, message, details, priority);
      
      // Insert message into chat_messages
      await this.dbConnection.execute(`
        INSERT INTO chat_messages (user_id, username, message, message_type, session_id)
        VALUES (?, ?, ?, ?, ?)
      `, [systemUserId, 'AI System', formattedMessage, 'system', sessionId]);

      // Update session timestamp
      await this.dbConnection.execute(`
        UPDATE chat_sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = ?
      `, [sessionId]);

      console.log(`📝 Logged inventory activity: ${activityType}`);

    } catch (error) {
      console.error('❌ Error logging inventory activity:', error);
    }
  }

  /**
   * Format inventory messages for chat display
   */
  formatInventoryMessage(activityType, message, details, priority) {
    const timestamp = new Date().toLocaleString();
    const priorityIcon = {
      'info': 'ℹ️',
      'warning': '⚠️',
      'error': '❌',
      'success': '✅',
      'urgent': '🚨'
    };

    let formattedMessage = `${priorityIcon[priority] || 'ℹ️'} **${activityType.toUpperCase()}** [${timestamp}]\n\n${message}`;

    if (details) {
      formattedMessage += '\n\n**Details:**\n';
      if (typeof details === 'object') {
        for (const [key, value] of Object.entries(details)) {
          formattedMessage += `• **${key}**: ${value}\n`;
        }
      } else {
        formattedMessage += `${details}`;
      }
    }

    return formattedMessage;
  }

  /**
   * Log low stock detection
   */
  async logLowStockDetection(productName, currentStock, threshold, reorderQuantity) {
    await this.logInventoryActivity(
      'Low Stock Alert',
      `Product "${productName}" is running critically low!`,
      {
        'Current Stock': `${currentStock} units`,
        'Minimum Threshold': `${threshold} units`,
        'Reorder Quantity': `${reorderQuantity} units`,
        'Status': 'Initiating automated reorder process'
      },
      'urgent'
    );
  }

  /**
   * Log AI supplier communication
   */
  async logSupplierCommunication(productName, supplierNames, suppliersCount, communicationType = 'inquiry') {
    const actionText = {
      'inquiry': 'sent stock inquiries to',
      'quote_comparison': 'received and compared quotes from',
      'order_placement': 'placed order with'
    };

    const typeStr = typeof communicationType === 'string' ? communicationType : 'inquiry';

    await this.logInventoryActivity(
      'AI Supplier Communication',
      `Successfully ${actionText[typeStr] || 'contacted'} ${suppliersCount} supplier(s) for "${productName}"`,
      {
        'Product': productName,
        'Suppliers Contacted': suppliersCount,
        'Communication Type': typeStr.replace('_', ' ').toUpperCase(),
        'Suppliers': Array.isArray(supplierNames) ? supplierNames.join(', ') : supplierNames
      },
      'info'
    );
  }

  /**
   * Log supplier inquiry with generated message
   */
  async logSupplierInquiry(productName, supplierName, generatedMessage, isAI = true) {
    const messagePreview = generatedMessage.length > 200 
      ? generatedMessage.substring(0, 200) + '...' 
      : generatedMessage;

    await this.logInventoryActivity(
      'Supplier Inquiry Sent',
      `${isAI ? 'AI-generated' : 'Template-based'} inquiry sent to ${supplierName}`,
      {
        'Product': productName,
        'Supplier': supplierName,
        'Method': isAI ? 'AI Generated' : 'Template Fallback',
        'Message Preview': messagePreview
      },
      'info'
    );
  }

  /**
   * Log quote comparison and selection
   */
  async logQuoteComparison(productName, quotes, selectedSupplier, totalCost) {
    const quotesSummary = quotes.map(q => 
      `${q.supplierName}: $${q.totalPrice.toFixed(2)} (${q.deliveryDays} days)`
    ).join('\n');

    await this.logInventoryActivity(
      'Quote Comparison Complete',
      `AI analyzed ${quotes.length} quotes and selected best supplier for "${productName}"`,
      {
        'Product': productName,
        'Quotes Received': quotes.length,
        'Selected Supplier': selectedSupplier,
        'Total Cost': `$${totalCost.toFixed(2)}`,
        'All Quotes': quotesSummary
      },
      'success'
    );
  }

  /**
   * Log successful order placement
   */
  async logOrderPlacement(productName, supplierName, quantity, totalCost, deliveryDays, orderId) {
    await this.logInventoryActivity(
      'Order Placed Successfully',
      `Automatic order placed for "${productName}" with ${supplierName}`,
      {
        'Product': productName,
        'Supplier': supplierName,
        'Quantity': `${quantity} units`,
        'Total Cost': `$${totalCost.toFixed(2)}`,
        'Expected Delivery': `${deliveryDays} business days`,
        'Order ID': orderId || 'Generated',
        'Status': 'Order confirmation sent to supplier'
      },
      'success'
    );
  }

  /**
   * Get or create a product-specific chat session
   */
  async getProductChatSession(productName) {
    try {
      // Get admin user(s)
      const [adminUsers] = await this.dbConnection.execute(`
        SELECT id FROM users WHERE role = 'admin' LIMIT 1
      `);

      if (adminUsers.length === 0) {
        console.error('❌ No admin user found for product chat session');
        return null;
      }

      const adminUserId = adminUsers[0].id;
      const sessionTitle = `Inventory Alert: ${productName}`;

      // Check if product-specific session already exists
      const [existingSessions] = await this.dbConnection.execute(`
        SELECT id FROM chat_sessions 
        WHERE user_id = ? AND title = ?
        LIMIT 1
      `, [adminUserId, sessionTitle]);

      if (existingSessions.length > 0) {
        return existingSessions[0].id;
      }

      // Create new product-specific session
      const [result] = await this.dbConnection.execute(`
        INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)
      `, [adminUserId, sessionTitle]);

      console.log(`✓ Created new chat session: ${sessionTitle}`);
      return result.insertId;

    } catch (error) {
      console.error('❌ Error getting product chat session:', error);
      return null;
    }
  }

  /**
   * Log admin notification sent to product-specific chat
   */
  async logAdminNotification(notificationType, productName, notificationMethods, success) {
    try {
      // Get product-specific chat session
      const sessionId = await this.getProductChatSession(productName);
      if (!sessionId) {
        console.error('❌ Could not get product chat session');
        return;
      }

      // Get or create system user
      const [systemUsers] = await this.dbConnection.execute(`
        SELECT id FROM users WHERE username = 'system' LIMIT 1
      `);
      
      let systemUserId;
      if (systemUsers.length === 0) {
        // Create system user if it doesn't exist
        const [result] = await this.dbConnection.execute(`
          INSERT INTO users (username, email, password_hash, role, first_name, last_name)
          VALUES ('system', 'system@inventory.local', 'none', 'admin', 'Inventory', 'System')
        `);
        systemUserId = result.insertId;
      } else {
        systemUserId = systemUsers[0].id;
      }

      const methodsList = notificationMethods.join(', ');
      const timestamp = new Date().toLocaleString();

      // Format message for product-specific chat (no icons, text only)
      const formattedMessage = `**EMAIL NOTIFICATION SENT** [${timestamp}]\n\n` +
        `An email alert has been sent for ${productName}.\n\n` +
        `**Details:**\n` +
        `• Alert Type: ${notificationType}\n` +
        `• Email Status: ${success.email ? 'Sent Successfully' : 'Failed'}\n` +
        `• Recipient: ${process.env.EMAIL_USER || 'Admin'}\n` +
        `• Action: Immediate restocking recommended`;

      // Insert message into product-specific chat
      await this.dbConnection.execute(`
        INSERT INTO chat_messages (user_id, username, message, message_type, session_id)
        VALUES (?, ?, ?, ?, ?)
      `, [systemUserId, 'AI System', formattedMessage, 'system', sessionId]);

      // Update session timestamp
      await this.dbConnection.execute(`
        UPDATE chat_sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = ?
      `, [sessionId]);

      console.log(`📝 Logged email notification to product chat: ${productName}`);

    } catch (error) {
      console.error('❌ Error logging admin notification:', error);
    }
  }

  /**
   * Log system errors
   */
  async logError(errorType, errorMessage, context = null) {
    await this.logInventoryActivity(
      `System Error - ${errorType}`,
      `An error occurred in the inventory management system: ${errorMessage}`,
      context ? {
        'Error Context': JSON.stringify(context, null, 2)
      } : null,
      'error'
    );
  }

  /**
   * Log system status updates
   */
  async logSystemStatus(status, message, details = null) {
    await this.logInventoryActivity(
      'System Status Update',
      message,
      details,
      status === 'operational' ? 'success' : 'warning'
    );
  }

  /**
   * Log monitoring cycle start/end
   */
  async logMonitoringCycle(isStart, lowStockCount = 0) {
    if (isStart) {
      await this.logInventoryActivity(
        'Monitoring Cycle Started',
        'AI inventory monitoring system started checking stock levels',
        {
          'Status': 'Active monitoring enabled',
          'Check Interval': '30 minutes',
          'Time Started': new Date().toLocaleString()
        },
        'info'
      );
    } else {
      await this.logInventoryActivity(
        'Monitoring Cycle Complete',
        `Inventory check completed. Found ${lowStockCount} product(s) below threshold`,
        {
          'Products Processed': 'All inventory items scanned',
          'Low Stock Items': lowStockCount,
          'Action Taken': lowStockCount > 0 ? 'Automated reorder initiated' : 'No action required',
          'Next Check': 'In 30 minutes'
        },
        lowStockCount > 0 ? 'warning' : 'success'
      );
    }
  }

  /**
   * Close database connection
   */
  async close() {
    if (this.dbConnection) {
      await this.dbConnection.end();
      console.log('📡 ChatIntegrationService database connection closed');
    }
  }
}

module.exports = ChatIntegrationService;