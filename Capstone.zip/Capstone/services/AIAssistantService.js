require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { HfInference } = require('@huggingface/inference');
const OpenAI = require('openai');
const mysql = require('mysql2/promise');
const ChatIntegrationService = require('./ChatIntegrationService');

class AIAssistantService {
  constructor() {
    this.googleAI = null;
    this.huggingFaceAI = null;
    this.openAI = null;
    this.dbConnection = null;
    this.chatIntegrationService = null;
    this.currentProvider = 'google'; // Default provider
    this.init();
  }

  async init() {
    try {
      // Initialize database connection
      this.dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306
      });

      // Initialize Google Gemini (free tier available)
      if (process.env.GEMINI_API_KEY) {
        this.googleAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        console.log('✓ Google Gemini AI initialized');
      } else {
        console.log('⚠️ Google Gemini API key not found');
      }

      // Initialize Hugging Face (free tier available)
      if (process.env.HUGGINGFACE_API_KEY) {
        this.huggingFaceAI = new HfInference(process.env.HUGGINGFACE_API_KEY);
        console.log('✓ Hugging Face AI initialized');
      } else {
        console.log('⚠️ Hugging Face API key not found');
      }

      // Initialize OpenAI compatible service
      if (process.env.OPENAI_API_KEY || process.env.HUGGINGFACE_API_KEY) {
        this.openAI = new OpenAI({
          apiKey: process.env.OPENAI_API_KEY || process.env.HUGGINGFACE_API_KEY,
          baseURL: process.env.OPENAI_BASE_URL || 'https://router.huggingface.co/v1'
        });
        console.log('✓ OpenAI compatible service initialized');
      }

      console.log('✅ AI Assistant Service initialized successfully');
      
      // Initialize ChatIntegrationService
      this.chatIntegrationService = new ChatIntegrationService();
      console.log('✅ Chat Integration Service initialized');
      
    } catch (error) {
      console.error('❌ Error initializing AI Assistant Service:', error);
    }
  }

  /**
   * Generate supplier communication using AI
   */
  async generateSupplierMessage(messageType, context) {
    const prompts = {
      stock_inquiry: `
You are a professional procurement assistant for a business. Write a polite, professional email to inquire about product availability and pricing.

Context:
- Product: ${context.productName}
- Current stock: ${context.currentStock} units
- Required quantity: ${context.requiredQuantity} units
- Supplier: ${context.supplierName}
- Company: ${context.companyName}

Write a concise business email that:
1. Introduces our company briefly
2. Inquires about availability of the specified quantity
3. Requests current pricing and delivery timeline
4. Asks about minimum order quantities
5. Provides contact information for follow-up

Keep it professional and to the point.
      `,
      
      price_comparison: `
You are analyzing supplier quotes. Compare the following quotes and provide a recommendation.

Context:
- Product: ${context.productName}
- Required quantity: ${context.requiredQuantity} units

Quotes received:
${context.quotes ? context.quotes.map((quote, i) => `
Supplier ${i + 1}: ${quote.supplierName}
- Unit price: $${quote.unitPrice}
- Total: $${quote.totalPrice}
- Delivery: ${quote.deliveryDays} days
- Minimum order: ${quote.minOrder} units
`).join('\n') : 'No quotes available'}

Provide a brief analysis considering:
1. Best value for money
2. Delivery timeline
3. Supplier reliability (if known)
4. Recommend the best option with reasoning
      `,

      order_placement: `
You are placing an order with a supplier. Write a professional purchase order email.

Context:
- Product: ${context.productName}
- Quantity: ${context.quantity} units
- Unit price: $${context.unitPrice}
- Total amount: $${context.totalAmount}
- Supplier: ${context.supplierName}
- Delivery address: ${context.deliveryAddress}
- Expected delivery: ${context.expectedDelivery}

Write a formal purchase order email that includes:
1. Purchase order number
2. Detailed order specification
3. Pricing confirmation
4. Delivery instructions
5. Payment terms
6. Contact information for coordination
      `,

      payment_notification: `
You are notifying a supplier about payment processing. Write a professional payment confirmation email.

Context:
- Purchase order: ${context.poNumber}
- Amount: $${context.amount}
- Payment method: ${context.paymentMethod}
- Supplier: ${context.supplierName}
- Expected delivery: ${context.expectedDelivery}

Write a brief email confirming:
1. Payment has been processed
2. Order details
3. Delivery expectations
4. Contact for any questions
      `
    };

    const prompt = prompts[messageType];
    if (!prompt) {
      throw new Error(`Unknown message type: ${messageType}`);
    }

    try {
      // Try providers in order of preference
      const providers = ['google', 'huggingface', 'openai'];
      
      for (const provider of providers) {
        try {
          const message = await this.generateWithProvider(provider, prompt);
          if (message) {
            console.log(`✓ Generated message using ${provider}`);
            return {
              success: true,
              message: message,
              provider: provider,
              timestamp: new Date().toISOString()
            };
          }
        } catch (providerError) {
          console.log(`⚠️ ${provider} failed, trying next provider...`);
          continue;
        }
      }

      throw new Error('All AI providers failed');
    } catch (error) {
      console.error('❌ Error generating supplier message:', error);
      return {
        success: false,
        error: error.message,
        fallbackMessage: this.getFallbackMessage(messageType, context)
      };
    }
  }

  /**
   * Generate message using specific provider
   */
  async generateWithProvider(provider, prompt) {
    switch (provider) {
      case 'google':
        if (!this.googleAI) return null;
        return await this.generateWithGoogle(prompt);
        
      case 'huggingface':
        if (!this.huggingFaceAI) return null;
        return await this.generateWithHuggingFace(prompt);
        
      case 'openai':
        if (!this.openAI) return null;
        return await this.generateWithOpenAI(prompt);
        
      default:
        throw new Error(`Unknown provider: ${provider}`);
    }
  }

  /**
   * Generate using Google Gemini
   */
  async generateWithGoogle(prompt) {
    const model = this.googleAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  }

  /**
   * Generate using Hugging Face
   */
  async generateWithHuggingFace(prompt) {
    const response = await this.huggingFaceAI.chatCompletion({
      model: "microsoft/DialoGPT-medium",
      messages: [
        { role: "system", content: "You are a professional business communication assistant." },
        { role: "user", content: prompt }
      ],
      max_tokens: 500
    });
    
    return response.choices[0].message.content;
  }

  /**
   * Generate using OpenAI compatible API
   */
  async generateWithOpenAI(prompt) {
    const response = await this.openAI.chat.completions.create({
      model: "meta-llama/Llama-3.1-8B-Instruct",
      messages: [
        { role: "system", content: "You are a professional business communication assistant." },
        { role: "user", content: prompt }
      ],
      max_tokens: 500
    });
    
    return response.choices[0].message.content;
  }

  /**
   * Provide fallback templates when AI fails
   */
  getFallbackMessage(messageType, context) {
    const templates = {
      stock_inquiry: `
Subject: Product Inquiry - ${context.productName}

Dear ${context.supplierName} Team,

I hope this email finds you well. I am writing on behalf of ${context.companyName} to inquire about the availability and pricing of the following product:

Product: ${context.productName}
Required Quantity: ${context.requiredQuantity} units

We are currently running low on stock (${context.currentStock} units remaining) and would like to place an order as soon as possible.

Could you please provide:
1. Current availability for the requested quantity
2. Unit pricing and total cost
3. Estimated delivery timeline
4. Minimum order requirements

Please feel free to contact us if you need any additional information.

Best regards,
Procurement Team
${context.companyName}
      `,
      
      order_placement: `
Subject: Purchase Order - ${context.productName}

Dear ${context.supplierName} Team,

Please consider this email as our official purchase order for the following:

Purchase Order #: PO-${Date.now()}
Product: ${context.productName}
Quantity: ${context.quantity} units
Unit Price: $${context.unitPrice}
Total Amount: $${context.totalAmount}

Delivery Address: ${context.deliveryAddress}
Expected Delivery: ${context.expectedDelivery}

Please confirm receipt of this order and provide estimated delivery date.

Best regards,
Procurement Team
      `
    };
    
    return templates[messageType] || 'Template message not available.';
  }

  /**
   * Log AI conversation to database
   */
  async logConversation(reorderLogId, messageType, context, aiResponse) {
    try {
      const conversationLog = {
        messageType,
        context,
        aiResponse,
        timestamp: new Date().toISOString()
      };

      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET ai_conversation_log = COALESCE(ai_conversation_log, '') + ? 
        WHERE id = ?
      `, [JSON.stringify(conversationLog) + '\n', reorderLogId]);

      console.log(`✓ Conversation logged for reorder ${reorderLogId}`);
    } catch (error) {
      console.error('❌ Error logging conversation:', error);
    }
  }

  /**
   * Process supplier communication workflow
   */
  async processSupplierCommunication(reorderLogId, productInfo, suppliers) {
    try {
      console.log(`🤖 Starting AI supplier communication for reorder ${reorderLogId}`);

      // Step 1: Generate stock inquiry messages for all suppliers
      const inquiries = [];
      for (const supplier of suppliers) {
        const context = {
          productName: productInfo.name,
          currentStock: productInfo.currentStock,
          requiredQuantity: productInfo.reorderQuantity,
          supplierName: supplier.name,
          companyName: process.env.COMPANY_NAME || 'Your Company'
        };

        const inquiry = await this.generateSupplierMessage('stock_inquiry', context);
        inquiries.push({
          supplier: supplier,
          inquiry: inquiry,
          context: context
        });

        // Log each inquiry
        await this.logConversation(reorderLogId, 'stock_inquiry', context, inquiry);
      }

      // Update reorder log status
      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET status = 'supplier_contacted',
            attempted_suppliers = ?
        WHERE id = ?
      `, [JSON.stringify(suppliers.map(s => s.id)), reorderLogId]);

      console.log(`📧 Generated ${inquiries.length} supplier inquiries`);
      
      // TODO: In a real implementation, these would be sent as emails
      // For now, we'll simulate the process and return the generated messages
      
      return {
        success: true,
        inquiriesSent: inquiries.length,
        inquiries: inquiries,
        nextStep: 'await_quotes'
      };

    } catch (error) {
      console.error('❌ Error in supplier communication workflow:', error);
      
      // Update reorder log status to failed
      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET status = 'failed',
            ai_conversation_log = COALESCE(ai_conversation_log, '') + ?
        WHERE id = ?
      `, [`ERROR: ${error.message}\n`, reorderLogId]);

      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Simulate quote comparison and selection
   */
  async processQuoteComparison(reorderLogId, quotes) {
    try {
      const context = {
        productName: quotes[0].productName,
        requiredQuantity: quotes[0].quantity,
        quotes: quotes
      };

      const comparison = await this.generateSupplierMessage('price_comparison', context);
      await this.logConversation(reorderLogId, 'price_comparison', context, comparison);

      // Select best quote (simple logic - lowest total price with reasonable delivery)
      const bestQuote = quotes.reduce((best, current) => {
        if (current.deliveryDays <= 14 && current.totalPrice < best.totalPrice) {
          return current;
        }
        return best;
      });

      console.log(`💰 Best quote selected: ${bestQuote.supplierName} - $${bestQuote.totalPrice}`);
      
      return {
        success: true,
        bestQuote,
        comparison: comparison,
        nextStep: 'place_order'
      };

    } catch (error) {
      console.error('❌ Error in quote comparison:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Close database connection
   */
  async close() {
    if (this.dbConnection) {
      await this.dbConnection.end();
      console.log('📡 AI Assistant Service database connection closed');
    }
  }
}

module.exports = AIAssistantService;