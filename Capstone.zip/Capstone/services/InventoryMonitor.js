require('dotenv').config();
const mysql = require('mysql2/promise');
const NotificationService = require('./NotificationService');
const AIAssistantService = require('./AIAssistantService');
const ChatIntegrationService = require('./ChatIntegrationService');

class InventoryMonitor {
  constructor() {
    this.dbConnection = null;
    this.notificationService = null;
    this.aiAssistantService = null;
    this.chatIntegrationService = null;
    this.monitoringInterval = null;
    this.isRunning = false;
    this.init();
  }

  async init() {
    try {
      // Initialize database connection
      this.dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306
      });

      // Initialize all services
      this.notificationService = new NotificationService();
      this.aiAssistantService = new AIAssistantService();
      this.chatIntegrationService = new ChatIntegrationService();
      
      // Wait for services to initialize
      await new Promise(resolve => setTimeout(resolve, 2000));

      console.log('✓ InventoryMonitor initialized successfully');
    } catch (error) {
      console.error('❌ Error initializing InventoryMonitor:', error);
      throw error;
    }
  }

  /**
   * Check all products for low stock and trigger notifications
   */
  async checkInventoryLevels() {
    try {
      console.log('🔍 Checking inventory levels...');

      // Log monitoring cycle start to chat
      await this.chatIntegrationService.logMonitoringCycle(true);

      // Query products with their thresholds and current stock
      const [lowStockProducts] = await this.dbConnection.execute(`
        SELECT 
          p.id,
          p.name,
          p.quantity as current_stock,
          rt.minimum_stock,
          rt.reorder_quantity,
          rt.auto_reorder_enabled
        FROM products p
        JOIN reorder_thresholds rt ON p.id = rt.product_id
        WHERE p.quantity <= rt.minimum_stock 
          AND rt.auto_reorder_enabled = TRUE
          AND NOT EXISTS (
            SELECT 1 FROM reorder_logs rl 
            WHERE rl.product_id = p.id 
              AND rl.status IN ('threshold_detected', 'admin_notified', 'supplier_contacted')
              AND rl.created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
          )
      `);

      console.log(`📊 Found ${lowStockProducts.length} products below threshold`);

      for (const product of lowStockProducts) {
        await this.handleLowStockProduct(product);
      }

      // Log monitoring cycle completion to chat
      await this.chatIntegrationService.logMonitoringCycle(false, lowStockProducts.length);

      return lowStockProducts.length;
    } catch (error) {
      console.error('❌ Error checking inventory levels:', error);
      
      // Log error to chat
      await this.chatIntegrationService.logError(
        'Inventory Check Failed',
        error.message,
        { function: 'checkInventoryLevels', timestamp: new Date().toISOString() }
      );
      
      throw error;
    }
  }

  /**
   * Handle a single low stock product
   */
  async handleLowStockProduct(product) {
    try {
      console.log(`⚠️ Processing low stock alert for: ${product.name}`);
      console.log(`   Current stock: ${product.current_stock}, Threshold: ${product.minimum_stock}`);

      // Log low stock detection to chat
      await this.chatIntegrationService.logLowStockDetection(
        product.name,
        product.current_stock,
        product.minimum_stock,
        product.reorder_quantity
      );

      // Create reorder log entry
      const [reorderResult] = await this.dbConnection.execute(`
        INSERT INTO reorder_logs (
          product_id, 
          current_stock,
          threshold_triggered,
          status,
          ai_conversation_log
        ) VALUES (?, ?, ?, ?, ?)
      `, [
        product.id,
        product.current_stock,
        product.minimum_stock,
        'threshold_detected',
        `Automatic threshold detection: ${product.current_stock} <= ${product.minimum_stock}`
      ]);

      const reorderLogId = reorderResult.insertId;
      console.log(`📝 Created reorder log ID: ${reorderLogId}`);

      // Get available suppliers for this product
      const [suppliers] = await this.dbConnection.execute(`
        SELECT s.*, sp.unit_price, sp.minimum_order_quantity, sp.lead_time_days
        FROM suppliers s
        JOIN supplier_products sp ON s.id = sp.supplier_id
        WHERE sp.product_name = ? AND sp.is_available = TRUE
        ORDER BY sp.unit_price ASC
        LIMIT 3
      `, [product.name]);

      const preferredSupplier = suppliers.length > 0 ? suppliers[0] : null;

      // Get all admin users to notify
      const [adminUsers] = await this.dbConnection.execute(`
        SELECT id, username, email, phone, first_name, last_name 
        FROM users 
        WHERE role = 'admin'
      `);

      console.log(`👥 Found ${adminUsers.length} admin users to notify`);

      // Send notifications to all admins
      for (const admin of adminUsers) {
        const supplierInfo = preferredSupplier ? {
          name: preferredSupplier.name,
          email: preferredSupplier.email,
          phone: preferredSupplier.phone
        } : null;

        try {
          const notificationResult = await this.notificationService.sendLowStockNotification(
            admin.id,
            product.name,
            product.current_stock,
            product.minimum_stock,
            supplierInfo
          );

          console.log(`📧 Notification sent to ${admin.username} (${admin.email})`);
          console.log(`   Email: ${notificationResult.email.success ? '✓' : '✗'}`);
          console.log(`   SMS: ${notificationResult.sms.success ? '✓' : '✗'}`);

          // Log admin notification to chat
          await this.chatIntegrationService.logAdminNotification(
            'Low Stock Alert',
            product.name,
            ['email', 'sms', 'in-app'],
            {
              email: notificationResult.email.success,
              sms: notificationResult.sms.success
            }
          );
          // Update reorder log to indicate admin notification sent
          await this.dbConnection.execute(`
            UPDATE reorder_logs 
            SET status = 'admin_notified',
                admin_notification_sent = TRUE,
                admin_notification_timestamp = CURRENT_TIMESTAMP
            WHERE id = ?
          `, [reorderLogId]);

        } catch (notificationError) {
          console.error(`❌ Error notifying admin ${admin.username}:`, notificationError);
          
          // Log notification error to chat
          await this.chatIntegrationService.logError(
            'Admin Notification Failed',
            `Failed to notify admin ${admin.username}: ${notificationError.message}`,
            { product: product.name, admin: admin.username }
          );
        }
      }

      // Schedule automatic ordering (this will be implemented with Chatling AI)
      await this.scheduleAutomaticReorder(reorderLogId, product, preferredSupplier);

    } catch (error) {
      console.error(`❌ Error handling low stock product ${product.name}:`, error);
      
      // Log error to chat
      await this.chatIntegrationService.logError(
        'Low Stock Processing Failed',
        `Error processing low stock for ${product.name}: ${error.message}`,
        { product: product.name, error: error.message }
      );
    }
  }

  /**
   * Schedule automatic reorder process with AI assistance
   */
  async scheduleAutomaticReorder(reorderLogId, product, preferredSupplier = null) {
    try {
      console.log(`🤖 Starting AI-powered automatic reorder for: ${product.name}`);
      
      // Log automatic reorder start to chat
      await this.chatIntegrationService.logInventoryActivity(
        'Automatic Reorder Started',
        `Beginning AI-powered reorder process for ${product.name}`,
        { 
          product: product.name, 
          reorderLogId,
          currentStock: product.current_stock,
          reorderQuantity: product.reorder_quantity
        }
      );
      
      // Update reorder log to indicate auto-order process started
      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET auto_order_started = TRUE,
            auto_order_timestamp = CURRENT_TIMESTAMP,
            status = 'supplier_contacted'
        WHERE id = ?
      `, [reorderLogId]);

      // Get available suppliers for this product
      const suppliers = await this.getAvailableSuppliers(product.name);
      
      if (suppliers.length === 0) {
        console.log('⚠️ No suppliers available for this product');
        
        // Log no suppliers error to chat
        await this.chatIntegrationService.logError(
          'No Suppliers Available',
          `No suppliers found for ${product.name}`,
          { product: product.name, reorderLogId }
        );
        
        await this.dbConnection.execute(`
          UPDATE reorder_logs 
          SET status = 'failed',
              ai_conversation_log = COALESCE(ai_conversation_log, '') + ?
          WHERE id = ?
        `, ['ERROR: No suppliers available for this product\n', reorderLogId]);
        return;
      }

      console.log(`� Found ${suppliers.length} suppliers for ${product.name}`);

      // Use AI assistant to process supplier communication
      const productInfo = {
        name: product.name,
        currentStock: product.current_stock,
        reorderQuantity: product.reorder_quantity
      };

      const communicationResult = await this.aiAssistantService.processSupplierCommunication(
        reorderLogId,
        productInfo,
        suppliers
      );

      if (communicationResult.success) {
        console.log(`✅ AI supplier communication completed for ${product.name}`);
        console.log(`📧 Sent inquiries to ${communicationResult.inquiriesSent} suppliers`);
        
        // Log successful supplier communication to chat
        await this.chatIntegrationService.logSupplierCommunication(
          product.name,
          suppliers.map(s => s.name),
          communicationResult.inquiriesSent,
          'inquiry'
        );
        
        // Simulate waiting for quotes (in a real system, this would be handled by email responses)
        setTimeout(async () => {
          await this.processSimulatedQuotes(reorderLogId, product, suppliers);
        }, 5000); // Wait 5 seconds to simulate quote response time
        
      } else {
        console.error(`❌ AI supplier communication failed: ${communicationResult.error}`);
        
        // Log failed supplier communication to chat
        await this.chatIntegrationService.logError(
          'Supplier Communication Failed',
          `AI communication failed for ${product.name}: ${communicationResult.error}`,
          { product: product.name, reorderLogId }
        );
        
        await this.dbConnection.execute(`
          UPDATE reorder_logs 
          SET status = 'failed'
          WHERE id = ?
        `, [reorderLogId]);
      }

    } catch (error) {
      console.error(`❌ Error in automatic reorder process:`, error);
      
      // Log reorder process error to chat
      await this.chatIntegrationService.logError(
        'Reorder Process Failed',
        `Automatic reorder process failed for product: ${error.message}`,
        { product: product.name, reorderLogId, error: error.message }
      );
      
      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET status = 'failed',
            ai_conversation_log = COALESCE(ai_conversation_log, '') + ?
        WHERE id = ?
      `, [`ERROR: ${error.message}\n`, reorderLogId]);
    }
  }

  /**
   * Get available suppliers for a product
   */
  async getAvailableSuppliers(productName) {
    try {
      // Get suppliers that have this product in their catalog
      const [supplierRows] = await this.dbConnection.execute(`
        SELECT DISTINCT s.id, s.name, s.email, s.phone
        FROM suppliers s
        LEFT JOIN supplier_products sp ON s.id = sp.supplier_id
        WHERE sp.product_name LIKE ? OR sp.product_name IS NULL
        ORDER BY s.name
      `, [`%${productName}%`]);

      // If no specific supplier products found, return all suppliers
      if (supplierRows.length === 0) {
        const [allSuppliers] = await this.dbConnection.execute(`
          SELECT id, name, email, phone FROM suppliers ORDER BY name
        `);
        return allSuppliers;
      }

      return supplierRows;
    } catch (error) {
      console.error('❌ Error getting suppliers:', error);
      return [];
    }
  }

  /**
   * Process simulated quotes from suppliers
   */
  async processSimulatedQuotes(reorderLogId, product, suppliers) {
    try {
      console.log(`💰 Processing simulated quotes for ${product.name}...`);
      
      // Log quote processing start to chat
      await this.chatIntegrationService.logInventoryActivity(
        'Quote Processing Started',
        `Processing quotes from ${suppliers.length} suppliers for ${product.name}`,
        { 
          product: product.name, 
          supplierCount: suppliers.length,
          reorderLogId 
        }
      );

      // Generate simulated quotes
      const quotes = suppliers.map((supplier, index) => ({
        supplierName: supplier.name,
        supplierId: supplier.id,
        productName: product.name,
        quantity: product.reorder_quantity,
        unitPrice: 10 + (index * 0.5) + (Math.random() * 2), // Varied pricing
        totalPrice: (10 + (index * 0.5) + (Math.random() * 2)) * product.reorder_quantity,
        deliveryDays: 5 + (index * 2) + Math.floor(Math.random() * 3), // Varied delivery times
        minOrder: Math.max(20, product.reorder_quantity - 10)
      }));

      // Use AI to compare quotes
      const comparisonResult = await this.aiAssistantService.processQuoteComparison(reorderLogId, quotes);

      if (comparisonResult.success) {
        const bestQuote = comparisonResult.bestQuote;
        console.log(`🏆 Best quote: ${bestQuote.supplierName} - $${bestQuote.totalPrice.toFixed(2)}`);

        // Log quote comparison result to chat
        await this.chatIntegrationService.logQuoteComparison(
          product.name,
          quotes.map(q => ({
            supplier: q.supplierName,
            price: q.totalPrice,
            delivery: `${q.deliveryDays} days`
          })),
          bestQuote.supplierName,
          bestQuote.totalPrice
        );

        // Place order with best supplier
        await this.placeAutomaticOrder(reorderLogId, bestQuote, product);
      } else {
        console.error('❌ Failed to compare quotes:', comparisonResult.error);
        
        // Log quote comparison error to chat
        await this.chatIntegrationService.logError(
          'Quote Comparison Failed',
          `Failed to compare quotes for ${product.name}: ${comparisonResult.error}`,
          { product: product.name, reorderLogId }
        );
        
        await this.dbConnection.execute(`
          UPDATE reorder_logs SET status = 'failed' WHERE id = ?
        `, [reorderLogId]);
      }

    } catch (error) {
      console.error('❌ Error processing quotes:', error);
      
      // Log quote processing error to chat
      await this.chatIntegrationService.logError(
        'Quote Processing Failed',
        `Error processing quotes for ${product.name}: ${error.message}`,
        { product: product.name, reorderLogId, error: error.message }
      );
      
      await this.dbConnection.execute(`
        UPDATE reorder_logs SET status = 'failed' WHERE id = ?
      `, [reorderLogId]);
    }
  }

  /**
   * Place automatic order with selected supplier
   */
  async placeAutomaticOrder(reorderLogId, quote, product) {
    try {
      console.log(`📋 Placing automatic order with ${quote.supplierName}...`);

      // Log order placement start to chat
      await this.chatIntegrationService.logInventoryActivity(
        'Order Placement Started',
        `Placing order with ${quote.supplierName} for ${quote.quantity} units of ${product.name}`,
        { 
          product: product.name,
          supplier: quote.supplierName,
          quantity: quote.quantity,
          totalPrice: quote.totalPrice,
          reorderLogId 
        }
      );

      // Generate order placement message using AI
      const orderContext = {
        productName: quote.productName,
        quantity: quote.quantity,
        unitPrice: quote.unitPrice.toFixed(2),
        totalAmount: quote.totalPrice.toFixed(2),
        supplierName: quote.supplierName,
        deliveryAddress: process.env.COMPANY_ADDRESS || '123 Business Street, City, State 12345',
        expectedDelivery: `${quote.deliveryDays} business days`
      };

      const orderMessage = await this.aiAssistantService.generateSupplierMessage('order_placement', orderContext);
      
      // Log the order
      await this.aiAssistantService.logConversation(reorderLogId, 'order_placement', orderContext, orderMessage);

      // Log order placement to chat
      await this.chatIntegrationService.logOrderPlacement(
        product.name,
        quote.supplierName,
        quote.quantity,
        quote.totalPrice,
        orderMessage
      );

      // Update reorder log with order details
      const orderDetails = {
        supplier_id: quote.supplierId,
        unit_price: quote.unitPrice,
        total_cost: quote.totalPrice,
        quantity: quote.quantity,
        expected_delivery_days: quote.deliveryDays
      };

      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET status = 'order_placed',
            supplier_id = ?,
            total_cost = ?,
            order_details = ?,
            expected_delivery_date = DATE_ADD(CURRENT_DATE, INTERVAL ? DAY)
        WHERE id = ?
      `, [
        quote.supplierId,
        quote.totalPrice,
        JSON.stringify(orderDetails),
        quote.deliveryDays,
        reorderLogId
      ]);

      console.log(`✅ Order placed successfully for ${product.name}`);
      console.log(`📦 Expected delivery: ${quote.deliveryDays} days`);
      console.log(`💰 Total cost: $${quote.totalPrice.toFixed(2)}`);

      // Log successful order placement to chat
      await this.chatIntegrationService.logOrderPlacement(
        product.name,
        quote.supplierName,
        quote.quantity,
        quote.totalPrice,
        `${quote.deliveryDays} days`,
        'completed'
      );

      // Send final notification to admin about order placement
      await this.sendOrderNotification(reorderLogId, product.name, quote);

    } catch (error) {
      console.error('❌ Error placing automatic order:', error);
      
      // Log order placement error to chat
      await this.chatIntegrationService.logError(
        'Order Placement Failed',
        `Failed to place order for ${product.name}: ${error.message}`,
        { 
          product: product.name, 
          supplier: quote.supplierName, 
          reorderLogId,
          error: error.message 
        }
      );
      
      await this.dbConnection.execute(`
        UPDATE reorder_logs SET status = 'failed' WHERE id = ?
      `, [reorderLogId]);
    }
  }

  /**
   * Send notification about order placement
   */
  async sendOrderNotification(reorderLogId, productName, quote) {
    try {
      // Get admin users
      const [adminUsers] = await this.dbConnection.execute(`
        SELECT id FROM users WHERE role = 'admin'
      `);

      let successCount = 0;
      let failCount = 0;

      for (const admin of adminUsers) {
        try {
          await this.notificationService.createNotification({
            userId: admin.id,
            type: 'reorder_completed',
            title: `Order Placed: ${productName}`,
            message: `Automatic order has been placed with ${quote.supplierName} for ${quote.quantity} units of ${productName}. Total cost: $${quote.totalPrice.toFixed(2)}. Expected delivery: ${quote.deliveryDays} days.`,
            reorderLogId: reorderLogId,
            priority: 'medium',
            methods: ['email', 'in_app']
          });
          successCount++;
        } catch (adminError) {
          failCount++;
          console.error(`❌ Failed to notify admin ${admin.id}:`, adminError);
        }
      }

      console.log('📧 Order confirmation notifications sent to admins');

      // Log order notification result to chat
      await this.chatIntegrationService.logAdminNotification(
        'Order Confirmation',
        productName,
        ['email', 'in-app'],
        { success: successCount > 0, failureCount: failCount },
        `Order placed with ${quote.supplierName} for $${quote.totalPrice.toFixed(2)}`
      );

    } catch (error) {
      console.error('❌ Error sending order notification:', error);
      
      // Log order notification error to chat
      await this.chatIntegrationService.logError(
        'Order Notification Failed',
        `Failed to send order confirmation notifications: ${error.message}`,
        { product: productName, supplier: quote.supplierName, reorderLogId }
      );
    }
  }

  /**
   * Start continuous monitoring
   */
  startMonitoring(intervalMinutes = 30) {
    if (this.isRunning) {
      console.log('⚠️ Monitoring is already running');
      return;
    }

    console.log(`🚀 Starting inventory monitoring (checking every ${intervalMinutes} minutes)`);
    
    this.isRunning = true;

    // Run initial check
    this.checkInventoryLevels().catch(console.error);

    // Set up periodic monitoring
    this.monitoringInterval = setInterval(() => {
      if (this.isRunning) {
        this.checkInventoryLevels().catch(console.error);
      }
    }, intervalMinutes * 60 * 1000);
  }

  /**
   * Stop monitoring
   */
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    this.isRunning = false;
    console.log('🛑 Inventory monitoring stopped');
  }

  /**
   * Get monitoring status
   */
  getStatus() {
    return {
      isRunning: this.isRunning,
      intervalId: this.monitoringInterval ? 'active' : null
    };
  }

  /**
   * Manual trigger for testing
   */
  async runSingleCheck() {
    console.log('🔧 Running manual inventory check...');
    const lowStockCount = await this.checkInventoryLevels();
    console.log(`✅ Manual check completed. Found ${lowStockCount} low stock items.`);
    return lowStockCount;
  }

  /**
   * Get recent reorder logs
   */
  async getRecentReorderLogs(limit = 10) {
    try {
      const [logs] = await this.dbConnection.execute(`
        SELECT 
          rl.*,
          p.name as product_name,
          s.name as supplier_name
        FROM reorder_logs rl
        JOIN products p ON rl.product_id = p.id
        LEFT JOIN suppliers s ON rl.supplier_id = s.id
        ORDER BY rl.created_at DESC
        LIMIT ?
      `, [parseInt(limit)]);

      return logs;
    } catch (error) {
      console.error('❌ Error fetching reorder logs:', error);
      throw error;
    }
  }

  /**
   * Close connections and cleanup
   */
  async close() {
    this.stopMonitoring();
    
    if (this.notificationService) {
      await this.notificationService.close();
    }
    
    if (this.aiAssistantService) {
      await this.aiAssistantService.close();
    }
    
    if (this.dbConnection) {
      await this.dbConnection.end();
      console.log('📡 InventoryMonitor database connection closed');
    }
  }
}

module.exports = InventoryMonitor;