require('dotenv').config();
const axios = require('axios');
const mysql = require('mysql2/promise');

class ChatlingIntegration {
  constructor() {
    this.apiKey = process.env.CHATLING_API_KEY;
    this.agentId = process.env.CHATLING_AGENT_ID;
    this.baseURL = 'https://api.chatling.ai/v2';
    this.dbConnection = null;
    this.init();
  }

  async init() {
    try {
      // Initialize database connection
      this.dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306
      });

      console.log('✓ ChatlingIntegration initialized');
    } catch (error) {
      console.error('❌ Error initializing ChatlingIntegration:', error);
    }
  }

  /**
   * Contact suppliers for stock reorder using AI
   */
  async contactSuppliersForReorder(reorderLogId, productName, quantityNeeded, currentStock, threshold) {
    try {
      console.log(`🤖 AI starting supplier contact process for ${productName}...`);
      
      // Get available suppliers for this product
      const [suppliers] = await this.dbConnection.execute(`
        SELECT s.*, sp.unit_price, sp.minimum_order_quantity, sp.lead_time_days
        FROM suppliers s
        JOIN supplier_products sp ON s.id = sp.supplier_id
        WHERE sp.product_name = ? AND sp.is_available = TRUE
        ORDER BY sp.unit_price ASC
      `, [productName]);

      if (suppliers.length === 0) {
        console.log('❌ No suppliers found for this product');
        await this.updateReorderLog(reorderLogId, 'failed', 'No suppliers available');
        return { success: false, reason: 'No suppliers available' };
      }

      console.log(`📋 Found ${suppliers.length} available suppliers`);

      // Update reorder log to indicate supplier contact started
      await this.updateReorderLog(reorderLogId, 'supplier_contacted', null, suppliers.map(s => s.id));

      const results = [];

      // Contact each supplier (simulated AI conversation)
      for (const supplier of suppliers.slice(0, 3)) { // Limit to top 3 suppliers
        console.log(`📞 AI contacting ${supplier.name}...`);
        
        const supplierResult = await this.simulateSupplierContact(supplier, productName, quantityNeeded, reorderLogId);
        results.push({
          supplier: supplier.name,
          ...supplierResult
        });

        // Add delay between supplier contacts
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      // Evaluate responses and select best option
      const bestOffer = this.selectBestSupplierOffer(results);
      
      if (bestOffer.success) {
        console.log(`✅ Best offer selected from ${bestOffer.supplier}`);
        console.log(`💰 Price: $${bestOffer.totalCost} | Delivery: ${bestOffer.deliveryDate}`);
        
        // Place order with selected supplier
        await this.placeOrder(reorderLogId, bestOffer);
        
        return {
          success: true,
          selectedSupplier: bestOffer.supplier,
          totalCost: bestOffer.totalCost,
          deliveryDate: bestOffer.deliveryDate,
          supplierContacts: results.length
        };
      } else {
        await this.updateReorderLog(reorderLogId, 'failed', 'No suitable offers received');
        return {
          success: false,
          reason: 'No suitable offers received',
          supplierContacts: results.length
        };
      }

    } catch (error) {
      console.error('❌ Error in AI supplier contact process:', error);
      await this.updateReorderLog(reorderLogId, 'failed', error.message);
      throw error;
    }
  }

  /**
   * Simulate AI conversation with supplier
   */
  async simulateSupplierContact(supplier, productName, quantityNeeded, reorderLogId) {
    try {
      console.log(`💬 [AI SIMULATION] Starting conversation with ${supplier.name}`);
      
      // Simulate AI conversation log
      const conversationSteps = [
        `AI: Hello! I'm reaching out regarding an urgent reorder for ${productName}.`,
        `AI: We need ${quantityNeeded} units. Can you provide availability and pricing?`,
        `${supplier.name}: Hello! Yes, we have ${productName} in stock.`,
        `${supplier.name}: Current price: $${supplier.unit_price}/unit. Minimum order: ${supplier.minimum_order_quantity} units.`,
        `${supplier.name}: Lead time: ${supplier.lead_time_days} business days.`,
        `AI: Perfect! Can you confirm total cost and expected delivery date?`
      ];

      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Calculate pricing
      const actualQuantity = Math.max(quantityNeeded, supplier.minimum_order_quantity);
      const totalCost = (actualQuantity * supplier.unit_price).toFixed(2);
      const deliveryDate = this.calculateDeliveryDate(supplier.lead_time_days);

      // Simulate supplier response variations
      const isAvailable = Math.random() > 0.1; // 90% availability
      const priceVariation = (Math.random() - 0.5) * 0.1; // ±5% price variation
      const adjustedPrice = (supplier.unit_price * (1 + priceVariation)).toFixed(2);
      const adjustedTotalCost = (actualQuantity * adjustedPrice).toFixed(2);

      conversationSteps.push(
        `${supplier.name}: Total cost: $${adjustedTotalCost} for ${actualQuantity} units.`,
        `${supplier.name}: Expected delivery: ${deliveryDate}`
      );

      if (isAvailable) {
        conversationSteps.push(
          `${supplier.name}: Order confirmed! We'll prepare your shipment.`,
          `AI: Thank you! Order details saved for processing.`
        );
      } else {
        conversationSteps.push(
          `${supplier.name}: Sorry, we're currently out of stock for this quantity.`,
          `AI: Understood. Thank you for your time.`
        );
      }

      // Log conversation to database
      await this.logAIConversation(reorderLogId, supplier.id, conversationSteps);

      console.log(`✅ AI conversation completed with ${supplier.name}`);
      console.log(`   Available: ${isAvailable ? 'Yes' : 'No'} | Cost: $${adjustedTotalCost} | Delivery: ${deliveryDate}`);

      return {
        success: isAvailable,
        supplierId: supplier.id,
        unitPrice: parseFloat(adjustedPrice),
        totalCost: parseFloat(adjustedTotalCost),
        quantity: actualQuantity,
        deliveryDate: deliveryDate,
        conversationLog: conversationSteps.join('\n')
      };

    } catch (error) {
      console.error(`❌ Error in supplier contact simulation for ${supplier.name}:`, error);
      return {
        success: false,
        supplierId: supplier.id,
        error: error.message
      };
    }
  }

  /**
   * Select the best supplier offer based on criteria
   */
  selectBestSupplierOffer(offers) {
    const availableOffers = offers.filter(offer => offer.success);
    
    if (availableOffers.length === 0) {
      return { success: false, reason: 'No available offers' };
    }

    // Sort by price (ascending) and delivery time
    availableOffers.sort((a, b) => {
      const priceWeight = 0.7; // 70% weight on price
      const timeWeight = 0.3;  // 30% weight on delivery time
      
      const priceScore = (a.totalCost - b.totalCost) * priceWeight;
      const timeScore = (new Date(a.deliveryDate) - new Date(b.deliveryDate)) * timeWeight / (1000 * 60 * 60 * 24); // Convert to days
      
      return priceScore + timeScore;
    });

    return {
      success: true,
      ...availableOffers[0]
    };
  }

  /**
   * Place order with selected supplier
   */
  async placeOrder(reorderLogId, orderDetails) {
    try {
      console.log(`📋 Placing order with ${orderDetails.supplier}...`);
      
      // Update reorder log with order details
      const orderData = {
        supplier_id: orderDetails.supplierId,
        quantity: orderDetails.quantity,
        unit_price: orderDetails.unitPrice,
        total_cost: orderDetails.totalCost,
        expected_delivery_date: orderDetails.deliveryDate
      };

      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET status = 'order_placed',
            supplier_id = ?,
            order_details = ?,
            total_cost = ?,
            expected_delivery_date = ?
        WHERE id = ?
      `, [
        orderDetails.supplierId,
        JSON.stringify(orderData),
        orderDetails.totalCost,
        orderDetails.deliveryDate,
        reorderLogId
      ]);

      // Create pending order record
      await this.dbConnection.execute(`
        INSERT INTO pending_orders (
          reorder_log_id, supplier_id, product_id, quantity, unit_price, 
          total_cost, status, expected_delivery_date, order_placed_at
        ) 
        SELECT 
          ?, ?, product_id, ?, ?, ?, 'placed', ?, CURRENT_TIMESTAMP
        FROM reorder_logs WHERE id = ?
      `, [
        reorderLogId, orderDetails.supplierId, orderDetails.quantity,
        orderDetails.unitPrice, orderDetails.totalCost, 
        orderDetails.deliveryDate, reorderLogId
      ]);

      console.log(`✅ Order placed successfully with ${orderDetails.supplier}`);
      
      // Simulate order confirmation
      setTimeout(() => {
        this.simulateOrderConfirmation(reorderLogId);
      }, 5000); // Confirm after 5 seconds

    } catch (error) {
      console.error('❌ Error placing order:', error);
      throw error;
    }
  }

  /**
   * Simulate order confirmation from supplier
   */
  async simulateOrderConfirmation(reorderLogId) {
    try {
      await this.updateReorderLog(reorderLogId, 'completed', 'Order confirmed by supplier');
      console.log(`✅ Order confirmation received for reorder log ${reorderLogId}`);
    } catch (error) {
      console.error('❌ Error processing order confirmation:', error);
    }
  }

  /**
   * Update reorder log status and information
   */
  async updateReorderLog(reorderLogId, status, notes = null, supplierIds = null) {
    try {
      let query = 'UPDATE reorder_logs SET status = ?';
      const params = [status];

      if (notes) {
        query += ', ai_conversation_log = CONCAT(COALESCE(ai_conversation_log, ""), ?)';
        params.push(`\n[${new Date().toISOString()}] ${notes}`);
      }

      if (supplierIds) {
        query += ', attempted_suppliers = ?';
        params.push(JSON.stringify(supplierIds));
      }

      query += ' WHERE id = ?';
      params.push(reorderLogId);

      await this.dbConnection.execute(query, params);
    } catch (error) {
      console.error('❌ Error updating reorder log:', error);
    }
  }

  /**
   * Log AI conversation details
   */
  async logAIConversation(reorderLogId, supplierId, conversationSteps) {
    try {
      const conversationLog = `\n\n=== Conversation with Supplier ID ${supplierId} ===\n` +
                             conversationSteps.join('\n') +
                             `\n=== End of Conversation ===\n`;

      await this.dbConnection.execute(`
        UPDATE reorder_logs 
        SET ai_conversation_log = CONCAT(COALESCE(ai_conversation_log, ''), ?) 
        WHERE id = ?
      `, [conversationLog, reorderLogId]);
    } catch (error) {
      console.error('❌ Error logging AI conversation:', error);
    }
  }

  /**
   * Calculate expected delivery date
   */
  calculateDeliveryDate(leadTimeDays) {
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + leadTimeDays);
    return deliveryDate.toISOString().split('T')[0]; // Return YYYY-MM-DD format
  }

  /**
   * Get AI processing status for a reorder
   */
  async getReorderStatus(reorderLogId) {
    try {
      const [rows] = await this.dbConnection.execute(`
        SELECT rl.*, p.name as product_name, s.name as supplier_name,
               po.status as order_status
        FROM reorder_logs rl
        JOIN products p ON rl.product_id = p.id
        LEFT JOIN suppliers s ON rl.supplier_id = s.id
        LEFT JOIN pending_orders po ON po.reorder_log_id = rl.id
        WHERE rl.id = ?
      `, [reorderLogId]);

      return rows[0] || null;
    } catch (error) {
      console.error('❌ Error getting reorder status:', error);
      throw error;
    }
  }

  /**
   * Close database connection
   */
  async close() {
    if (this.dbConnection) {
      await this.dbConnection.end();
      console.log('📡 ChatlingIntegration database connection closed');
    }
  }
}

module.exports = ChatlingIntegration;