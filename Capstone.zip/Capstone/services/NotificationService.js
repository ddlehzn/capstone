require('dotenv').config();
const nodemailer = require('nodemailer');
const twilio = require('twilio');
const mysql = require('mysql2/promise');

class NotificationService {
  constructor() {
    this.emailTransporter = null;
    this.twilioClient = null;
    this.dbConnection = null;
    this.init();
  }

  async init() {
    try {
      // Initialize database connection
      this.dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306
      });

      // Initialize email transporter (using Gmail as example)
      this.emailTransporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASS // Use app password for Gmail
        }
      });

      // Check for test mode
      this.testMode = process.env.SMS_TEST_MODE === 'true' || !process.env.TWILIO_ACCOUNT_SID;
      
      if (this.testMode) {
        console.log('🧪 SMS TEST MODE ENABLED - SMS will be simulated instead of sent');
        console.log('   To enable real SMS: Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER in .env');
        console.log('   To disable test mode: Set SMS_TEST_MODE=false in .env');
      } else {
        // Initialize Twilio client for SMS (only if credentials are provided)
        if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && 
            process.env.TWILIO_ACCOUNT_SID.startsWith('AC') && 
            process.env.TWILIO_AUTH_TOKEN.length > 10) {
          this.twilioClient = twilio(
            process.env.TWILIO_ACCOUNT_SID,
            process.env.TWILIO_AUTH_TOKEN
          );
          console.log('✓ Twilio SMS service initialized');
        } else {
          console.log('⚠️ Twilio credentials not properly configured - SMS service disabled');
        }
      }

      console.log('NotificationService initialized successfully');
    } catch (error) {
      console.error('Error initializing NotificationService:', error);
    }
  }

  /**
   * Create a new notification record in the database
   */
  async createNotification(notificationData) {
    try {
      const {
        userId,
        type,
        title,
        message,
        productId = null,
        reorderLogId = null,
        priority = 'medium',
        methods = ['email', 'phone', 'in_app']
      } = notificationData;

      const methodsString = methods.join(',');

      const [result] = await this.dbConnection.execute(`
        INSERT INTO admin_notifications 
        (user_id, type, title, message, product_id, reorder_log_id, priority, notification_methods) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [userId, type, title, message, productId, reorderLogId, priority, methodsString]);

      console.log(`✓ Notification created with ID: ${result.insertId}`);
      return result.insertId;
    } catch (error) {
      console.error('Error creating notification:', error);
      throw error;
    }
  }

  /**
   * Send email notification
   */
  async sendEmailNotification(userEmail, subject, content, notificationId, isHTML = true) {
    try {
      if (!this.emailTransporter) {
        throw new Error('Email transporter not initialized');
      }

      const mailOptions = {
        from: process.env.EMAIL_USER || 'noreply@company.com',
        to: userEmail,
        subject: subject
      };

      // Add content based on type
      if (isHTML) {
        mailOptions.html = content;
      } else {
        mailOptions.text = content;
      }

      const info = await this.emailTransporter.sendMail(mailOptions);
      
      // Update notification record
      if (notificationId) {
        await this.dbConnection.execute(`
          UPDATE admin_notifications 
          SET email_sent = TRUE, email_sent_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `, [notificationId]);
      }

      console.log(`✓ Email sent successfully to ${userEmail}`);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error(`❌ Error sending email to ${userEmail}:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Send SMS notification
   */
  async sendSMSNotification(phoneNumber, message, notificationId) {
    try {
      // Handle test mode
      if (this.testMode) {
        console.log('🧪 SMS TEST MODE - Simulating SMS send:');
        console.log(`   To: ${phoneNumber}`);
        console.log(`   Message: ${message}`);
        console.log(`   From: ${process.env.TWILIO_PHONE_NUMBER || 'TEST_PHONE'}`);
        
        // Simulate a delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Update notification record as if SMS was sent
        if (notificationId) {
          await this.dbConnection.execute(`
            UPDATE admin_notifications 
            SET phone_sent = TRUE, phone_sent_at = CURRENT_TIMESTAMP 
            WHERE id = ?
          `, [notificationId]);
        }

        console.log(`✓ SMS simulated successfully to ${phoneNumber}`);
        return { success: true, sid: `TEST_${Date.now()}_${Math.random().toString(36).substr(2, 9)}` };
      }

      if (!this.twilioClient) {
        console.log('⚠️ SMS service not configured (missing Twilio credentials)');
        return { success: false, error: 'SMS service not configured' };
      }

      const smsMessage = await this.twilioClient.messages.create({
        body: message,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: phoneNumber
      });

      // Update notification record
      if (notificationId) {
        await this.dbConnection.execute(`
          UPDATE admin_notifications 
          SET phone_sent = TRUE, phone_sent_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `, [notificationId]);
      }

      console.log(`✓ SMS sent successfully to ${phoneNumber}`);
      return { success: true, sid: smsMessage.sid };
    } catch (error) {
      console.error(`❌ Error sending SMS to ${phoneNumber}:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Generate email HTML template for low stock notification
   */
  generateLowStockEmailHTML(productName, currentStock, threshold, supplierInfo) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #f44336; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background-color: #f9f9f9; }
          .alert { background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 15px 0; border-radius: 5px; }
          .product-info { background-color: white; padding: 15px; margin: 15px 0; border-radius: 5px; border-left: 4px solid #f44336; }
          .supplier-info { background-color: #e3f2fd; padding: 15px; margin: 15px 0; border-radius: 5px; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚨 Low Stock Alert</h1>
          </div>
          <div class="content">
            <div class="alert">
              <strong>⚠️ Immediate Attention Required</strong><br>
              Your inventory management system has detected critically low stock levels.
            </div>
            
            <div class="product-info">
              <h3>Product Details</h3>
              <p><strong>Product:</strong> ${productName}</p>
              <p><strong>Current Stock:</strong> ${currentStock} units</p>
              <p><strong>Reorder Threshold:</strong> ${threshold} units</p>
              <p><strong>Stock Level:</strong> <span style="color: #f44336; font-weight: bold;">CRITICALLY LOW</span></p>
            </div>

            ${supplierInfo ? `
            <div class="supplier-info">
              <h3>Preferred Supplier</h3>
              <p><strong>Company:</strong> ${supplierInfo.name}</p>
              <p><strong>Contact:</strong> ${supplierInfo.email}</p>
              <p><strong>Phone:</strong> ${supplierInfo.phone}</p>
            </div>` : ''}

            <div class="alert">
              <p><strong>Automated Action:</strong> Our AI system will automatically contact suppliers and initiate the reorder process. You will be notified once the order is confirmed.</p>
            </div>
          </div>
          <div class="footer">
            <p>This is an automated notification from your Inventory Management System</p>
            <p>Generated on ${new Date().toLocaleString()}</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Send comprehensive low stock notification
   */
  async sendLowStockNotification(userId, productName, currentStock, threshold, supplierInfo = null) {
    try {
      // Get user contact information
      const [userRows] = await this.dbConnection.execute(`
        SELECT email, phone, first_name, last_name, notification_preferences 
        FROM users WHERE id = ?
      `, [userId]);

      if (userRows.length === 0) {
        throw new Error(`User with ID ${userId} not found`);
      }

      const user = userRows[0];
      const preferences = user.notification_preferences ? user.notification_preferences.split(',') : ['email'];

      // Create notification record
      const notificationData = {
        userId,
        type: 'low_stock',
        title: `Low Stock Alert: ${productName}`,
        message: `${productName} is running low (${currentStock} units remaining, threshold: ${threshold} units). Automated reorder process initiated.`,
        priority: currentStock <= threshold * 0.5 ? 'urgent' : 'high',
        methods: preferences
      };

      const notificationId = await this.createNotification(notificationData);

      const results = {
        notificationId,
        email: { success: false },
        sms: { success: false }
      };

      // Send email notification
      if (preferences.includes('email') && user.email) {
        const emailSubject = `🚨 URGENT: Low Stock Alert - ${productName}`;
        const emailHTML = this.generateLowStockEmailHTML(productName, currentStock, threshold, supplierInfo);
        
        results.email = await this.sendEmailNotification(user.email, emailSubject, emailHTML, notificationId);
      }

      // Send SMS notification
      if (preferences.includes('phone') && user.phone) {
        const smsMessage = `🚨 LOW STOCK ALERT: ${productName} is critically low (${currentStock} units). Automated reorder initiated. Check your email for details.`;
        
        results.sms = await this.sendSMSNotification(user.phone, smsMessage, notificationId);
      }

      console.log(`✅ Low stock notification sent for product: ${productName}`);
      return results;

    } catch (error) {
      console.error('Error sending low stock notification:', error);
      throw error;
    }
  }

  /**
   * Get unread notifications for a user
   */
  async getUnreadNotifications(userId) {
    try {
      const [notifications] = await this.dbConnection.execute(`
        SELECT n.*, p.name as product_name
        FROM admin_notifications n
        LEFT JOIN products p ON n.product_id = p.id
        WHERE n.user_id = ? AND n.is_read = FALSE
        ORDER BY n.priority DESC, n.created_at DESC
      `, [userId]);

      return notifications;
    } catch (error) {
      console.error('Error fetching notifications:', error);
      throw error;
    }
  }

  /**
   * Mark notification as read
   */
  async markAsRead(notificationId) {
    try {
      await this.dbConnection.execute(`
        UPDATE admin_notifications 
        SET is_read = TRUE, read_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `, [notificationId]);

      console.log(`✓ Notification ${notificationId} marked as read`);
    } catch (error) {
      console.error('Error marking notification as read:', error);
      throw error;
    }
  }

  /**
   * Close database connection
   */
  async close() {
    if (this.dbConnection) {
      await this.dbConnection.end();
      console.log('NotificationService database connection closed');
    }
  }
}

module.exports = NotificationService;