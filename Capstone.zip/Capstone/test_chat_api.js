const mysql = require('mysql2/promise');
require('dotenv').config();

async function testChatOperations() {
  try {
    // Connect to database
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    console.log('Connected to database');

    // Get sessions for user 1 (admin)
    const [sessions] = await connection.execute(
      'SELECT id, session_name FROM chat_sessions WHERE user_id = ? LIMIT 5',
      [1]
    );

    console.log('Sessions found:', sessions);

    if (sessions.length > 0) {
      const sessionId = sessions[0].id;
      console.log(`\nTesting with session ID: ${sessionId}`);

      // Test rename operation
      const newName = `Test Renamed Chat ${Date.now()}`;
      const [renameResult] = await connection.execute(
        'UPDATE chat_sessions SET session_name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?',
        [newName, sessionId, 1]
      );

      console.log('Rename result:', renameResult);
      console.log('Affected rows:', renameResult.affectedRows);

      // Verify rename
      const [verifyRename] = await connection.execute(
        'SELECT session_name FROM chat_sessions WHERE id = ?',
        [sessionId]
      );
      
      console.log('New name:', verifyRename[0]?.session_name);

      // Test delete operation (only if we have multiple sessions)
      if (sessions.length > 1) {
        const deleteSessionId = sessions[1].id;
        
        // Delete messages first
        const [deleteMessages] = await connection.execute(
          'DELETE FROM chat_messages WHERE session_id = ?',
          [deleteSessionId]
        );
        
        console.log(`\nDeleted ${deleteMessages.affectedRows} messages`);

        // Delete session
        const [deleteSession] = await connection.execute(
          'DELETE FROM chat_sessions WHERE id = ? AND user_id = ?',
          [deleteSessionId, 1]
        );

        console.log('Delete session result:', deleteSession.affectedRows);
      }
    }

    await connection.end();
    console.log('\nTest completed successfully');
  } catch (error) {
    console.error('Test error:', error);
  }
}

testChatOperations();