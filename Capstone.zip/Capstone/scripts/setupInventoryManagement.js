require('dotenv').config();
const mysql = require('mysql2/promise');

async function createInventoryManagementTables() {
  let connection;
  
  try {
    console.log('Connecting to database...');
    
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    console.log(`Connected to MySQL database: ${process.env.DB_NAME}`);

    // Create suppliers table
    const createSuppliersTableQuery = `
      CREATE TABLE IF NOT EXISTS suppliers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        phone VARCHAR(50),
        address TEXT,
        contact_person VARCHAR(255),
        priority INT DEFAULT 1 COMMENT '1=primary, 2=secondary, 3=tertiary',
        is_active BOOLEAN DEFAULT TRUE,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_priority (priority),
        INDEX idx_is_active (is_active)
      )
    `;

    await connection.execute(createSuppliersTableQuery);
    console.log('✓ Suppliers table created/verified');

    // Create supplier_products table (what each supplier can provide)
    const createSupplierProductsTableQuery = `
      CREATE TABLE IF NOT EXISTS supplier_products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        supplier_id INT NOT NULL,
        product_name VARCHAR(255) NOT NULL,
        supplier_product_code VARCHAR(100),
        unit_price DECIMAL(10, 2),
        minimum_order_quantity INT DEFAULT 1,
        lead_time_days INT DEFAULT 7,
        is_available BOOLEAN DEFAULT TRUE,
        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE,
        INDEX idx_supplier_id (supplier_id),
        INDEX idx_product_name (product_name),
        INDEX idx_is_available (is_available)
      )
    `;

    await connection.execute(createSupplierProductsTableQuery);
    console.log('✓ Supplier products table created/verified');

    // Create reorder_thresholds table
    const createReorderThresholdsTableQuery = `
      CREATE TABLE IF NOT EXISTS reorder_thresholds (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        minimum_stock INT NOT NULL DEFAULT 10,
        reorder_quantity INT NOT NULL DEFAULT 50,
        auto_reorder_enabled BOOLEAN DEFAULT TRUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        UNIQUE KEY unique_product_threshold (product_id),
        INDEX idx_auto_reorder (auto_reorder_enabled)
      )
    `;

    await connection.execute(createReorderThresholdsTableQuery);
    console.log('✓ Reorder thresholds table created/verified');

    // Create reorder_logs table (track AI reorder attempts)
    const createReorderLogsTableQuery = `
      CREATE TABLE IF NOT EXISTS reorder_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        current_stock INT NOT NULL,
        threshold_triggered INT NOT NULL,
        status ENUM('threshold_detected', 'admin_notified', 'supplier_contacted', 'quote_received', 'order_placed', 'completed', 'failed') DEFAULT 'threshold_detected',
        supplier_id INT,
        attempted_suppliers JSON COMMENT 'Array of supplier IDs that were contacted',
        ai_conversation_log TEXT,
        order_details JSON,
        total_cost DECIMAL(10, 2),
        expected_delivery_date DATE,
        admin_notification_sent BOOLEAN DEFAULT FALSE,
        admin_notification_timestamp DATETIME,
        auto_order_started BOOLEAN DEFAULT FALSE,
        auto_order_timestamp DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
        INDEX idx_product_id (product_id),
        INDEX idx_status (status),
        INDEX idx_admin_notification (admin_notification_sent),
        INDEX idx_created_at (created_at)
      )
    `;

    await connection.execute(createReorderLogsTableQuery);
    console.log('✓ Reorder logs table created/verified');

    // Create pending_orders table (orders awaiting user approval/payment)
    const createPendingOrdersTableQuery = `
      CREATE TABLE IF NOT EXISTS pending_orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        reorder_log_id INT NOT NULL,
        supplier_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        unit_price DECIMAL(10, 2) NOT NULL,
        total_amount DECIMAL(10, 2) NOT NULL,
        supplier_quote_details TEXT,
        payment_required BOOLEAN DEFAULT TRUE,
        approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        approved_by INT,
        approved_at DATETIME,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (reorder_log_id) REFERENCES reorder_logs(id) ON DELETE CASCADE,
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_approval_status (approval_status),
        INDEX idx_created_at (created_at)
      )
    `;

    await connection.execute(createPendingOrdersTableQuery);
    console.log('✓ Pending orders table created/verified');

    // Create notifications table for admin alerts
    const createNotificationsTableQuery = `
      CREATE TABLE IF NOT EXISTS admin_notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL COMMENT 'Admin user to notify',
        type ENUM('low_stock', 'reorder_started', 'reorder_completed', 'reorder_failed', 'supplier_issue') NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        product_id INT,
        reorder_log_id INT,
        is_read BOOLEAN DEFAULT FALSE,
        priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
        email_sent BOOLEAN DEFAULT FALSE,
        email_sent_at DATETIME,
        phone_sent BOOLEAN DEFAULT FALSE,
        phone_sent_at DATETIME,
        notification_methods SET('email', 'phone', 'in_app') DEFAULT 'email,phone,in_app',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        read_at DATETIME,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (reorder_log_id) REFERENCES reorder_logs(id) ON DELETE CASCADE,
        INDEX idx_user_id (user_id),
        INDEX idx_is_read (is_read),
        INDEX idx_type (type),
        INDEX idx_priority (priority),
        INDEX idx_created_at (created_at),
        INDEX idx_email_sent (email_sent),
        INDEX idx_phone_sent (phone_sent)
      )
    `;

    await connection.execute(createNotificationsTableQuery);
    console.log('✓ Admin notifications table created/verified');

    // Insert sample suppliers
    const sampleSuppliers = [
      {
        name: 'Premium Coffee Beans Co.',
        email: 'orders@premiumcoffee.com',
        phone: '+1-555-0101',
        contact_person: 'John Martinez',
        priority: 1,
        notes: 'Primary supplier for coffee beans and espresso products'
      },
      {
        name: 'Global Food Distributors',
        email: 'supply@globalfood.com',
        phone: '+1-555-0202',
        contact_person: 'Sarah Johnson',
        priority: 2,
        notes: 'Secondary supplier with wider product range'
      },
      {
        name: 'Local Coffee Roasters',
        email: 'wholesale@localroasters.com',
        phone: '+1-555-0303',
        contact_person: 'Mike Chen',
        priority: 3,
        notes: 'Local backup supplier for emergency orders'
      }
    ];

    for (const supplier of sampleSuppliers) {
      try {
        await connection.execute(
          'INSERT INTO suppliers (name, email, phone, contact_person, priority, notes) VALUES (?, ?, ?, ?, ?, ?)',
          [supplier.name, supplier.email, supplier.phone, supplier.contact_person, supplier.priority, supplier.notes]
        );
        console.log(`✓ Sample supplier added: ${supplier.name}`);
      } catch (err) {
        if (err.code !== 'ER_DUP_ENTRY') {
          console.log(`Note: Supplier ${supplier.name} may already exist`);
        }
      }
    }

    // Insert sample reorder thresholds for existing products
    const [existingProducts] = await connection.execute('SELECT id, name FROM products LIMIT 5');
    
    if (existingProducts.length > 0) {
      console.log('Setting up reorder thresholds for existing products...');
      
      for (const product of existingProducts) {
        try {
          const threshold = Math.floor(Math.random() * 15) + 5; // Random threshold between 5-20
          const reorderQty = threshold * 3; // Reorder 3x the threshold amount
          
          await connection.execute(
            'INSERT INTO reorder_thresholds (product_id, minimum_stock, reorder_quantity) VALUES (?, ?, ?)',
            [product.id, threshold, reorderQty]
          );
          console.log(`✓ Reorder threshold set for ${product.name}: min=${threshold}, reorder=${reorderQty}`);
        } catch (err) {
          if (err.code !== 'ER_DUP_ENTRY') {
            console.log(`Note: Threshold for ${product.name} may already exist`);
          }
        }
      }
    }

    console.log('Inventory management tables setup completed successfully!');

  } catch (error) {
    console.error('Error setting up inventory management tables:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

createInventoryManagementTables();