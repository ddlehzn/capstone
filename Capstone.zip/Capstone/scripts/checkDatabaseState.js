require('dotenv').config();
const mysql = require('mysql2/promise');

async function checkDatabaseState() {
  try {
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT || 3306
    });

    console.log('🔍 Checking database state...\n');

    // Check products
    const [products] = await connection.execute('SELECT * FROM products LIMIT 5');
    console.log('📦 Products:');
    products.forEach(p => {
      console.log(`  - ${p.name}: ${p.quantity} units`);
    });

    // Check reorder thresholds
    const [thresholds] = await connection.execute(`
      SELECT rt.*, p.name as product_name 
      FROM reorder_thresholds rt 
      JOIN products p ON rt.product_id = p.id
    `);
    console.log('\n⚖️ Reorder Thresholds:');
    thresholds.forEach(t => {
      console.log(`  - ${t.product_name}: min=${t.minimum_stock}, reorder=${t.reorder_quantity}, enabled=${t.auto_reorder_enabled}`);
    });

    // Check low stock products
    const [lowStock] = await connection.execute(`
      SELECT 
        p.id,
        p.name,
        p.quantity as current_stock,
        rt.minimum_stock,
        rt.reorder_quantity,
        rt.auto_reorder_enabled
      FROM products p
      JOIN reorder_thresholds rt ON p.id = rt.product_id
      WHERE p.quantity <= rt.minimum_stock 
        AND rt.auto_reorder_enabled = TRUE
    `);
    
    console.log('\n🚨 Low Stock Products:');
    if (lowStock.length === 0) {
      console.log('  No products below threshold');
    } else {
      lowStock.forEach(p => {
        console.log(`  - ${p.name}: ${p.current_stock} <= ${p.minimum_stock} (reorder: ${p.reorder_quantity})`);
      });
    }

    // Check suppliers
    const [suppliers] = await connection.execute('SELECT * FROM suppliers');
    console.log('\n🏪 Suppliers:');
    suppliers.forEach(s => {
      console.log(`  - ${s.name} (${s.email})`);
    });

    await connection.end();
    console.log('\n✅ Database state check completed');

  } catch (error) {
    console.error('❌ Error checking database state:', error);
  }
}

checkDatabaseState();