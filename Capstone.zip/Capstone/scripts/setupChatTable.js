require('dotenv').config();
const mysql = require('mysql2/promise');

async function createChatTable() {
  let connection;
  
  try {
    console.log('Connecting to database...');
    
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    console.log(`Connected to MySQL database: ${process.env.DB_NAME}`);

    // Create chat_messages table
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS chat_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        username VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        message_type ENUM('user', 'ai', 'system') DEFAULT 'user',
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id),
        INDEX idx_timestamp (timestamp),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `;

    await connection.execute(createTableQuery);
    console.log('✓ Chat messages table created/verified');

    // Insert some sample messages for testing
    const sampleMessages = [
      {
        user_id: 1,
        username: 'admin',
        message: 'Hello! Welcome to our coffee ordering system. How can I help you today?',
        message_type: 'ai'
      },
      {
        user_id: 1,
        username: 'admin',
        message: 'Hi there! I would like to order a large cappuccino please.',
        message_type: 'user'
      },
      {
        user_id: 1,
        username: 'admin',
        message: 'Great choice! I can help you with that. Would you like any additional options like extra foam or flavoring?',
        message_type: 'ai'
      }
    ];

    for (const msg of sampleMessages) {
      try {
        await connection.execute(
          'INSERT INTO chat_messages (user_id, username, message, message_type) VALUES (?, ?, ?, ?)',
          [msg.user_id, msg.username, msg.message, msg.message_type]
        );
        console.log(`✓ Sample message added: ${msg.message_type} - ${msg.message.substring(0, 50)}...`);
      } catch (err) {
        if (err.code !== 'ER_DUP_ENTRY') {
          console.log(`Note: Sample message may already exist`);
        }
      }
    }

    console.log('Chat table setup completed successfully!');

  } catch (error) {
    console.error('Error setting up chat table:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

createChatTable();