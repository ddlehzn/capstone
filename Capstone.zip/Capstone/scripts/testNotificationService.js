require('dotenv').config();
const NotificationService = require('../services/NotificationService');

async function testNotificationService() {
  const notificationService = new NotificationService();
  
  // Wait for initialization
  await new Promise(resolve => setTimeout(resolve, 1000));

  try {
    console.log('🧪 Testing Notification Service...\n');

    // Test low stock notification
    console.log('📧 Testing low stock notification...');
    
    const supplierInfo = {
      name: 'Premium Coffee Beans Co.',
      email: 'orders@premiumcoffeebeans.com',
      phone: '+1-555-0123'
    };

    // Send notification to admin user (ID = 1)
    const result = await notificationService.sendLowStockNotification(
      1, // admin user ID
      'Colombian Coffee Beans',
      8, // current stock
      15, // threshold
      supplierInfo
    );

    console.log('Notification Results:');
    console.log('- Notification ID:', result.notificationId);
    console.log('- Email sent:', result.email.success);
    console.log('- SMS sent:', result.sms.success);

    // Test getting unread notifications
    console.log('\n📋 Fetching unread notifications...');
    const unreadNotifications = await notificationService.getUnreadNotifications(1);
    console.log(`Found ${unreadNotifications.length} unread notifications:`);
    
    unreadNotifications.forEach((notif, index) => {
      console.log(`${index + 1}. [${notif.priority.toUpperCase()}] ${notif.title}`);
      console.log(`   Message: ${notif.message}`);
      console.log(`   Created: ${notif.created_at}`);
      console.log(`   Email sent: ${notif.email_sent ? '✓' : '✗'}`);
      console.log(`   Phone sent: ${notif.phone_sent ? '✓' : '✗'}`);
      console.log('');
    });

    // Mark the first notification as read
    if (unreadNotifications.length > 0) {
      console.log('✓ Marking first notification as read...');
      await notificationService.markAsRead(unreadNotifications[0].id);
    }

    console.log('✅ Notification service test completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await notificationService.close();
  }
}

// Check if script is run directly
if (require.main === module) {
  testNotificationService();
}

module.exports = testNotificationService;