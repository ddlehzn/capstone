require('dotenv').config();
const mysql = require('mysql2/promise');

async function createChatSessionsTable() {
  let connection;
  
  try {
    console.log('Connecting to database...');
    
    connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });

    console.log(`Connected to MySQL database: ${process.env.DB_NAME}`);

    // Create chat_sessions table
    const createSessionsTableQuery = `
      CREATE TABLE IF NOT EXISTS chat_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) DEFAULT 'New Chat',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT TRUE,
        INDEX idx_user_id (user_id),
        INDEX idx_created_at (created_at),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `;

    await connection.execute(createSessionsTableQuery);
    console.log('✓ Chat sessions table created/verified');

    // Update chat_messages table to include session_id
    const alterMessagesTableQuery = `
      ALTER TABLE chat_messages 
      ADD COLUMN session_id INT,
      ADD INDEX idx_session_id (session_id),
      ADD FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
    `;

    try {
      await connection.execute(alterMessagesTableQuery);
      console.log('✓ Chat messages table updated with session_id');
    } catch (err) {
      if (err.code === 'ER_DUP_FIELDNAME' || err.message.includes('Duplicate column name')) {
        console.log('✓ Chat messages table already has session_id column');
      } else {
        throw err;
      }
    }

    // Create a default session for existing messages
    const [existingMessages] = await connection.execute(
      'SELECT COUNT(*) as count FROM chat_messages WHERE session_id IS NULL'
    );

    if (existingMessages[0].count > 0) {
      console.log(`Found ${existingMessages[0].count} messages without sessions. Creating default session...`);
      
      // Create default session for user 1 (admin)
      const [sessionResult] = await connection.execute(
        'INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)',
        [1, 'Initial Chat Session']
      );
      
      const sessionId = sessionResult.insertId;
      
      // Update existing messages to use this session
      await connection.execute(
        'UPDATE chat_messages SET session_id = ? WHERE session_id IS NULL',
        [sessionId]
      );
      
      console.log(`✓ Created default session and updated ${existingMessages[0].count} messages`);
    }

    console.log('Chat sessions setup completed successfully!');

  } catch (error) {
    console.error('Error setting up chat sessions:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

createChatSessionsTable();