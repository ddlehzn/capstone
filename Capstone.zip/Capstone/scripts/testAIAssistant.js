noderequire('dotenv').config();
const AIAssistantService = require('../services/AIAssistantService');

async function testAIAssistantService() {
  const aiService = new AIAssistantService();
  
  // Wait for initialization
  await new Promise(resolve => setTimeout(resolve, 2000));

  try {
    console.log('🤖 Testing AI Assistant Service...\n');

    // Test 1: Generate stock inquiry message
    console.log('📧 Test 1: Generating stock inquiry message...');
    const stockInquiryContext = {
      productName: 'Colombian Coffee Beans Premium Grade',
      currentStock: 8,
      requiredQuantity: 50,
      supplierName: 'Premium Coffee Beans Co.',
      companyName: 'Café Central'
    };

    const stockInquiry = await aiService.generateSupplierMessage('stock_inquiry', stockInquiryContext);
    console.log('Stock Inquiry Result:');
    console.log('Success:', stockInquiry.success);
    if (stockInquiry.success) {
      console.log('Provider used:', stockInquiry.provider);
      console.log('Generated message:');
      console.log('---');
      console.log(stockInquiry.message);
      console.log('---\n');
    } else {
      console.log('Error:', stockInquiry.error);
      console.log('Fallback message:');
      console.log(stockInquiry.fallbackMessage);
    }

    // Test 2: Generate price comparison
    console.log('💰 Test 2: Generating price comparison...');
    const quotes = [
      {
        supplierName: 'Premium Coffee Beans Co.',
        unitPrice: 12.50,
        totalPrice: 625.00,
        deliveryDays: 7,
        minOrder: 25
      },
      {
        supplierName: 'Global Food Distributors',
        unitPrice: 11.80,
        totalPrice: 590.00,
        deliveryDays: 10,
        minOrder: 50
      },
      {
        supplierName: 'Local Coffee Roasters',
        unitPrice: 13.20,
        totalPrice: 660.00,
        deliveryDays: 3,
        minOrder: 20
      }
    ];

    const comparisonContext = {
      productName: 'Colombian Coffee Beans Premium Grade',
      requiredQuantity: 50,
      quotes: quotes
    };

    const priceComparison = await aiService.generateSupplierMessage('price_comparison', comparisonContext);
    console.log('Price Comparison Result:');
    console.log('Success:', priceComparison.success);
    if (priceComparison.success) {
      console.log('Provider used:', priceComparison.provider);
      console.log('Generated analysis:');
      console.log('---');
      console.log(priceComparison.message);
      console.log('---\n');
    } else {
      console.log('Error:', priceComparison.error);
    }

    // Test 3: Generate order placement
    console.log('📋 Test 3: Generating order placement email...');
    const orderContext = {
      productName: 'Colombian Coffee Beans Premium Grade',
      quantity: 50,
      unitPrice: 11.80,
      totalAmount: 590.00,
      supplierName: 'Global Food Distributors',
      deliveryAddress: '123 Business St, Coffee City, CC 12345',
      expectedDelivery: '7-10 business days'
    };

    const orderPlacement = await aiService.generateSupplierMessage('order_placement', orderContext);
    console.log('Order Placement Result:');
    console.log('Success:', orderPlacement.success);
    if (orderPlacement.success) {
      console.log('Provider used:', orderPlacement.provider);
      console.log('Generated order email:');
      console.log('---');
      console.log(orderPlacement.message);
      console.log('---\n');
    } else {
      console.log('Error:', orderPlacement.error);
      console.log('Fallback message:');
      console.log(orderPlacement.fallbackMessage);
    }

    // Test 4: Full supplier communication workflow
    console.log('🔄 Test 4: Testing full supplier communication workflow...');
    
    const productInfo = {
      name: 'Colombian Coffee Beans Premium Grade',
      currentStock: 8,
      reorderQuantity: 50
    };

    const suppliers = [
      { id: 1, name: 'Premium Coffee Beans Co.', email: 'orders@premiumcoffee.com' },
      { id: 2, name: 'Global Food Distributors', email: 'sales@globalfood.com' },
      { id: 3, name: 'Local Coffee Roasters', email: 'wholesale@localroasters.com' }
    ];

    // Simulate with a test reorder log ID
    const workflowResult = await aiService.processSupplierCommunication(999, productInfo, suppliers);
    console.log('Workflow Result:');
    console.log('Success:', workflowResult.success);
    console.log('Inquiries sent:', workflowResult.inquiriesSent);
    console.log('Next step:', workflowResult.nextStep);
    
    if (workflowResult.success && workflowResult.inquiries) {
      console.log('\nGenerated inquiries:');
      workflowResult.inquiries.forEach((inquiry, index) => {
        console.log(`\n--- Inquiry ${index + 1}: ${inquiry.supplier.name} ---`);
        if (inquiry.inquiry.success) {
          console.log(inquiry.inquiry.message);
        } else {
          console.log('Error:', inquiry.inquiry.error);
          console.log('Fallback:', inquiry.inquiry.fallbackMessage);
        }
      });
    }

    console.log('\n✅ AI Assistant Service test completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await aiService.close();
  }
}

// Check if script is run directly
if (require.main === module) {
  testAIAssistantService();
}

module.exports = testAIAssistantService;