require('dotenv').config();
const InventoryMonitor = require('../services/InventoryMonitor');
const mysql = require('mysql2/promise');

async function testInventoryMonitor() {
  const monitor = new InventoryMonitor();
  
  // Wait for initialization
  await new Promise(resolve => setTimeout(resolve, 2000));

  try {
    console.log('🧪 Testing Inventory Monitor...\n');

    // First, let's artificially create a low stock situation for testing
    console.log('📦 Setting up test scenario (lowering stock)...');
    
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT || 3306
    });

    // Get first product and lower its stock
    const [products] = await connection.execute('SELECT id, name, quantity FROM products LIMIT 1');
    if (products.length > 0) {
      const product = products[0];
      console.log(`📊 Original stock for "${product.name}": ${product.quantity}`);
      
      // Set stock to a very low number to trigger threshold
      await connection.execute('UPDATE products SET quantity = 5 WHERE id = ?', [product.id]);
      console.log(`📉 Set stock for "${product.name}" to 5 units (below threshold)`);
    }

    await connection.end();

    // Run manual inventory check
    console.log('\n🔍 Running manual inventory check...');
    const lowStockCount = await monitor.runSingleCheck();

    // Get recent reorder logs
    console.log('\n📋 Recent reorder logs:');
    const reorderLogs = await monitor.getRecentReorderLogs(5);
    
    reorderLogs.forEach((log, index) => {
      console.log(`${index + 1}. Product: ${log.product_name}`);
      console.log(`   Status: ${log.status}`);
      console.log(`   Quantity Requested: ${log.quantity_requested}`);
      console.log(`   Supplier: ${log.supplier_name || 'Not assigned'}`);
      console.log(`   Threshold Detected: ${log.threshold_detected_at}`);
      console.log(`   Admin Notified: ${log.admin_notification_sent ? '✓' : '✗'}`);
      console.log(`   Auto Order Started: ${log.auto_order_started ? '✓' : '✗'}`);
      console.log('');
    });

    // Test monitoring status
    console.log('📊 Monitor Status:', monitor.getStatus());

    // Test short-term monitoring (just for demo - 30 seconds)
    console.log('\n⏱️ Testing 30-second monitoring cycle...');
    monitor.startMonitoring(0.5); // Check every 30 seconds
    
    // Let it run for 2 minutes then stop
    await new Promise(resolve => setTimeout(resolve, 120000));
    monitor.stopMonitoring();

    console.log('✅ Inventory monitor test completed successfully!');

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await monitor.close();
  }
}

// Helper function to restore stock levels
async function restoreStockLevels() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306
  });

  console.log('🔄 Restoring stock levels...');
  await connection.execute('UPDATE products SET quantity = 100 WHERE quantity < 20');
  console.log('✅ Stock levels restored');
  
  await connection.end();
}

// Check if script is run directly
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.includes('--restore')) {
    restoreStockLevels();
  } else {
    testInventoryMonitor();
  }
}

module.exports = { testInventoryMonitor, restoreStockLevels };