require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');

(async () => {
  try {
    const conn = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT || 3306
    });

    console.log('Connected to MySQL database:', process.env.DB_NAME);

    // Create users table
    await conn.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    console.log('Users table created/verified');

    // Seed initial users
    const users = [
      { username: 'admin@company.com', password: 'admin123', role: 'admin' },
      { username: 'staff@company.com', password: 'staff123', role: 'staff' }
    ];

    const rounds = parseInt(process.env.BCRYPT_ROUNDS || '10', 10);

    for (const u of users) {
      const [rows] = await conn.execute('SELECT id FROM users WHERE username = ?', [u.username]);
      if (rows.length === 0) {
        const hash = await bcrypt.hash(u.password, rounds);
        await conn.execute(
          'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
          [u.username, hash, u.role]
        );
        console.log(`✓ Seeded user: ${u.username} (${u.role})`);
      } else {
        console.log(`- User already exists: ${u.username}`);
      }
    }

    await conn.end();
    console.log('Seeding completed successfully!');
    
  } catch (err) {
    console.error('Error during seeding:', err.message);
    process.exit(1);
  }
})();