require('dotenv').config();
const mysql = require('mysql2/promise');

(async () => {
  try {
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT || 3306
    });

    console.log('Connected to MySQL database:', process.env.DB_NAME);

    // Add email and phone columns to users table if they don't exist
    try {
      await connection.execute(`
        ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS email VARCHAR(255),
        ADD COLUMN IF NOT EXISTS phone VARCHAR(20),
        ADD COLUMN IF NOT EXISTS first_name VARCHAR(100),
        ADD COLUMN IF NOT EXISTS last_name VARCHAR(100),
        ADD COLUMN IF NOT EXISTS notification_preferences SET('email', 'phone', 'in_app') DEFAULT 'email,in_app'
      `);
      console.log('✓ Users table updated with email, phone, and notification fields');
    } catch (error) {
      // Handle case where columns might already exist
      console.log('Note: Some columns may already exist, checking individually...');
      
      const columns = [
        { name: 'email', definition: 'VARCHAR(255)' },
        { name: 'phone', definition: 'VARCHAR(20)' },
        { name: 'first_name', definition: 'VARCHAR(100)' },
        { name: 'last_name', definition: 'VARCHAR(100)' },
        { name: 'notification_preferences', definition: "SET('email', 'phone', 'in_app') DEFAULT 'email,in_app'" }
      ];

      for (const col of columns) {
        try {
          await connection.execute(`ALTER TABLE users ADD COLUMN ${col.name} ${col.definition}`);
          console.log(`✓ Added column: ${col.name}`);
        } catch (addError) {
          if (addError.code === 'ER_DUP_FIELDNAME') {
            console.log(`- Column already exists: ${col.name}`);
          } else {
            console.error(`Error adding column ${col.name}:`, addError.message);
          }
        }
      }
    }

    // Update existing users with sample contact information
    const [adminRows] = await connection.execute('SELECT id FROM users WHERE username = ?', ['admin']);
    if (adminRows.length > 0) {
      await connection.execute(`
        UPDATE users 
        SET email = COALESCE(email, 'admin@company.com'),
            phone = COALESCE(phone, '+1234567890'),
            first_name = COALESCE(first_name, 'Admin'),
            last_name = COALESCE(last_name, 'User'),
            notification_preferences = COALESCE(notification_preferences, 'email,phone,in_app')
        WHERE username = 'admin'
      `);
      console.log('✓ Updated admin user with contact information');
    }

    const [staffRows] = await connection.execute('SELECT id FROM users WHERE username = ?', ['staff']);
    if (staffRows.length > 0) {
      await connection.execute(`
        UPDATE users 
        SET email = COALESCE(email, 'staff@company.com'),
            phone = COALESCE(phone, '+1234567891'),
            first_name = COALESCE(first_name, 'Staff'),
            last_name = COALESCE(last_name, 'User'),
            notification_preferences = COALESCE(notification_preferences, 'email,in_app')
        WHERE username = 'staff'
      `);
      console.log('✓ Updated staff user with contact information');
    }

    console.log('\n✅ Users table successfully updated with notification fields!');
    await connection.end();

  } catch (error) {
    console.error('❌ Error updating users table:', error);
    process.exit(1);
  }
})();