require('dotenv').config();
const mysql = require('mysql2/promise');

async function runCompleteSystemDemo() {
  try {
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT || 3306
    });

    console.log('🎬 Starting Complete Inventory Management System Demo...\n');

    // Step 1: Show current system state
    console.log('📊 Step 1: Current System State');
    console.log('=' .repeat(50));
    
    const [products] = await connection.execute(`
      SELECT p.*, rt.minimum_stock, rt.reorder_quantity 
      FROM products p 
      LEFT JOIN reorder_thresholds rt ON p.id = rt.product_id
    `);
    
    console.log('Current Inventory:');
    products.forEach(p => {
      const status = p.quantity <= (p.minimum_stock || 0) ? '🚨 LOW STOCK' : '✅ Good';
      console.log(`  ${p.name}: ${p.quantity} units (min: ${p.minimum_stock || 'N/A'}) ${status}`);
    });

    // Step 2: Demonstrate AI-powered supplier communication
    console.log('\n🤖 Step 2: AI-Powered Supplier Communication Demo');
    console.log('=' .repeat(50));
    
    const AIAssistantService = require('../services/AIAssistantService');
    const aiService = new AIAssistantService();
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Generate sample supplier inquiry
    const inquiryContext = {
      productName: 'Colombian Coffee Beans Premium Grade',
      currentStock: 5,
      requiredQuantity: 45,
      supplierName: 'Premium Coffee Beans Co.',
      companyName: process.env.COMPANY_NAME || 'Your Coffee Shop'
    };

    console.log('Generating AI supplier inquiry...');
    const inquiry = await aiService.generateSupplierMessage('stock_inquiry', inquiryContext);
    
    if (inquiry.success) {
      console.log(`✅ AI Generated Message (Provider: ${inquiry.provider}):`);
      console.log('---');
      console.log(inquiry.message);
      console.log('---');
    } else {
      console.log('⚠️ AI failed, using fallback template:');
      console.log('---');
      console.log(inquiry.fallbackMessage);
      console.log('---');
    }

    // Step 3: Demonstrate notification system
    console.log('\n📧 Step 3: Admin Notification System Demo');
    console.log('=' .repeat(50));
    
    const NotificationService = require('../services/NotificationService');
    const notificationService = new NotificationService();
    await new Promise(resolve => setTimeout(resolve, 1000));

    console.log('Creating low stock notification...');
    const notificationResult = await notificationService.sendLowStockNotification(
      1, // admin user ID
      'Colombian Coffee Beans Premium Grade',
      5, // current stock
      15, // threshold
      { name: 'Premium Coffee Beans Co.', email: 'orders@premiumcoffee.com', phone: '+1-555-0123' }
    );

    console.log('Notification Results:');
    console.log(`  Database Record: ID ${notificationResult.notificationId}`);
    console.log(`  Email Sent: ${notificationResult.email.success ? '✅' : '❌'}`);
    console.log(`  SMS Sent: ${notificationResult.sms.success ? '✅' : '❌'}`);

    // Step 4: Show complete inventory monitoring workflow
    console.log('\n🔄 Step 4: Complete Monitoring Workflow');
    console.log('=' .repeat(50));
    
    // Clear any existing reorder logs for clean demo
    await connection.execute(`DELETE FROM reorder_logs WHERE product_id IN (SELECT id FROM products WHERE name = 'sadasd')`);
    console.log('📝 Cleared existing reorder logs for clean demo');

    // Set product to low stock
    await connection.execute(`UPDATE products SET quantity = 3 WHERE name = 'sadasd'`);
    console.log('📉 Set "sadasd" product to 3 units (below threshold of 15)');

    // Initialize inventory monitor
    const InventoryMonitor = require('../services/InventoryMonitor');
    const monitor = new InventoryMonitor();
    await new Promise(resolve => setTimeout(resolve, 3000));

    console.log('\n🔍 Running inventory check...');
    const lowStockCount = await monitor.runSingleCheck();
    console.log(`Found ${lowStockCount} low stock items`);

    // Wait for AI processing to complete
    console.log('\n⏳ Waiting for AI processing to complete (10 seconds)...');
    await new Promise(resolve => setTimeout(resolve, 10000));

    // Check reorder logs
    console.log('\n📋 Recent Activity:');
    try {
      const reorderLogs = await monitor.getRecentReorderLogs(3);
      reorderLogs.forEach((log, index) => {
        console.log(`${index + 1}. Product: ${log.product_name || 'Unknown'}`);
        console.log(`   Status: ${log.status}`);
        console.log(`   Supplier: ${log.supplier_name || 'Not assigned'}`);
        console.log(`   Admin Notified: ${log.admin_notification_sent ? '✅' : '❌'}`);
        console.log(`   Auto Order Started: ${log.auto_order_started ? '✅' : '❌'}`);
        if (log.total_cost) {
          console.log(`   Total Cost: $${log.total_cost}`);
        }
        console.log('');
      });
    } catch (error) {
      console.log('⚠️ Could not fetch reorder logs:', error.message);
    }

    // Check notifications
    console.log('📬 Recent Admin Notifications:');
    const notifications = await notificationService.getUnreadNotifications(1);
    notifications.slice(0, 3).forEach((notif, index) => {
      console.log(`${index + 1}. [${notif.priority.toUpperCase()}] ${notif.title}`);
      console.log(`   ${notif.message}`);
      console.log(`   Created: ${new Date(notif.created_at).toLocaleString()}`);
      console.log('');
    });

    console.log('\n🎉 System Demo Summary');
    console.log('=' .repeat(50));
    console.log('✅ Database-backed authentication system');
    console.log('✅ Real-time chat with persistent sessions');
    console.log('✅ Automated inventory monitoring');
    console.log('✅ AI-powered supplier communication');
    console.log('✅ Email/SMS admin notifications');
    console.log('✅ Complete reorder workflow automation');
    console.log('✅ Comprehensive logging and tracking');
    
    console.log('\n💡 Key Features Demonstrated:');
    console.log('• Low stock detection with configurable thresholds');
    console.log('• AI-generated professional supplier communications');
    console.log('• Multi-channel admin notifications (email, SMS, in-app)');
    console.log('• Automated quote comparison and supplier selection');
    console.log('• Complete audit trail of all inventory actions');
    console.log('• Graceful fallback when AI services are unavailable');

    // Cleanup
    await monitor.close();
    await aiService.close();
    await notificationService.close();
    await connection.end();

    console.log('\n✅ Complete System Demo finished successfully!');
    console.log('🚀 Your AI-powered inventory management system is ready for production!');

  } catch (error) {
    console.error('❌ Demo failed:', error);
  }
}

runCompleteSystemDemo();