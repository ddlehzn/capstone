-- Create monthly_sales table for storing monthly sales data
CREATE TABLE IF NOT EXISTS monthly_sales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sales_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
  expenses_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
  profit_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
  created_at DATE NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_month_year (created_at)
);
