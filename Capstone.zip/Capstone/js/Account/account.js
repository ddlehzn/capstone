// ==================== ACCOUNT MANAGEMENT SYSTEM ====================

class AccountManager {
  constructor() {
    this.users = [];
    this.selectedUsers = new Set();
    this.editingUserId = null;
    this.pendingFormData = null;
    this.currentFilters = {
      role: 'All',
      status: 'All',
      search: ''
    };
    
    this.initializeEventListeners();
    this.loadUsers();
  }

  // Get authentication headers
  getAuthHeaders() {
    const token = sessionStorage.getItem('auth.token');
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    };
  }

  // Initialize all event listeners
  initializeEventListeners() {
    // Modal functionality
const modal = document.getElementById('addStaffModal');
    const confirmModal = document.getElementById('confirmAddStaffModal');
const openBtn = document.getElementById('addStaffBtn');
    
    if (openBtn) {
      openBtn.addEventListener('click', () => this.openModal());
    }
    
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal || e.target.closest('[data-close]')) {
          this.closeModal();
        }
      });
    }

    if (confirmModal) {
      confirmModal.addEventListener('click', (e) => {
        if (e.target === confirmModal || e.target.closest('#cancelAddStaff')) {
          this.closeConfirmModal();
        }
      });
    }
    
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal && modal.classList.contains('show')) {
        this.closeModal();
      }
      if (e.key === 'Escape' && confirmModal && confirmModal.classList.contains('show')) {
        this.closeConfirmModal();
      }
    });

    // Form submission
    const form = modal?.querySelector('form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.handleFormSubmit(e);
        return false;
      });
    }

    // Confirmation modal buttons
    const confirmBtn = document.getElementById('confirmAddStaff');
    const cancelConfirmBtn = document.getElementById('cancelAddStaff');
    
    if (confirmBtn) {
      confirmBtn.addEventListener('click', () => this.confirmAddStaff());
    }
    
    if (cancelConfirmBtn) {
      cancelConfirmBtn.addEventListener('click', () => this.closeConfirmModal());
    }

    // Success modal button
    const closeSuccessBtn = document.getElementById('closeSuccessModal');
    if (closeSuccessBtn) {
      closeSuccessBtn.addEventListener('click', () => this.closeSuccessModal());
    }

    // Password reset modal buttons
    const closePasswordResetBtn = document.getElementById('closePasswordResetModal');
    const cancelPasswordResetBtn = document.getElementById('cancelPasswordReset');
    const confirmPasswordResetBtn = document.getElementById('confirmPasswordReset');
    
    if (closePasswordResetBtn) {
      closePasswordResetBtn.addEventListener('click', () => this.closePasswordResetModal());
    }
    
    if (cancelPasswordResetBtn) {
      cancelPasswordResetBtn.addEventListener('click', () => this.closePasswordResetModal());
    }
    
    if (confirmPasswordResetBtn) {
      confirmPasswordResetBtn.addEventListener('click', () => this.confirmPasswordReset());
    }

    // Search functionality
    const searchInput = document.querySelector('.search-wrap input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => this.handleSearch(e));
    }

    // Filter dropdowns
    const roleFilter = document.querySelectorAll('.select')[0];
    const statusFilter = document.querySelectorAll('.select')[1];
    
    if (roleFilter) {
      roleFilter.addEventListener('change', (e) => this.handleFilterChange('role', e.target.value));
    }
    
    if (statusFilter) {
      statusFilter.addEventListener('change', (e) => this.handleFilterChange('status', e.target.value));
    }

    // Bulk operations
    const selectAllBtn = document.querySelector('.link-btn');
    const clearBtn = document.querySelectorAll('.link-btn')[1];
    const deleteBtn = document.querySelector('.btn-danger');
    
    if (selectAllBtn) {
      selectAllBtn.addEventListener('click', () => this.selectAllUsers());
    }
    
    if (clearBtn) {
      clearBtn.addEventListener('click', () => this.clearSelection());
    }
    
    if (deleteBtn) {
      deleteBtn.addEventListener('click', () => this.deleteSelectedUsers());
    }
  }

  // Load users from API
  async loadUsers() {
    try {
      const params = new URLSearchParams();
      if (this.currentFilters.role !== 'All') params.append('role', this.currentFilters.role);
      if (this.currentFilters.status !== 'All') params.append('status', this.currentFilters.status);
      if (this.currentFilters.search.trim()) params.append('search', this.currentFilters.search);

      const response = await fetch(`http://localhost:3000/api/users?${params.toString()}`, {
        headers: this.getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      this.users = data.users || [];
      this.renderUsers();
    } catch (error) {
      console.error('Error loading users:', error);
      this.showError('Failed to load users. Please try again.');
    }
  }

  // Render users in the table
  renderUsers() {
    const staffCard = document.querySelector('.staff-card');
    if (!staffCard) return;

    // Remove existing staff items (keep header)
    const existingItems = staffCard.querySelectorAll('.staff-item');
    existingItems.forEach(item => item.remove());

    if (this.users.length === 0) {
      const noUsersRow = document.createElement('div');
      noUsersRow.className = 'staff-item grid-row';
      noUsersRow.innerHTML = `
        <div class="cell" style="grid-column: 1 / -1; text-align: center; padding: 20px; color: #666;">
          No users found
        </div>
      `;
      staffCard.appendChild(noUsersRow);
      return;
    }

    this.users.forEach(user => {
      const staffItem = document.createElement('div');
      staffItem.className = 'staff-item grid-row';
      staffItem.innerHTML = `
        <div class="cell cell-check">
          <input type="checkbox" ${this.selectedUsers.has(user.id) ? 'checked' : ''} 
                 onchange="accountManager.toggleUserSelection(${user.id})" />
        </div>
        <div class="cell"><strong>${this.escapeHtml(user.name)}</strong></div>
        <div class="cell">${this.escapeHtml(user.email)}</div>
        <div class="cell linkish">${this.escapeHtml(user.role)}</div>
        <div class="cell">
          <span class="status-pill">${this.escapeHtml(user.status)}</span>
        </div>
        <div class="cell cell-actions">
          <button class="btn btn-slate" onclick="accountManager.editUser(${user.id})">Edit</button>
          ${user.role !== 'Admin' ? `<button class="btn btn-warning" onclick="accountManager.resetPassword(${user.id}, '${this.escapeHtml(user.name)}')">Reset</button>` : ''}
        </div>
      `;
      staffCard.appendChild(staffItem);
    });
  }

  // Handle search input
  handleSearch(e) {
    this.currentFilters.search = e.target.value;
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => {
      this.loadUsers();
    }, 300); // Debounce search
  }

  // Handle filter changes
  handleFilterChange(filterType, value) {
    this.currentFilters[filterType] = value;
    this.loadUsers();
  }

  // Toggle user selection
  toggleUserSelection(userId) {
    if (this.selectedUsers.has(userId)) {
      this.selectedUsers.delete(userId);
    } else {
      this.selectedUsers.add(userId);
    }
    this.updateBulkActionButtons();
  }

  // Select all users
  selectAllUsers() {
    this.users.forEach(user => {
      if (user.id !== 1) { // Don't select admin user
        this.selectedUsers.add(user.id);
      }
    });
    this.renderUsers();
    this.updateBulkActionButtons();
  }

  // Clear selection
  clearSelection() {
    this.selectedUsers.clear();
    this.renderUsers();
    this.updateBulkActionButtons();
  }

  // Update bulk action buttons state
  updateBulkActionButtons() {
    const deleteBtn = document.querySelector('.btn-danger');
    const clearBtn = document.querySelectorAll('.link-btn')[1];
    
    if (deleteBtn) {
      deleteBtn.disabled = this.selectedUsers.size === 0;
      deleteBtn.style.opacity = this.selectedUsers.size === 0 ? '0.5' : '1';
    }
    
    if (clearBtn) {
      clearBtn.style.opacity = this.selectedUsers.size === 0 ? '0.5' : '1';
    }
  }

  // Delete selected users
  async deleteSelectedUsers() {
    if (this.selectedUsers.size === 0) return;

    const confirmMessage = this.selectedUsers.size === 1 
      ? 'Are you sure you want to delete this user?' 
      : `Are you sure you want to delete ${this.selectedUsers.size} users?`;

    if (!confirm(confirmMessage)) return;

    try {
      const response = await fetch('http://localhost:3000/api/users/bulk', {
        method: 'DELETE',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ userIds: Array.from(this.selectedUsers) })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete users');
      }

      const result = await response.json();
      this.showSuccessModal(result.message);
      this.clearSelection();
      this.loadUsers();
    } catch (error) {
      console.error('Error deleting users:', error);
      this.showError(error.message || 'Failed to delete users');
    }
  }

  // Open modal for adding/editing user
  openModal(userId = null) {
    this.editingUserId = userId;
    const modal = document.getElementById('addStaffModal');
    const title = document.getElementById('addTitle');
    const form = modal.querySelector('form');
    const passwordField = document.getElementById('passwordField');
    const passwordLabel = passwordField?.previousElementSibling;
    
    if (title) {
      title.textContent = userId ? 'Edit Staff' : 'Add Staff';
    }
    
    // Show/hide password field based on mode
    if (passwordField) {
      if (userId) {
        // Editing mode - hide password field and remove required attribute
        passwordField.style.display = 'none';
        passwordField.required = false;
        passwordField.removeAttribute('required');
        if (passwordLabel) passwordLabel.style.display = 'none';
      } else {
        // Adding mode - show password field and make it required
        passwordField.style.display = 'block';
        passwordField.required = true;
        passwordField.setAttribute('required', 'required');
        if (passwordLabel) passwordLabel.style.display = 'block';
      }
    }
    
    // Reset form
    if (form) {
      form.reset();
      
      // If editing, populate form with user data
      if (userId) {
        const user = this.users.find(u => u.id === userId);
        if (user) {
          form.querySelector('input[type="text"]').value = user.name || '';
          form.querySelector('input[type="email"]').value = user.email || '';
          
          // Set role and status
          const roleSelect = form.querySelectorAll('select')[0];
          const statusSelect = form.querySelectorAll('select')[1];
          
          if (roleSelect) {
            roleSelect.value = user.role || '';
          }
          
          if (statusSelect) {
            statusSelect.value = user.status || 'Active';
          }
        }
      }
    }
    
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  // Close modal
  closeModal() {
    const modal = document.getElementById('addStaffModal');
    modal.classList.remove('show');
    document.body.style.overflow = '';
    this.editingUserId = null;
  }

  // Show confirmation modal
  showConfirmModal() {
    const confirmModal = document.getElementById('confirmAddStaffModal');
    confirmModal.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  // Close confirmation modal
  closeConfirmModal() {
    const confirmModal = document.getElementById('confirmAddStaffModal');
    confirmModal.classList.remove('show');
    document.body.style.overflow = '';
  }

  // Confirm add staff
  confirmAddStaff() {
    this.closeConfirmModal();
    this.processAddStaff();
  }

  // Show success modal
  showSuccessModal(message) {
    const successModal = document.getElementById('successModal');
    const successMessage = document.getElementById('successMessage');
    
    if (successMessage) {
      successMessage.textContent = message;
    }
    
    successModal.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  // Close success modal
  closeSuccessModal() {
    const successModal = document.getElementById('successModal');
    successModal.classList.remove('show');
    document.body.style.overflow = '';
  }

  // Handle form submission
  async handleFormSubmit(e) {
    
    const form = e.target;
    
    // Get form values
    const name = form.querySelector('input[type="text"]').value.trim();
    const email = form.querySelector('input[type="email"]').value.trim();
    const role = form.querySelectorAll('select')[0].value;
    const status = form.querySelectorAll('select')[1].value;
    
    // Get password field (only if visible)
    const passwordField = document.getElementById('passwordField');
    const password = passwordField && passwordField.style.display !== 'none' ? passwordField.value.trim() : '';
    
    if (!name || !email || !role) {
      this.showError('Please fill in all required fields');
      return;
    }
    
    // Only validate password for new users (when editing, password is optional)
    if (!this.editingUserId && (!password || password.length < 6)) {
      this.showError('Password is required for new users (minimum 6 characters)');
      return;
    }

    // Store form data for later processing
    this.pendingFormData = {
      name,
      email,
      role,
      status,
      password
    };

    // Only show confirmation modal for adding new users, not editing
    if (!this.editingUserId) {
      this.showConfirmModal();
    } else {
      // For editing, process directly
      this.processAddStaff();
    }
  }

  // Process add staff after confirmation
  async processAddStaff() {
    const { name, email, role, status, password } = this.pendingFormData;

    try {
      // Parse name into first and last name
      const nameParts = name.split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';

      const userData = {
        username: email.split('@')[0], // Use email prefix as username
        email,
        firstName,
        lastName,
        role,
        status,
        phone: '', // Add phone field to form if needed
        ...(password && password.trim() && { password })
      };

      const url = this.editingUserId ? `http://localhost:3000/api/users/${this.editingUserId}` : 'http://localhost:3000/api/users';
      const method = this.editingUserId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: this.getAuthHeaders(),
        body: JSON.stringify(userData)
      });

      if (!response.ok) {
        let errorMessage = 'Failed to save user';
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch (parseError) {
          console.error('Failed to parse error response:', parseError);
          errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }

      const result = await response.json();
      this.closeModal();
      this.showSuccessModal(result.message);
      this.loadUsers();
    } catch (error) {
      console.error('Error saving user:', error);
      this.showError(error.message || 'Failed to save user');
    }
  }

  // Edit user
  editUser(userId) {
    this.openModal(userId);
  }

  // Show success message
  showSuccess(message) {
    // Simple alert for now - can be replaced with toast notification
    alert(`Success: ${message}`);
  }

  // Show error message
  showError(message) {
    alert(`Error: ${message}`);
  }

  // Escape HTML to prevent XSS
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Reset password functionality
  resetPassword(userId, userName) {
    this.resetPasswordUserId = userId;
    this.resetPasswordUserName = userName;
    this.openPasswordResetModal();
  }

  // Open password reset modal
  openPasswordResetModal() {
    const modal = document.getElementById('passwordResetModal');
    const messageEl = document.getElementById('passwordResetMessage');
    const userNameEl = document.getElementById('resetUserName');
    
    if (modal && messageEl && userNameEl) {
      userNameEl.textContent = this.resetPasswordUserName;
      modal.classList.add('show');
      
      // Focus on the first input
      const newPasswordInput = document.getElementById('newPasswordInput');
      if (newPasswordInput) {
        newPasswordInput.focus();
      }
    }
  }

  // Close password reset modal
  closePasswordResetModal() {
    const modal = document.getElementById('passwordResetModal');
    if (modal) {
      modal.classList.remove('show');
      
      // Clear form fields
      const newPasswordInput = document.getElementById('newPasswordInput');
      const confirmPasswordInput = document.getElementById('confirmPasswordInput');
      if (newPasswordInput) newPasswordInput.value = '';
      if (confirmPasswordInput) confirmPasswordInput.value = '';
    }
  }

  // Confirm password reset
  async confirmPasswordReset() {
    const newPassword = document.getElementById('newPasswordInput')?.value;
    const confirmPassword = document.getElementById('confirmPasswordInput')?.value;

    if (!newPassword || newPassword.length < 6) {
      alert('Password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      alert('Passwords do not match.');
      return;
    }

    try {
      const response = await fetch(`http://localhost:3000/api/users/${this.resetPasswordUserId}/reset-password`, {
        method: 'POST',
        headers: this.getAuthHeaders(),
        body: JSON.stringify({ newPassword })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to reset password');
      }

      const result = await response.json();
      this.closePasswordResetModal();
      this.showSuccessModal(`Password reset successfully for ${this.resetPasswordUserName}`);
      this.loadUsers(); // Refresh the user list
      
    } catch (error) {
      console.error('Password reset error:', error);
      alert(`Failed to reset password: ${error.message}`);
    }
  }
}

// Initialize account manager when DOM is loaded
let accountManager;
document.addEventListener('DOMContentLoaded', () => {
  accountManager = new AccountManager();
  initializeBurgerMenu();
});

// Burger menu functionality
function initializeBurgerMenu() {
  const burgerMenu = document.getElementById('burgerMenu');
  const mobileNavOverlay = document.getElementById('mobileNavOverlay');
  
  function openMobileMenu() {
    burgerMenu.classList.add('open');
    mobileNavOverlay.classList.add('active');
    // Only prevent body scroll when mobile menu is open
    if (window.innerWidth <= 768) {
      document.body.style.overflow = 'hidden';
    }
  }
  
  function closeMobileMenu() {
    burgerMenu.classList.remove('open');
    mobileNavOverlay.classList.remove('active');
    // Restore body scroll
    document.body.style.overflow = '';
  }
  
  if (burgerMenu && mobileNavOverlay) {
    // Toggle mobile menu
    burgerMenu.addEventListener('click', function() {
      if (mobileNavOverlay.classList.contains('active')) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    });
    
    // Close menu when clicking on overlay
    mobileNavOverlay.addEventListener('click', function(e) {
      if (e.target === mobileNavOverlay) {
        closeMobileMenu();
      }
    });
    
    // Close menu when clicking on a link
    const mobileNavLinks = mobileNavOverlay.querySelectorAll('a');
    mobileNavLinks.forEach(link => {
      link.addEventListener('click', closeMobileMenu);
    });
    
    // Close menu on window resize if it gets too large
    window.addEventListener('resize', function() {
      if (window.innerWidth > 768 && mobileNavOverlay.classList.contains('active')) {
        closeMobileMenu();
      }
      // Ensure body scroll is restored on resize
      if (window.innerWidth > 768) {
        document.body.style.overflow = '';
      }
    });
  }
}

// Legacy logout function
function logout() {
    showLogoutModal();
}