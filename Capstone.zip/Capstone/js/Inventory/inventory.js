const API_BASE = "http://localhost:3000/api/products";

let productsCache = [];
let productToDelete = null;

// Helpers
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
const byId = (id) => document.getElementById(id);
const peso = (n) => `₱ ${Number(n || 0).toLocaleString()}`;

// Modals
function showAddModal() {
  byId("addForm")?.reset();
  const prev = byId("addPreview");
  if (prev) { prev.src = ""; prev.style.display = "none"; }
  byId("addModal").style.display = "flex";
}
function closeAddModal() { byId("addModal").style.display = "none"; }

function showEditModal(product) {
  byId("editId").value = product.id;
  byId("editName").value = product.name ?? "";
  byId("editQuantity").value = product.quantity ?? "";
  byId("editPrice").value = product.price ?? "";
  byId("editModal").style.display = "flex";
}
function closeEditModal() { byId("editModal").style.display = "none"; }

function showDetailsModal(product) {
  byId("detailsName").textContent = product.name || "";
  byId("detailsQuantity").textContent = product.quantity || "";
  byId("detailsPrice").textContent = peso(product.price);
  byId("detailsModal").style.display = "flex";
}
function closeDetailsModal() { byId("detailsModal").style.display = "none"; }

function openDeleteModal(product) {
  productToDelete = product;
  byId("deleteModal").style.display = "flex";
}
function closeDeleteModal() {
  productToDelete = null;
  byId("deleteModal").style.display = "none";
}

// Render
function renderProducts(products) {
  const tbody = byId("product-table-body");
  if (!tbody) return;
  tbody.innerHTML = "";
  products.forEach((p) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>
        <div class="product-info">
          <span>${p.name || ""}</span>
        </div>
      </td>
      <td>${p.quantity ?? ""}</td>
      <td>${peso(p.price)}</td>
      <td>
        <button type="button" class="btn details-btn" data-id="${p.id}" title="View Details">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" fill="currentColor"/>
          </svg>
        </button>
        <button type="button" class="btn edit-btn" data-id="${p.id}" title="Edit Product">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" fill="currentColor"/>
          </svg>
        </button>
        <button type="button" class="btn delete-btn table-delete-btn" data-id="${p.id}" title="Delete Product">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="currentColor"/>
          </svg>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  $$(".details-btn", tbody).forEach((btn) => {
    btn.onclick = () => {
      const id = btn.getAttribute("data-id");
      const prod = productsCache.find((x) => String(x.id) === String(id));
      if (prod) showDetailsModal(prod);
    };
  });
  $$(".edit-btn", tbody).forEach((btn) => {
    btn.onclick = () => {
      const id = btn.getAttribute("data-id");
      const prod = productsCache.find((x) => String(x.id) === String(id));
      if (prod) showEditModal(prod);
    };
  });
  $$(".table-delete-btn", tbody).forEach((btn) => {
    btn.onclick = () => {
      const id = btn.getAttribute("data-id");
      const prod = productsCache.find((x) => String(x.id) === String(id));
      if (prod) openDeleteModal(prod);
    };
  });
}

// Auth headers helper
function getAuthHeaders() {
  const token = sessionStorage.getItem('auth.token');
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

// API
async function fetchProducts() {
  const res = await fetch(API_BASE, {
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error("Failed to fetch products");
  productsCache = await res.json();
  renderProducts(productsCache);
}

async function createProduct(fd) {
  const res = await fetch(API_BASE, { 
    method: "POST", 
    body: fd,
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Failed to add product (${res.status} ${res.statusText})`);
  }
  
  // Tolerate empty or non-JSON responses
  const ct = (res.headers.get("content-type") || "").toLowerCase();
  let result = null;
  if (ct.includes("application/json")) {
    try { result = await res.json(); } catch { result = null; }
  }
  
  // Trigger immediate inventory notification check for new products
  if (window.inventoryNotificationService) {
    setTimeout(() => {
      window.inventoryNotificationService.onInventoryUpdate();
    }, 500); // Small delay to ensure database is updated
  }
  
  return result;
}

async function updateProduct(id, payload) {
  const res = await fetch(`${API_BASE}/${id}`, {
    method: "PUT",
    headers: { 
      "Content-Type": "application/json",
      ...getAuthHeaders()
    },
    body: JSON.stringify(payload),
    credentials: 'include'
  });
  if (!res.ok) throw new Error("Failed to update product");
  
  const result = await res.json();
  
  // Trigger immediate inventory notification check
  if (window.inventoryNotificationService) {
    setTimeout(() => {
      window.inventoryNotificationService.onInventoryUpdate();
    }, 500); // Small delay to ensure database is updated
  }
  
  return result;
}

async function deleteProduct(id) {
  const res = await fetch(`${API_BASE}/${id}`, { 
    method: "DELETE",
    credentials: 'include',
    headers: getAuthHeaders()
  });
  if (!res.ok) throw new Error("Failed to delete product");
  
  const result = await res.json();
  
  // Trigger immediate inventory notification check after deletion
  if (window.inventoryNotificationService) {
    setTimeout(() => {
      window.inventoryNotificationService.onInventoryUpdate();
    }, 500); // Small delay to ensure database is updated
  }
  
  return result;
}

// Boot
document.addEventListener("DOMContentLoaded", async () => {
  $(".add-btn")?.addEventListener("click", showAddModal);

  // Photo functionality removed

  // Add (multipart for multer)
  const addForm = byId("addForm");
  if (addForm) {
    addForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const saveBtn = addForm.querySelector(".save-btn");
      try {
        saveBtn?.setAttribute("disabled", "true");

        const fd = new FormData();
        fd.append("name", byId("addName").value);
        fd.append("quantity", byId("addQuantity").value);
        fd.append("price", byId("addPrice").value);
        const file = byId("addPhoto")?.files?.[0];
        if (file) fd.append("photo", file); // multer.single('photo')

        const created = await createProduct(fd);
        if (created?.id) {
          productsCache = [created, ...productsCache];
          renderProducts(productsCache);
        } else {
          await fetchProducts();
        }
        closeAddModal();
      } catch (err) {
        console.error(err);
        alert(err.message || "Failed to add product");
      } finally {
        saveBtn?.removeAttribute("disabled");
      }
    });
  }

  // Edit
  const editForm = byId("editForm");
  if (editForm) {
    editForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        const id = byId("editId").value;
        const payload = {
          name: byId("editName").value,
          quantity: byId("editQuantity").value,
          price: byId("editPrice").value,
        };
        const updated = await updateProduct(id, payload);
        if (updated?.id) {
          productsCache = productsCache.map((p) =>
            String(p.id) === String(updated.id) ? { ...p, ...updated } : p
          );
          renderProducts(productsCache);
        } else {
          await fetchProducts();
        }
        closeEditModal();
      } catch (err) {
        alert(err.message || "Error updating product");
      }
    });
  }

  // Delete
  byId("confirmDeleteBtn")?.addEventListener("click", async () => {
    if (!productToDelete?.id) return alert("No product selected.");
    try {
      await deleteProduct(productToDelete.id);
      productsCache = productsCache.filter(
        (p) => String(p.id) !== String(productToDelete.id)
      );
      renderProducts(productsCache);
      closeDeleteModal();
    } catch (err) {
      alert(err.message || "Error deleting product");
    }
  });

  // Close buttons inside modals
  $$(".modal .cancel-btn").forEach((btn) => {
    btn.addEventListener("click", () => btn.closest(".modal")?.style && (btn.closest(".modal").style.display = "none"));
  });

  try { await fetchProducts(); } catch (err) { alert(err.message || "Unable to load products."); }
});

// Expose for inline handlers
window.showAddModal = showAddModal;
window.closeAddModal = closeAddModal;
window.showEditModal = showEditModal;
window.closeEditModal = closeEditModal;
window.showDetailsModal = showDetailsModal;
window.closeDetailsModal = closeDetailsModal;
window.openDeleteModal = openDeleteModal;
window.closeDeleteModal = closeDeleteModal;
window.logout = function logout() {
  showLogoutModal();
};