// Staff Inventory Management - Monitor Only
const API_BASE = "http://localhost:3000/api/products";

let productsCache = [];

// Helpers
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
const byId = (id) => document.getElementById(id);
const peso = (n) => `₱ ${Number(n || 0).toLocaleString()}`;

// Stock status helper
function getStockStatus(quantity) {
  const qty = Number(quantity) || 0;
  if (qty === 0) return { class: 'out-of-stock', text: 'Out of Stock' };
  if (qty <= 10) return { class: 'low-stock', text: 'Low Stock' };
  return { class: 'in-stock', text: 'In Stock' };
}

// Render products for staff monitoring (matching admin design, no action column)
function renderProducts(products) {
  const tbody = byId("product-table-body");
  if (!tbody) return;
  
  tbody.innerHTML = "";
  
  if (products.length === 0) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td colspan="3" style="text-align: center; padding: 2rem; color: #666;">
        No products found in inventory
      </td>
    `;
    tbody.appendChild(tr);
    return;
  }
  
  products.forEach((p) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>
        <div class="product-info">
          <span>${p.name || ""}</span>
        </div>
      </td>
      <td>${p.quantity ?? ""}</td>
      <td>${peso(p.price)}</td>
    `;
    tbody.appendChild(tr);
  });
}

// Auth headers helper
function getAuthHeaders() {
  const token = sessionStorage.getItem('auth.token');
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

// API - Read only for staff
async function fetchProducts() {
  try {
    console.log('Staff: Fetching products from:', API_BASE);
    console.log('Staff: Auth headers:', getAuthHeaders());
    
    const res = await fetch(API_BASE, {
      credentials: 'include',
      headers: getAuthHeaders()
    });
    
    console.log('Staff: Response status:', res.status);
    console.log('Staff: Response ok:', res.ok);
    
    if (!res.ok) {
      const errorText = await res.text();
      console.error('Staff: Error response:', errorText);
      throw new Error(`Failed to fetch products: ${res.status} ${errorText}`);
    }
    
    productsCache = await res.json();
    console.log('Staff: Products fetched:', productsCache.length, 'products');
    console.log('Staff: Products data:', productsCache);
    renderProducts(productsCache);
  } catch (err) {
    console.error("Staff: Error fetching products:", err);
    showErrorMessage("Unable to load inventory data: " + err.message);
  }
}

// Error handling
function showErrorMessage(message) {
  const tbody = byId("product-table-body");
  if (!tbody) return;
  
  tbody.innerHTML = `
    <tr>
      <td colspan="3" style="text-align: center; padding: 2rem; color: #e74c3c;">
        <strong>⚠ ${message}</strong><br>
        <button onclick="location.reload()" style="margin-top: 1rem; padding: 0.5rem 1rem; background: #0d3c69; color: white; border: none; border-radius: 4px; cursor: pointer;">
          Retry
        </button>
      </td>
    </tr>
  `;
}

// Auto-refresh functionality
function startAutoRefresh() {
  // Refresh every 30 seconds
  setInterval(async () => {
    try {
      await fetchProducts();
    } catch (err) {
      console.error("Auto-refresh failed:", err);
    }
  }, 30000);
}

// Initialize staff inventory monitoring
document.addEventListener("DOMContentLoaded", async () => {
  try {
    // Initial load
    await fetchProducts();
    
    // Start auto-refresh
    startAutoRefresh();
    
    // Add monitoring info
    console.log("Staff inventory monitoring initialized");
    
  } catch (err) {
    console.error("Failed to initialize staff inventory:", err);
    showErrorMessage("Failed to initialize inventory monitoring");
  }
});

// Expose logout function
window.logout = function logout() {
  showLogoutModal();
};

// Export for potential use by other modules
window.StaffInventory = {
  refresh: fetchProducts,
  getProducts: () => [...productsCache],
  getStockStatus
};