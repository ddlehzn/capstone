function logout() {
    showLogoutModal();
}

// Initialize sales page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Restore saved filter selection
    restoreFilterSelection();
    
    // Initialize charts for sales page
    if (window.chartManager) {
        window.chartManager.initializeSalesPage();
    }
    
    // Attach sales filter functionality
    attachSalesFilter();
    
    // Attach data table upload functionality
    attachDataTableUpload();
    
    // Attach calendar date filtering functionality
    attachDateFiltering();
    
    // Load uploaded data on page load
    loadUploadedData();
    
    // Override the modal opening to pass current filter
    overrideModalOpen();
});

// Restore saved filter selection from localStorage
function restoreFilterSelection() {
    const select = document.getElementById('salesFilterSelect');
    if (!select) {
        console.warn('Sales filter select element not found');
        return;
    }
    
    // Get saved filter from localStorage
    const savedFilter = localStorage.getItem('salesManagementFilter');
    if (savedFilter && ['monthly', 'weekly', 'daily'].includes(savedFilter)) {
        console.log('Restoring saved filter:', savedFilter);
        select.value = savedFilter;
        
        // Trigger the filter change to update the chart
        setTimeout(() => {
            const event = new Event('change', { bubbles: true });
            select.dispatchEvent(event);
        }, 100);
    } else {
        console.log('No saved filter found, using default (monthly)');
        select.value = 'monthly';
    }
}

// Save filter selection to localStorage
function saveFilterSelection(filterValue) {
    localStorage.setItem('salesManagementFilter', filterValue);
    console.log('Saved filter selection:', filterValue);
}

// Load existing data table from database
async function loadExistingDataTable() {
    try {
        const res = await fetch('http://localhost:3000/api/sales/data-table', {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Authorization': `Bearer ${sessionStorage.getItem('auth.token')}`
            }
        });

        if (res.ok) {
            const result = await res.json();
            if (result.success && result.data) {
                displayDataInTable(result.data, result.fileName);
                console.log('Loaded existing data table:', result.fileName);
            } else {
                console.log('No existing data table found');
            }
        } else {
            console.error('Failed to load existing data table');
        }
    } catch (error) {
        console.error('Error loading existing data table:', error);
    }
}

// Override the modal opening function to pass current filter selection
function overrideModalOpen() {
    const infoIcon = document.querySelector('.info-icon');
    if (infoIcon) {
        infoIcon.addEventListener('click', function() {
            const select = document.getElementById('salesFilterSelect');
            const currentFilter = select ? select.value : 'monthly';
            
            console.log('Opening modal with filter:', currentFilter);
            
            // Call the modal with the current filter context
            if (window.openChartModal) {
                window.openChartModal('monthly-sales', currentFilter);
            }
        });
    }
}

// Attach sales filter functionality similar to dashboard
function attachSalesFilter() {
    const select = document.getElementById('salesFilterSelect');
    
    if (!select) {
        console.warn('Sales filter elements not found');
        return;
    }

    // Handle filter change
    select.addEventListener('change', async () => {
        const value = select.value; // monthly, weekly, or daily
        
        // Save the filter selection to localStorage
        saveFilterSelection(value);
        
        try {
            if (value === 'monthly') {
                // Show monthly sales data
                const apiData = await window.chartManager.fetchMonthlySalesApi();
                if (apiData) {
                    window.chartManager.createMonthlySalesTrendsChart('monthlySalesTrendsChart', apiData);
                } else {
                    // Fallback to default monthly data
                    const monthlyData = {
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                        datasets: [{
                            label: 'Monthly Sales',
                            data: [65, 78, 82, 89, 95, 88, 92, 98, 105, 112, 118, 125],
                            borderColor: '#0d3c69',
                            backgroundColor: 'rgba(13, 60, 105, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.3,
                            pointBackgroundColor: '#0d3c69',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 4
                        }]
                    };
                    window.chartManager.createMonthlySalesTrendsChart('monthlySalesTrendsChart', monthlyData);
                }
            } else if (value === 'weekly') {
                // Show weekly sales data
                const apiData = await window.chartManager.fetchWeeklySalesApi();
                if (apiData) {
                    window.chartManager.createWeeklySalesChart('monthlySalesTrendsChart', apiData);
                } else {
                    // Fallback to default weekly data
                    const weeklyData = {
                        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                        datasets: [{
                            label: 'Weekly Sales',
                            data: [120, 150, 130, 170, 200, 220, 180],
                            borderColor: '#0d3c69',
                            backgroundColor: 'rgba(13, 60, 105, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointBackgroundColor: '#0d3c69',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 4
                        }]
                    };
                    window.chartManager.createWeeklySalesChart('monthlySalesTrendsChart', weeklyData);
                }
            } else if (value === 'daily') {
                // Show daily sales data
                const apiData = await window.chartManager.fetchDailySalesApi();
                if (apiData) {
                    window.chartManager.createDailySalesChart('monthlySalesTrendsChart', apiData);
                } else {
                    // Fallback to default daily data
                    const dailyData = {
                        labels: ['6 AM', '8 AM', '10 AM', '12 PM', '2 PM', '4 PM', '6 PM', '8 PM'],
                        datasets: [{
                            label: 'Daily Sales',
                            data: [45, 120, 180, 220, 160, 140, 200, 90],
                            borderColor: '#0d3c69',
                            backgroundColor: 'rgba(13, 60, 105, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointBackgroundColor: '#0d3c69',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 4
                        }]
                    };
                    window.chartManager.createDailySalesChart('monthlySalesTrendsChart', dailyData);
                }
            }
        } catch (err) {
            console.error('Error switching sales chart:', err);
        }
    });

}

// Update chart after successful upload
function updateChartAfterUpload(selectValue, uploadResponse) {
    console.log('=== updateChartAfterUpload called ===');
    console.log('selectValue:', selectValue);
    console.log('uploadResponse:', uploadResponse);
    
    try {
        if (selectValue === 'monthly' && uploadResponse.labels && uploadResponse.sales) {
            console.log('Creating monthly chart with upload data');
            
            const ds = {
                labels: uploadResponse.labels,
                datasets: [{
                    label: 'Monthly Sales',
                    data: uploadResponse.sales,
                    borderColor: '#0d3c69',
                    backgroundColor: 'rgba(13, 60, 105, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: '#0d3c69',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            };
            window.chartManager.createMonthlySalesTrendsChart('monthlySalesTrendsChart', ds);
            
        } else if (selectValue === 'weekly' && uploadResponse.type === 'weekly' && uploadResponse.labels && uploadResponse.data) {
            console.log('Creating weekly chart with upload data');
            
            const ds = {
                labels: uploadResponse.labels,
                datasets: [{
                    label: 'Weekly Sales',
                    data: uploadResponse.data,
                    borderColor: '#0d3c69',
                    backgroundColor: 'rgba(13, 60, 105, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#0d3c69',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            };
            window.chartManager.createWeeklySalesChart('monthlySalesTrendsChart', ds);
            
        } else if (selectValue === 'daily' && uploadResponse.type === 'daily' && uploadResponse.labels && uploadResponse.data) {
            console.log('Creating daily chart with upload data');
            
            const ds = {
                labels: uploadResponse.labels,
                datasets: [{
                    label: 'Daily Sales',
                    data: uploadResponse.data,
                    borderColor: '#0d3c69',
                    backgroundColor: 'rgba(13, 60, 105, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#0d3c69',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            };
            window.chartManager.createDailySalesChart('monthlySalesTrendsChart', ds);
        }
        
        console.log('Chart updated successfully after upload');
        
    } catch (error) {
        console.error('Error updating chart after upload:', error);
    }
}

// Attach data table upload functionality
function attachDataTableUpload() {
    const uploadBtn = document.getElementById('tableUploadBtn');
    const uploadInput = document.getElementById('tableUploadInput');
    
    if (!uploadBtn || !uploadInput) {
        console.warn('Data table upload elements not found');
        return;
    }

    // Handle upload button click
    uploadBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadInput.click();
    });

    // Handle file upload for data table
    uploadInput.addEventListener('change', async (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) {
            return;
        }
        
        // Show custom confirmation modal
        showConfirmationModal(file.name, () => {
            // User confirmed, proceed with upload
            proceedWithUpload(file);
        }, () => {
            // User cancelled, reset the input
            uploadInput.value = '';
        });
    });
}

// Read and parse uploaded file
async function readAndParseFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            try {
                const data = e.target.result;
                let parsedData = [];
                
                if (file.name.endsWith('.csv')) {
                    // Parse CSV
                    parsedData = parseCSV(data);
                } else {
                    reject(new Error('Please use CSV files for direct preview, or use the server upload for Excel files.'));
                    return;
                }
                
                resolve(parsedData);
            } catch (error) {
                reject(error);
            }
        };
        
        reader.onerror = function() {
            reject(new Error('Error reading file'));
        };
        
        reader.readAsText(file);
    });
}

// Parse CSV data
function parseCSV(csvText) {
    const lines = csvText.split('\n');
    const data = [];
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line) {
            // Simple CSV parsing (handles basic cases)
            const values = line.split(',').map(value => value.trim().replace(/^"|"$/g, ''));
            data.push(values);
        }
    }
    
    return data;
}

// Function to display uploaded data from database in the uploaded data table
function displayUploadedDataFromDatabase(data, fileName) {
    const dataTableBody = document.getElementById('dataTableBody');
    if (!dataTableBody) {
        console.error('Data table body not found');
        return;
    }

    // Clear existing content
    dataTableBody.innerHTML = '';

    // Filter out empty records
    const validData = data.filter(item => {
        return item.date && item.sales && 
               item.date.toString().trim() !== '' && 
               item.sales.toString().trim() !== '';
    });

    console.log(`Filtered ${validData.length} valid records from ${data.length} total records`);

    if (validData.length === 0) {
        // Show "No data uploaded yet" message if no valid data
        dataTableBody.innerHTML = `
            <tr>
                <td colspan="2" style="text-align: center; color: #999; padding: 20px;">
                    No data uploaded yet
                </td>
            </tr>
        `;
        
        // Update file info
        const fileInfo = document.querySelector('.uploaded-data-section .file-info');
        if (fileInfo) {
            fileInfo.textContent = 'File: No file uploaded';
        }
        return;
    }

    // Create table rows for valid uploaded data
    validData.forEach(item => {
        const row = document.createElement('tr');
        
        // Format the date properly
        let formattedDate = item.date;
        if (!isNaN(item.date) && parseFloat(item.date) > 25569) {
            // Convert Excel serial number to JavaScript date
            const excelDate = new Date((parseFloat(item.date) - 25569) * 86400 * 1000);
            formattedDate = excelDate.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
        } else if (item.date && item.date.includes('-')) {
            // Format ISO date string
            const date = new Date(item.date);
            if (!isNaN(date.getTime())) {
                formattedDate = date.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
            }
        }
        
        // Format the sales value
        const salesValue = parseFloat(item.sales);
        const formattedSales = isNaN(salesValue) ? '0' : salesValue.toLocaleString();
        
        row.innerHTML = `
            <td>${formattedDate}</td>
            <td>₱${formattedSales}</td>
        `;
        dataTableBody.appendChild(row);
    });

    // Update file info
    const fileInfo = document.querySelector('.uploaded-data-section .file-info');
    if (fileInfo) {
        fileInfo.textContent = `File: ${fileName} (${validData.length} records)`;
    }

    console.log(`Displayed ${validData.length} valid records in uploaded data table from database`);
}

// Function to display daily sales data in the uploaded data table
function displayDailyDataInTable(dailyData, fileName) {
    const dataTableBody = document.getElementById('dataTableBody');
    if (!dataTableBody) {
        console.error('Data table body not found');
        return;
    }

    // Clear existing content
    dataTableBody.innerHTML = '';

    // Create table rows for daily data
    dailyData.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.date}</td>
            <td>${item.sales.toLocaleString()}</td>
        `;
        dataTableBody.appendChild(row);
    });

    // Update file info
    const fileInfo = document.querySelector('.uploaded-data-section .file-info');
    if (fileInfo) {
        fileInfo.textContent = `File: ${fileName} (${dailyData.length} daily records)`;
    }

    console.log(`Displayed ${dailyData.length} daily records in uploaded data table`);
}

// Display data in the table
function displayDataInTable(data, fileName, uploadResult = null) {
    // Update file name display
    const fileNameElement = document.getElementById('fileName');
    if (fileNameElement) {
        fileNameElement.textContent = fileName;
    }
    
    // Update row count display
    const rowCountElement = document.getElementById('rowCount');
    if (rowCountElement) {
        rowCountElement.textContent = `(${data ? data.length : 0} rows)`;
    }
    
    const tableBody = document.getElementById('dataTableBody');
    if (!tableBody) {
        console.error('Data table body not found');
        return;
    }
    
    if (!data || data.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="2" class="no-data">No data uploaded</td>
            </tr>
        `;
        return;
    }
    
    // Create table HTML
    let tableHTML = `
        <div class="table-info" style="background: #f8f9fa; padding: 15px; border-bottom: 1px solid #dee2e6; border-radius: 8px 8px 0 0; margin-bottom: 0;">
            <p style="margin: 0; color: #666; font-size: 14px;"><strong>File:</strong> ${fileName} | <strong>Rows:</strong> ${data.length}</p>
    `;
    
    // Add incremental upload information if available
    if (uploadResult && uploadResult.isIncremental && uploadResult.newRecordsCount !== undefined) {
        tableHTML += `
            <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;"><strong>Upload Type:</strong> Incremental | <strong>New Records:</strong> ${uploadResult.newRecordsCount || 0} | <strong>Duplicates Skipped:</strong> ${uploadResult.skippedRecordsCount || 0}</p>
        `;
    }
    
    // Add daily data processing information if available
    if (uploadResult && uploadResult.dailyDataProcessed) {
        tableHTML += `
            <p style="margin: 5px 0 0 0; color: #0d3c69; font-size: 14px; font-weight: 600;"><strong>✓ Daily Sales Chart Updated:</strong> Data has been processed and added to the Sales per Day chart</p>
        `;
    }
    
    tableHTML += `
        </div>
        <div class="table-wrapper-centered" style="background: white; border-radius: 0 0 8px 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow-x: auto; max-height: 400px; overflow-y: auto; padding: 0 20px;">
            <table class="data-table" style="width: 100%; border-collapse: separate; border-spacing: 0 8px; margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; min-width: 600px;">
            <thead>
                <tr>
    `;
    
    // Create header row with meaningful column names
    if (data.length > 0) {
        const columnCount = data[0].length;
        const headers = [];
        
        // Determine appropriate headers based on column count and content
        if (columnCount === 2) {
            headers.push('Date', 'Sales');
        } else if (columnCount === 3) {
            headers.push('Date', 'Sales', 'Notes');
        } else {
            // Generic headers for other cases
            for (let i = 0; i < columnCount; i++) {
                headers.push(`Column ${i + 1}`);
            }
        }
        
        headers.forEach(header => {
            tableHTML += `<th style="background-color: #f8f9fa; padding: 12px 20px; font-weight: 600; color: #333; border-bottom: 2px solid #dee2e6; text-align: left; min-width: 150px;">${header}</th>`;
        });
    }
    
    tableHTML += `
                </tr>
            </thead>
            <tbody>
    `;
    
    // Create data rows - only show rows with actual data (skip header row if it exists)
    data.forEach((row, index) => {
        // Skip empty rows
        if (row.every(cell => !cell || cell.toString().trim() === '')) {
            return;
        }
        
        // Skip the first row if it contains headers (like "Date", "Sales")
        if (index === 0 && row.some(cell => 
            cell && typeof cell === 'string' && 
            (cell.toLowerCase() === 'date' || cell.toLowerCase() === 'sales' || cell.toLowerCase().includes('column'))
        )) {
            return; // Skip this row as it's a header
        }
        
        tableHTML += '<tr>';
        row.forEach(cell => {
            const cellValue = cell || '';
            tableHTML += `<td style="padding: 12px 20px; background: white; border: 1px solid #eee; border-radius: 4px; color: #555; min-width: 150px;" title="${cellValue}">${cellValue}</td>`;
        });
        tableHTML += '</tr>';
    });
    
    tableHTML += `
            </tbody>
        </table>
        </div>
    `;
    
    // Extract just the table rows from the HTML
    try {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = tableHTML;
        const tbody = tempDiv.querySelector('tbody');
        if (tbody && tableBody) {
            tableBody.innerHTML = tbody.innerHTML;
        }
    
    // Remove any existing inline styles to avoid duplication
    const existingStyles = document.querySelectorAll('style[data-table-styles]');
    existingStyles.forEach(style => style.remove());
    } catch (extractError) {
        console.error('Error extracting table content:', extractError);
        // Fallback: just show a simple message
        if (tableBody) {
            tableBody.innerHTML = '<tr><td colspan="2" class="no-data">Data loaded successfully</td></tr>';
        }
    }
}

// Custom confirmation modal functions
function showConfirmationModal(fileName, onConfirm, onCancel) {
    const modal = document.getElementById('confirmationModal');
    const message = document.getElementById('confirmationMessage');
    
    // Update the message with file name
    message.textContent = `Are you sure you want to upload "${fileName}" to display its data?`;
    
    // Store the callbacks globally for the modal buttons
    window.confirmationCallbacks = { onConfirm, onCancel };
    
    // Show the modal
    modal.classList.add('show');
}

function closeConfirmationModal() {
    const modal = document.getElementById('confirmationModal');
    modal.classList.remove('show');
    
    // Call cancel callback if it exists
    if (window.confirmationCallbacks && window.confirmationCallbacks.onCancel) {
        window.confirmationCallbacks.onCancel();
    }
    
    // Clear callbacks
    window.confirmationCallbacks = null;
}

function confirmUpload() {
    const modal = document.getElementById('confirmationModal');
    modal.classList.remove('show');
    
    // Call confirm callback if it exists
    if (window.confirmationCallbacks && window.confirmationCallbacks.onConfirm) {
        window.confirmationCallbacks.onConfirm();
    }
    
    // Clear callbacks
    window.confirmationCallbacks = null;
}

// Refactored upload function
async function proceedWithUpload(file) {
    try {
        console.log('Starting data table upload request...');
        console.log('File:', file.name, 'Type:', file.type);
        
        let fileData = [];
        
        // Handle Excel files with server processing
        if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
            const formData = new FormData();
            formData.append('file', file);
            
            const res = await fetch('http://localhost:3000/api/sales/parse-file', {
                method: 'POST',
                body: formData,
                credentials: 'include',
                headers: {
                    'Authorization': `Bearer ${sessionStorage.getItem('auth.token')}`
                }
            });
            
            if (!res.ok) {
                const errorText = await res.text();
                throw new Error(`Server error: ${res.status} ${errorText}`);
            }
            
            const result = await res.json();
            if (result.success && result.data) {
                fileData = result.data;
                console.log('Excel file parsed by server:', result);
            } else {
                throw new Error(result.error || 'Failed to parse Excel file');
            }
        } else {
            // Handle CSV files locally
            fileData = await readAndParseFile(file);
        }
        
        if (fileData && fileData.length > 0) {
            try {
            // Show incremental upload message if applicable
                let uploadMessage = 'Data uploaded successfully!';
                if (result && result.uploadedDataIncremental) {
                    const processedCount = result.uploadedDataNewCount || 0;
                    const skippedCount = result.uploadedDataSkippedCount || 0;
                    uploadMessage = `Incremental upload: ${processedCount} records processed (new/updated)`;
                    if (skippedCount > 0) {
                        uploadMessage += `, ${skippedCount} unchanged records skipped`;
                    }
                }
                console.log(uploadMessage);
                
                // Always refresh the uploaded data table from database after upload
                console.log('Refreshing uploaded data table from database...');
                
                // Refresh the uploaded data table from database
                setTimeout(async () => {
                    try {
                        const response = await fetch('http://localhost:3000/api/sales/uploaded-data', {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': `Bearer ${sessionStorage.getItem('auth.token')}`
                            }
                        });
                        
                        if (response.ok) {
                            const data = await response.json();
                            if (data.success && data.data && data.data.length > 0) {
                                // Update the uploaded data table with data from database
                                displayUploadedDataFromDatabase(data.data, data.fileName);
                                console.log('Uploaded data table updated from database');
                                
                                // Show success message to user
                                if (typeof showToast === 'function') {
                                    showToast(uploadMessage, 'success');
                                }
                            } else {
                                // Clear the table if no data is found
                                clearUploadedDataTable();
                            }
                        } else {
                            // Clear the table if there's an error
                            clearUploadedDataTable();
                        }
                    } catch (error) {
                        console.error('Error fetching uploaded data from database:', error);
                        // Clear the table if there's an error
                        clearUploadedDataTable();
                    }
                }, 500);
            
            // If daily data was processed, refresh the daily sales chart
            if (result && result.dailyDataProcessed) {
                console.log('Daily data was processed, refreshing daily sales chart...');
                
                // Refresh the daily sales chart if it's currently displayed
                const select = document.getElementById('salesFilterSelect');
                if (select && select.value === 'daily') {
                    setTimeout(async () => {
                        try {
                            const apiData = await window.chartManager.fetchDailySalesApi();
                            if (apiData) {
                                window.chartManager.createDailySalesChart('monthlySalesTrendsChart', apiData);
                                console.log('Daily sales chart refreshed with new data');
                                
                                // Show a subtle notification
                                const notification = document.createElement('div');
                                notification.style.cssText = `
                                    position: fixed;
                                    top: 20px;
                                    right: 20px;
                                    background: #0d3c69;
                                    color: white;
                                    padding: 12px 20px;
                                    border-radius: 6px;
                                    font-size: 14px;
                                    font-weight: 600;
                                    z-index: 1000;
                                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                                `;
                                notification.textContent = '✓ Daily Sales Chart Updated';
                                document.body.appendChild(notification);
                                
                                // Remove notification after 3 seconds
                                setTimeout(() => {
                                    if (notification.parentNode) {
                                        notification.parentNode.removeChild(notification);
                                    }
                                }, 3000);
                            }
                        } catch (error) {
                            console.error('Error refreshing daily sales chart:', error);
                        }
                    }, 1000); // Wait 1 second for database to be ready
                }
            }
            } catch (displayError) {
                console.error('Error displaying data in table:', displayError);
                // Don't show error alert for display issues, just log it
            }
        } else {
            alert('No data found in the file or file format not supported.');
            // Clear the table if no data is found
            clearUploadedDataTable();
        }
        
    } catch (err) {
        console.error('Data table upload error:', err);
        
        // Only show error alerts for actual upload failures, not display issues
        if (err.name === 'AbortError') {
            alert('Upload timed out. Please try again with a smaller file.');
        } else if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
            // Only show network error if we haven't already processed the file successfully
            if (!fileData || fileData.length === 0) {
                alert('Network connection issue. Please check your connection and try again.');
            }
        } else if (!err.message.includes('display') && !err.message.includes('table')) {
            // Only show error for non-display related issues
            alert('Error reading file: ' + err.message);
        }
        
        // Clear the table on any error
        clearUploadedDataTable();
    } finally {
        const uploadInput = document.getElementById('tableUploadInput');
        uploadInput.value = '';
    }
}

// Clear uploaded data table and show "No data uploaded yet" message
function clearUploadedDataTable() {
    const dataTableBody = document.getElementById('dataTableBody');
    if (!dataTableBody) {
        console.error('Data table body not found');
        return;
    }

    // Clear existing content and show "No data uploaded yet" message
    dataTableBody.innerHTML = `
        <tr>
            <td colspan="2" style="text-align: center; color: #999; padding: 20px;">
                No data uploaded yet
            </td>
        </tr>
    `;

    // Update file info
    const fileNameElement = document.getElementById('fileName');
    const rowCountElement = document.getElementById('rowCount');
    
    if (fileNameElement) {
        fileNameElement.textContent = 'No file uploaded';
    }
    
    if (rowCountElement) {
        rowCountElement.textContent = '';
    }
}

// Attach date filtering functionality
function attachDateFiltering() {
    const datePicker = document.getElementById('dataTableDatePicker');
    const clearDateBtn = document.getElementById('clearDateFilter');
    const calendarIcon = document.querySelector('.calendar-icon');
    
    if (!datePicker || !clearDateBtn) {
        console.log('Date picker or clear button not found');
        return;
    }
    
    // Store original data for filtering
    let originalData = [];
    let currentFilteredData = [];
    
    // Date picker change event
    datePicker.addEventListener('change', function() {
        const selectedDate = this.value;
        if (selectedDate) {
            filterTableByDate(selectedDate);
        } else {
            showAllData();
        }
    });
    
    // Date picker click event to open picker
    datePicker.addEventListener('click', function() {
        this.showPicker();
    });
    
    // Clear date filter button
    clearDateBtn.addEventListener('click', function() {
        datePicker.value = '';
        showAllData();
    });
    
    // Calendar icon click handler to open date picker
    if (calendarIcon) {
        calendarIcon.addEventListener('click', function() {
            datePicker.focus();
            datePicker.showPicker();
        });
    }
    
    // Function to filter table by selected date
    function filterTableByDate(selectedDate) {
        if (originalData.length === 0) {
            console.log('No original data to filter');
            return;
        }
        
        const selectedDateObj = new Date(selectedDate);
        currentFilteredData = originalData.filter(item => {
            let itemDate;
            
            // Handle different date formats
            if (!isNaN(item.date) && parseFloat(item.date) > 25569) {
                // Excel serial number
                itemDate = new Date((parseFloat(item.date) - 25569) * 86400 * 1000);
            } else if (item.date && item.date.includes('-')) {
                // ISO date string
                itemDate = new Date(item.date);
            } else {
                return false;
            }
            
            // Compare dates (year, month, day only)
            return itemDate.getFullYear() === selectedDateObj.getFullYear() &&
                   itemDate.getMonth() === selectedDateObj.getMonth() &&
                   itemDate.getDate() === selectedDateObj.getDate();
        });
        
        displayFilteredData(currentFilteredData);
        console.log(`Filtered to ${currentFilteredData.length} records for date: ${selectedDate}`);
    }
    
    // Function to show all data
    function showAllData() {
        if (originalData.length > 0) {
            displayFilteredData(originalData);
            console.log(`Showing all ${originalData.length} records`);
        }
    }
    
    // Function to display filtered data
    function displayFilteredData(data) {
        const dataTableBody = document.getElementById('dataTableBody');
        if (!dataTableBody) {
            console.error('Data table body not found');
            return;
        }
        
        // Clear existing content
        dataTableBody.innerHTML = '';
        
        // Create table rows for filtered data
        data.forEach(item => {
            const row = document.createElement('tr');
            
            // Format the date properly
            let formattedDate = item.date;
            if (!isNaN(item.date) && parseFloat(item.date) > 25569) {
                // Convert Excel serial number to JavaScript date
                const excelDate = new Date((parseFloat(item.date) - 25569) * 86400 * 1000);
                formattedDate = excelDate.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
            } else if (item.date && item.date.includes('-')) {
                // Format ISO date string
                const date = new Date(item.date);
                if (!isNaN(date.getTime())) {
                    formattedDate = date.toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'short', 
                        day: 'numeric' 
                    });
                }
            }
            
            // Format the sales value
            const formattedSales = parseFloat(item.sales).toLocaleString();
            
            row.innerHTML = `
                <td>${formattedDate}</td>
                <td>₱${formattedSales}</td>
            `;
            dataTableBody.appendChild(row);
        });
    }
    
    // Override the displayUploadedDataFromDatabase function to store original data
    window.displayUploadedDataFromDatabase = function(data, fileName) {
        // Store original data for filtering
        originalData = data;
        
        // Display all data initially
        displayFilteredData(data);
        
    // Update file info - target the specific elements
    const fileNameElement = document.getElementById('fileName');
    const rowCountElement = document.getElementById('rowCount');
    
    if (fileNameElement) {
        fileNameElement.textContent = fileName;
    } else {
        console.log('File name element not found');
    }
    
    if (rowCountElement) {
        rowCountElement.textContent = `(${data.length} records)`;
    } else {
        console.log('Row count element not found');
    }
        
        console.log(`Displayed ${data.length} records in uploaded data table from database`);
    };
}

// Load uploaded data on page load
async function loadUploadedData() {
    try {
        console.log('Loading uploaded data from database...');
        const response = await fetch('http://localhost:3000/api/sales/uploaded-data', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${sessionStorage.getItem('auth.token')}`
            }
        });

        console.log('Response status:', response.status);
        console.log('Response ok:', response.ok);

        if (response.ok) {
            const data = await response.json();
            console.log('Uploaded data response:', data);
            if (data.success && data.data && data.data.length > 0) {
                displayUploadedDataFromDatabase(data.data, data.fileName);
                console.log('Loaded uploaded data from database on page load');
            } else {
                console.log('No uploaded data found in response:', data);
                // Clear the table and show "No data uploaded yet" message
                clearUploadedDataTable();
            }
        } else {
            console.error('Failed to load uploaded data, status:', response.status);
            const errorText = await response.text();
            console.error('Error response:', errorText);
        }
    } catch (error) {
        console.error('Error loading uploaded data:', error);
    }
}
