const REDIRECTS = {
  admin: 'module/dashboard.html',
  staff: 'module/staff_dashboard.html'
};

async function login(e) {
  if (e?.preventDefault) e.preventDefault();

  const usernameEl = document.getElementById('username');
  const passwordEl = document.getElementById('password');

  const username = usernameEl?.value?.trim() || '';
  const password = passwordEl?.value || '';

  if (!username || !password) {
    alert('Please enter both username and password.');
    return;
  }

  // Validate email format (must contain @ symbol)
  if (!username.includes('@')) {
    alert('Please enter a valid email address as your username.');
    return;
  }

  try {
    const response = await fetch('http://127.0.0.1:3000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include', // Important for cookies
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (!response.ok) {
      alert(data.error || 'Login failed. Please try again.');
      return;
    }

    // Store session data including token for development
    sessionStorage.setItem('auth.username', data.user.username);
    sessionStorage.setItem('auth.role', data.user.role);
    
    // Extract token from response headers if available, or request it
    if (data.token) {
      sessionStorage.setItem('auth.token', data.token);
    }

    // Redirect by role
    const target = REDIRECTS[data.user.role] || 'module/staff_dashboard.html';
    window.location.href = target;

  } catch (error) {
    console.error('Login error:', error);
    alert('Login failed. Please check your connection and try again.');
  }
}

// Wire up form submit and Enter key handling
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const forgotPasswordLink = document.getElementById('forgotPasswordLink');
  
  // Handle form submission
  if (form) {
    form.addEventListener('submit', login);
  }
  
  // Handle Enter key on input fields
  const handleEnterKey = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      login(e);
    }
  };
  
  if (usernameInput) {
    usernameInput.addEventListener('keypress', handleEnterKey);
  }
  
  if (passwordInput) {
    passwordInput.addEventListener('keypress', handleEnterKey);
  }
  
  // Password visibility toggle
  const eyeShow = document.querySelector('.password-container .eye-show');
  const eyeHide = document.querySelector('.password-container .eye-hide');
  
  if (eyeShow && eyeHide && passwordInput) {
    const togglePasswordVisibility = () => {
      const isPassword = passwordInput.type === 'password';
      
      if (isPassword) {
        // Show password
        passwordInput.type = 'text';
        eyeShow.style.display = 'none';
        eyeHide.style.display = 'block';
      } else {
        // Hide password
        passwordInput.type = 'password';
        eyeShow.style.display = 'block';
        eyeHide.style.display = 'none';
      }
    };
    
    eyeShow.addEventListener('click', togglePasswordVisibility);
    eyeHide.addEventListener('click', togglePasswordVisibility);
  }
  
  // Forgot password handling
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener('click', (e) => {
      e.preventDefault();
      showForgotPasswordModal();
    });
  }
});

// Forgot Password Modal functionality
function showForgotPasswordModal() {
  const existingModal = document.querySelector('.forgot-password-modal');
  if (existingModal) {
    existingModal.remove();
  }

  const modal = document.createElement('div');
  modal.className = 'forgot-password-modal';
  modal.innerHTML = `
    <div class="modal-overlay">
      <div class="modal-content">
        <div class="modal-header">
          <h3>Reset Password</h3>
          <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
          <p>Please contact your administrator to reset your password.</p>
          <div class="admin-contact">
            <strong>Administrator Contact:</strong><br>
            Email: admin@goodshots.com<br>
            Phone: (555) 123-4567
          </div>
        </div>
        <div class="modal-actions">
          <button class="modal-btn modal-close-btn">Close</button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // Add modal styles
  if (!document.querySelector('#forgot-password-modal-styles')) {
    const styles = document.createElement('style');
    styles.id = 'forgot-password-modal-styles';
    styles.textContent = `
      .forgot-password-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 10000;
      }
      
      .modal-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
      }
      
      .modal-content {
        background: #ffff;
        border-radius: 20px;
        box-shadow: 4px 4px 15px rgba(0, 0, 0, 0.3);
        max-width: 400px;
        width: 100%;
        overflow: hidden;
        animation: modalSlideIn 0.2s ease-out;
      }
      
      @keyframes modalSlideIn {
        from {
          transform: scale(0.9);
          opacity: 0;
        }
        to {
          transform: scale(1);
          opacity: 1;
        }
      }
      
      .modal-header {
        background: #0D3C69;
        padding: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      }
      
      .modal-header h3 {
        margin: 0;
        color: white;
        font-size: 18px;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
      }
      
      .modal-close {
        background: #0D3C69;
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background-color 0.2s;
      }
      
      .modal-close:hover {
        background-color: rgba(255, 255, 255, 0.64);
      }
      
      .modal-body {
        padding: 25px;
        color: #0D0D0D;
      }
      
      .modal-body p {
        margin: 0 0 20px 0;
        font-size: 14px;
        line-height: 1.5;
      }
      
      .admin-contact {
        background: rgba(255, 255, 255, 0.2);
        padding: 15px;
        border-radius: 10px;
        font-size: 13px;
        line-height: 1.6;
      }
      
      .modal-actions {
        padding: 0 25px 25px 25px;
        text-align: center;
      }
      
      .modal-btn {
        background-color: #0D3C69;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 15px;
        cursor: pointer;
        font-weight: bold;
        font-size: 14px;
        box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
        transition: background-color 0.2s;
      }
      
      .modal-btn:hover {
        background-color: #092c4e;
      }
    `;
    document.head.appendChild(styles);
  }

  // Close modal handlers
  const closeModal = () => {
    modal.remove();
  };

  modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) {
      closeModal();
    }
  });

  modal.querySelectorAll('.modal-close, .modal-close-btn').forEach(btn => {
    btn.addEventListener('click', closeModal);
  });

  // Handle escape key
  const handleEscape = (e) => {
    if (e.key === 'Escape') {
      closeModal();
      document.removeEventListener('keydown', handleEscape);
    }
  };
  document.addEventListener('keydown', handleEscape);
}