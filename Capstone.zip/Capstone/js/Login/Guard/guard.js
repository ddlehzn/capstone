const HOME_BY_ROLE = {
  admin: '/module/dashboard.html',
  staff: '/module/staff_dashboard.html'
};

async function checkAuthStatus() {
  try {
    console.log('Checking auth status...');
    
    // First check sessionStorage for immediate access
    const sessionRole = sessionStorage.getItem('auth.role');
    const sessionUsername = sessionStorage.getItem('auth.username');
    const sessionToken = sessionStorage.getItem('auth.token');
    console.log('Session data:', { role: sessionRole, username: sessionUsername, hasToken: !!sessionToken });

    const headers = {
      'Content-Type': 'application/json'
    };
    
    // Add token to headers if available
    if (sessionToken) {
      headers['Authorization'] = `Bearer ${sessionToken}`;
    }

    const response = await fetch('http://localhost:3000/api/auth/me', {
      method: 'GET',
      headers: headers,
      credentials: 'include'
    });

    console.log('Auth API response status:', response.status);

    if (response.ok) {
      const data = await response.json();
      console.log('Auth API data:', data);
      // Update session storage with current server data
      sessionStorage.setItem('auth.username', data.user.username);
      sessionStorage.setItem('auth.role', data.user.role);
      return data.user;
    } else {
      console.log('Auth API failed, falling back to session storage');
      // If API fails but we have session data, use it (for development)
      if (sessionRole && sessionUsername) {
        console.log('Using session storage fallback');
        return { role: sessionRole, username: sessionUsername };
      }
      
      // Clear invalid session data
      sessionStorage.removeItem('auth.username');
      sessionStorage.removeItem('auth.role');
      return null;
    }
  } catch (error) {
    console.error('Auth check error:', error);
    // On network error, fall back to session storage
    const role = sessionStorage.getItem('auth.role');
    const username = sessionStorage.getItem('auth.username');
    if (role && username) {
      console.log('Using session storage due to network error');
      return { role, username };
    }
    return null;
  }
}

async function guard(requiredRole) {
  const user = await checkAuthStatus();
  
  if (!user) {
    window.location.href = '/index.html';
    return;
  }
  
  if (requiredRole && user.role !== requiredRole) {
    window.location.href = HOME_BY_ROLE[user.role] || '/module/staff_dashboard.html';
  }
}

// Expose globally
window.guard = guard;