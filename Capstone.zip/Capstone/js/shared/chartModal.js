// Chart Modal functionality for displaying detailed chart information

let modalChart = null;
let currentChartType = null;

// Fetch real monthly sales data from database
async function fetchRealMonthlySalesData() {
  try {
    const token = sessionStorage.getItem('auth.token');
    if (!token) {
      console.error('No authentication token found');
      return null;
    }

    const response = await fetch('http://localhost:3000/api/sales/monthly', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log('Real monthly sales data fetched for modal:', data);

    if (data && data.labels && data.data) {
      // Calculate statistics from real data
      const salesData = data.data.map(val => parseFloat(val));
      const maxValue = Math.max(...salesData);
      const minValue = Math.min(...salesData);
      const avgValue = salesData.reduce((sum, val) => sum + val, 0) / salesData.length;
      const maxIndex = salesData.indexOf(maxValue);
      const minIndex = salesData.indexOf(minValue);
      const maxMonth = data.labels[maxIndex];
      const minMonth = data.labels[minIndex];
      
      // Calculate growth rate (comparing first and last values)
      const firstValue = salesData[0];
      const lastValue = salesData[salesData.length - 1];
      const growthRate = firstValue > 0 ? ((lastValue - firstValue) / firstValue * 100).toFixed(1) : 0;

      return {
        title: 'Monthly Sales Trends',
        description: 'This chart shows the monthly sales performance throughout the year. It tracks the growth and fluctuations in sales revenue over time, helping identify seasonal patterns and business trends.',
        stats: [
          { label: 'Highest Month', value: `${maxMonth} (₱${maxValue.toLocaleString()})` },
          { label: 'Lowest Month', value: `${minMonth} (₱${minValue.toLocaleString()})` },
          { label: 'Average Monthly Sales', value: `₱${avgValue.toLocaleString()}` },
          { label: 'Growth Rate', value: `${growthRate}% YoY` }
        ],
        chartType: 'line',
        data: {
          labels: data.labels,
          datasets: [{
            label: 'Monthly Sales (₱)',
            data: salesData,
            borderColor: '#0D3C69',
            backgroundColor: 'rgba(13, 60, 105, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
          }]
        }
      };
    }
  } catch (error) {
    console.error('Error fetching real monthly sales data:', error);
  }
  return null;
}

// Fetch real weekly sales data from database
async function fetchRealWeeklySalesData() {
  try {
    const token = sessionStorage.getItem('auth.token');
    if (!token) {
      console.error('No authentication token found');
      return null;
    }

    const response = await fetch('http://localhost:3000/api/sales/weekly', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (data && data.labels && data.data) {
      // Calculate statistics from real data
      const salesData = data.data.map(val => parseFloat(val));
      const maxValue = Math.max(...salesData);
      const minValue = Math.min(...salesData);
      const avgValue = salesData.reduce((sum, val) => sum + val, 0) / salesData.length;
      const totalValue = salesData.reduce((sum, val) => sum + val, 0);
      const maxIndex = salesData.indexOf(maxValue);
      const minIndex = salesData.indexOf(minValue);
      const maxDay = data.labels[maxIndex];
      const minDay = data.labels[minIndex];

      const result = {
        title: 'Sales per Week',
        description: 'This line chart shows the daily sales performance throughout the week. It helps identify which days have the highest sales activity and track weekly sales trends.',
        stats: [
          { label: 'Best Day', value: `${maxDay} (₱${maxValue.toLocaleString()})` },
          { label: 'Lowest Day', value: `${minDay} (₱${minValue.toLocaleString()})` },
          { label: 'Average Daily Sales', value: `₱${avgValue.toLocaleString()}` },
          { label: 'Weekly Total', value: `₱${totalValue.toLocaleString()}` }
        ],
        chartType: 'line',
        data: {
          labels: data.labels,
          datasets: [{
            label: 'Weekly Sales (₱)',
            data: salesData,
            borderColor: '#0D3C69',
            backgroundColor: 'rgba(13, 60, 105, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
          }]
        }
      };
      return result;
    }
  } catch (error) {
    console.error('Error fetching real weekly sales data:', error);
  }
  return null;
}

// Fetch real daily sales data from database
async function fetchRealDailySalesData() {
  try {
    console.log('Fetching real daily sales data...');
    const token = sessionStorage.getItem('auth.token');
    if (!token) {
      console.error('No authentication token found');
      return null;
    }

    const response = await fetch('http://localhost:3000/api/sales/daily', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('Daily API response status:', response.status);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (data && data.labels && data.data) {
      // Calculate statistics from real data
      const salesData = data.data.map(val => parseFloat(val));
      const maxValue = Math.max(...salesData);
      const minValue = Math.min(...salesData);
      const avgValue = salesData.reduce((sum, val) => sum + val, 0) / salesData.length;
      const totalValue = salesData.reduce((sum, val) => sum + val, 0);
      const maxIndex = salesData.indexOf(maxValue);
      const minIndex = salesData.indexOf(minValue);
      const maxHour = data.labels[maxIndex];
      const minHour = data.labels[minIndex];

      const result = {
        title: 'Sales per Day',
        description: 'This chart shows the hourly sales performance throughout the day. It tracks peak business hours and helps identify the best times for sales and customer engagement.',
        stats: [
          { label: 'Peak Hour', value: `${maxHour} (₱${maxValue.toLocaleString()})` },
          { label: 'Lowest Hour', value: `${minHour} (₱${minValue.toLocaleString()})` },
          { label: 'Average Hourly Sales', value: `₱${avgValue.toLocaleString()}` },
          { label: 'Daily Total', value: `₱${totalValue.toLocaleString()}` }
        ],
        chartType: 'line',
        data: {
          labels: data.labels,
          datasets: [{
            label: 'Daily Sales (₱)',
            data: salesData,
            borderColor: '#0D3C69',
            backgroundColor: 'rgba(13, 60, 105, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
          }]
        }
      };
      return result;
    }
  } catch (error) {
    console.error('Error fetching real daily sales data:', error);
    console.error('Error details:', error.message);
  }
  return null;
}

// Fetch real sales by product data from database
async function fetchRealSalesByProductData() {
  try {
    const token = sessionStorage.getItem('auth.token');
    if (!token) {
      console.error('No authentication token found');
      return null;
    }

    const response = await fetch('http://localhost:3000/api/sales/by-product', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log('Real sales by product data fetched for modal:', data);

    if (data && data.labels && data.data) {
      // Calculate statistics from real data
      const salesData = data.data.map(val => parseFloat(val));
      const maxValue = Math.max(...salesData);
      const minValue = Math.min(...salesData);
      const avgValue = salesData.reduce((sum, val) => sum + val, 0) / salesData.length;
      const maxIndex = salesData.indexOf(maxValue);
      const maxProduct = data.labels[maxIndex];
      const totalProducts = data.labels.length;

      return {
        title: 'Sales by Product',
        description: 'This horizontal bar chart displays sales performance for each product category. It helps identify top-selling items and products that may need more attention or marketing focus.',
        stats: [
          { label: 'Best Seller', value: `${maxProduct} (${maxValue.toLocaleString()} units)` },
          { label: 'Total Products', value: `${totalProducts} Categories` },
          { label: 'Average Sales', value: `${avgValue.toLocaleString()} units` },
          { label: 'Top Category Revenue', value: `₱${(maxValue * 140).toLocaleString()}` } // Assuming ₱140 average price per unit
        ],
        chartType: 'bar',
        data: {
          labels: data.labels,
          datasets: [{
            label: 'Units Sold',
            data: salesData,
            backgroundColor: data.labels.map((_, index) => 
              index % 2 === 0 ? '#0D3C69' : '#6D89AD'
            ),
            borderRadius: 4
          }]
        }
      };
    }
  } catch (error) {
    console.error('Error fetching real sales by product data:', error);
  }
  return null;
}

// Chart data and descriptions
const chartData = {
  'monthly-sales': {
    title: 'Monthly Sales Trends',
    description: 'This chart shows the monthly sales performance throughout the year. It tracks the growth and fluctuations in sales revenue over time, helping identify seasonal patterns and business trends.',
    stats: [
      { label: 'Highest Month', value: 'December (₱125,000)' },
      { label: 'Lowest Month', value: 'January (₱65,000)' },
      { label: 'Average Monthly Sales', value: '₱95,500' },
      { label: 'Growth Rate', value: '+15.3% YoY' }
    ],
    chartType: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
        label: 'Monthly Sales (₱)',
        data: [65, 78, 82, 89, 95, 88, 92, 98, 105, 112, 118, 125],
        borderColor: '#0D3C69',
        backgroundColor: 'rgba(13, 60, 105, 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4
      }]
    }
  },
  'weekly-sales': {
    title: 'Sales per Week',
    description: 'This line chart shows the daily sales performance throughout the week. It helps identify which days have the highest sales activity and track weekly sales trends.',
    stats: [
      { label: 'Best Day', value: 'Friday (₱2,500)' },
      { label: 'Lowest Day', value: 'Monday (₱1,200)' },
      { label: 'Average Daily Sales', value: '₱1,814' },
      { label: 'Weekly Total', value: '₱12,700' },
      { label: 'Weekly Growth', value: '+91.7%' }
    ],
    chartType: 'line',
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'Weekly Sales',
        data: [1200, 1500, 1300, 1700, 2500, 2200, 2300],
        borderColor: '#0D3C69',
        backgroundColor: 'rgba(13, 60, 105, 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.3,
        pointBackgroundColor: '#0D3C69',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4
      }]
    }
  },
  'sales-by-product': {
    title: 'Sales by Product',
    description: 'This horizontal bar chart displays sales performance for each product category. It helps identify top-selling items and products that may need more attention or marketing focus.',
    stats: [
      { label: 'Best Seller', value: 'Caramel Macchiato (2,000 units)' },
      { label: 'Total Products', value: '6 Categories' },
      { label: 'Average Sales', value: '1,433 units' },
      { label: 'Top Category Revenue', value: '₱280,000' }
    ],
    chartType: 'bar',
    data: {
      labels: ['Caramel Macchiato', 'Spanish Latte', 'White Mocha', 'Dirty Matcha', 'Americano', 'Cappuccino'],
      datasets: [{
        label: 'Units Sold',
        data: [2000, 1800, 1600, 1400, 1200, 1000],
        backgroundColor: ['#0D3C69', '#6D89AD', '#0D3C69', '#6D89AD', '#0D3C69', '#6D89AD'],
        borderRadius: 4
      }]
    }
  }
};

// Get chart data based on filter type
async function getFilteredChartData(filterType) {
  switch (filterType) {
    case 'weekly':
      return {
        title: 'Sales per Week',
        description: 'This line chart shows the daily sales performance throughout the week. It helps identify which days have the highest sales activity and track weekly sales trends.',
        stats: [
          { label: 'Best Day', value: 'Friday (₱2,500)' },
          { label: 'Lowest Day', value: 'Monday (₱1,200)' },
          { label: 'Average Daily Sales', value: '₱1,814' },
          { label: 'Weekly Total', value: '₱12,700' }
        ],
        chartType: 'line',
        data: {
          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          datasets: [{
            label: 'Weekly Sales (₱)',
            data: [120, 150, 130, 170, 200, 220, 180],
            borderColor: '#0D3C69',
            backgroundColor: 'rgba(13, 60, 105, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
          }]
        }
      };
    case 'daily':
      // Fetch real daily sales data instead of using hardcoded data
      const realDailyData = await fetchRealDailySalesData();
      if (realDailyData) {
        return realDailyData;
      } else {
        // Return empty data if no real data available
        return {
          title: 'Sales per Day',
          description: 'No sales data available. Upload a file to see daily sales data.',
          stats: [
            { label: 'Status', value: 'No data available' },
            { label: 'Upload', value: 'Use file upload to add data' }
          ],
          chartType: 'line',
          data: {
            labels: ['No data uploaded yet'],
            datasets: [{
              label: 'Daily Sales (₱)',
              data: [0],
              borderColor: '#0D3C69',
              backgroundColor: 'rgba(13, 60, 105, 0.1)',
              borderWidth: 3,
              fill: true,
              tension: 0.4
            }]
          }
        };
      }
    case 'monthly':
    default:
      return chartData['monthly-sales'];
  }
}

// Open chart modal
async function openChartModal(chartType, filterType = null) {
  const modal = document.getElementById('chartModal');
  let baseData = chartData[chartType];
  
  if (!baseData) {
    console.error('Chart data not found for type:', chartType);
    return;
  }
  
    // If filter type is provided, get the appropriate data
    if (filterType && chartType === 'monthly-sales') {
      baseData = await getFilteredChartData(filterType);
    }
  
  // Store current chart type for download
  currentChartType = chartType;
  
  // Update modal content with base information
  document.getElementById('modalTitle').textContent = baseData.title;
  document.getElementById('modalDescription').textContent = baseData.description;
  
  // Show modal immediately
  modal.classList.add('show');
  document.body.style.overflow = 'hidden'; // Prevent background scrolling
  
  // Fetch real data and update modal content
  try {
    let realData = null;
    
    if (chartType === 'monthly-sales') {
      if (filterType === 'weekly') {
        realData = await fetchRealWeeklySalesData();
      } else if (filterType === 'daily') {
        realData = await fetchRealDailySalesData();
      } else {
        // Only fetch monthly data if no filter or filter is monthly
        realData = await fetchRealMonthlySalesData();
      }
    } else if (chartType === 'sales-by-product') {
      realData = await fetchRealSalesByProductData();
    } else if (chartType === 'weekly-sales') {
      realData = await fetchRealWeeklySalesData();
    } else {
      // For other charts, use base data
      realData = baseData;
    }
    
    // If no real data was fetched, use the filtered base data
    if (!realData) {
      realData = baseData;
    }
    
    if (realData) {
      // Update stats with real data
      const statsContainer = document.getElementById('modalStats');
      statsContainer.innerHTML = '';
      realData.stats.forEach(stat => {
        const statDiv = document.createElement('div');
        statDiv.className = 'stat-item';
        statDiv.innerHTML = `
          <span class="stat-label">${stat.label}:</span>
          <span class="stat-value">${stat.value}</span>
        `;
        statsContainer.appendChild(statDiv);
      });
      
      // Create chart with real data
      setTimeout(() => {
        createModalChart(realData);
      }, 100);
    } else {
      // Fallback to base data (which now includes filtered data)
      const statsContainer = document.getElementById('modalStats');
      statsContainer.innerHTML = '';
      baseData.stats.forEach(stat => {
        const statDiv = document.createElement('div');
        statDiv.className = 'stat-item';
        statDiv.innerHTML = `
          <span class="stat-label">${stat.label}:</span>
          <span class="stat-value">${stat.value}</span>
        `;
        statsContainer.appendChild(statDiv);
      });
      
      setTimeout(() => {
        createModalChart(baseData);
      }, 100);
    }
  } catch (error) {
    console.error('Error fetching real chart data:', error);
    // Fallback to base data on error
    const statsContainer = document.getElementById('modalStats');
    statsContainer.innerHTML = '';
    baseData.stats.forEach(stat => {
      const statDiv = document.createElement('div');
      statDiv.className = 'stat-item';
      statDiv.innerHTML = `
        <span class="stat-label">${stat.label}:</span>
        <span class="stat-value">${stat.value}</span>
      `;
      statsContainer.appendChild(statDiv);
    });
    
    setTimeout(() => {
      createModalChart(baseData);
    }, 100);
  }
}

// Close chart modal
function closeChartModal() {
  const modal = document.getElementById('chartModal');
  modal.classList.remove('show');
  document.body.style.overflow = ''; // Restore scrolling
  
  // Destroy existing chart
  if (modalChart) {
    modalChart.destroy();
    modalChart = null;
  }
}

// Make functions globally available
if (typeof window !== 'undefined') {
  window.openChartModal = openChartModal;
  window.closeChartModal = closeChartModal;
}

// Create chart in modal
function createModalChart(data) {
  const ctx = document.getElementById('modalChart');
  
  if (!ctx) {
    console.error('Modal chart canvas not found');
    return;
  }
  
  // Destroy existing chart
  if (modalChart) {
    modalChart.destroy();
  }
  
  // Chart options based on type
  let options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: data.chartType !== 'line',
        position: 'bottom'
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff'
      }
    }
  };
  
  // Type-specific options
  if (data.chartType === 'line') {
    options.scales = {
      x: { grid: { display: false } },
      y: { beginAtZero: true }
    };
  } else if (data.chartType === 'bar') {
    options.indexAxis = 'y'; // Horizontal bars
    options.scales = {
      x: { beginAtZero: true },
      y: { grid: { display: false } }
    };
  }
  
  // Create chart
  modalChart = new Chart(ctx, {
    type: data.chartType,
    data: data.data,
    options: options
  });
}

// Close modal when clicking outside
document.addEventListener('DOMContentLoaded', function() {
  const modal = document.getElementById('chartModal');
  if (modal) {
    modal.addEventListener('click', function(event) {
      if (event.target === modal) {
        closeChartModal();
      }
    });
  }
  
  // Close modal with Escape key
  document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && modal.classList.contains('show')) {
      closeChartModal();
    }
  });
});

// Download chart report as PDF
async function downloadChartReport() {
  if (!currentChartType || !modalChart) {
    console.error('No chart available for download');
    return;
  }
  
  // Try to get real data first, fallback to base data
  let data = chartData[currentChartType];
  
  try {
    if (currentChartType === 'monthly-sales') {
      const realData = await fetchRealMonthlySalesData();
      if (realData) data = realData;
    } else if (currentChartType === 'sales-by-product') {
      const realData = await fetchRealSalesByProductData();
      if (realData) data = realData;
    }
  } catch (error) {
    console.error('Error fetching real data for PDF:', error);
    // Continue with base data
  }
  const downloadBtn = document.getElementById('downloadBtn');
  
  // Show loading state
  downloadBtn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" opacity="0.3"/>
      <path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <animateTransform attributeName="transform" type="rotate" dur="1s" values="0 12 12;360 12 12" repeatCount="indefinite"/>
      </path>
    </svg>
    Generating PDF...
  `;
  downloadBtn.disabled = true;
  
  try {
    // Create new jsPDF instance
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    // Get chart image
    const chartCanvas = document.getElementById('modalChart');
    const chartImage = chartCanvas.toDataURL('image/png', 1.0);
    
    // Header
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Chart Analysis Report', 20, 25);
    
    // Subtitle with chart type
    pdf.setFontSize(16);
    pdf.setFont('helvetica', 'normal');
    pdf.text(data.title, 20, 35);
    
    // Date
    pdf.setFontSize(10);
    pdf.setTextColor(100, 100, 100);
    const currentDate = new Date().toLocaleDateString('en-US', { 
      year: 'numeric', month: 'long', day: 'numeric' 
    });
    pdf.text(`Generated on ${currentDate}`, 20, 45);
    
    // Reset text color
    pdf.setTextColor(0, 0, 0);
    
    // Summary section
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Summary', 20, 60);
    
    // Description
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    const splitDescription = pdf.splitTextToSize(data.description, 170);
    pdf.text(splitDescription, 20, 70);
    
    // Key Statistics
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Key Statistics', 20, 95);
    
    let yPos = 105;
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    
    data.stats.forEach(stat => {
      pdf.text(`• ${stat.label}: ${stat.value}`, 25, yPos);
      yPos += 8;
    });
    
    // Chart image
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Chart Visualization', 20, yPos + 15);
    
    // Add chart image (properly sized to fit A4 page)
    const maxWidth = 170; // Maximum width for A4 (210mm - 40mm margins)
    const maxHeight = 120; // Maximum height to leave space for footer
    const aspectRatio = chartCanvas.width / chartCanvas.height;
    
    let imgWidth = maxWidth;
    let imgHeight = maxWidth / aspectRatio;
    
    // If height exceeds maximum, scale down based on height
    if (imgHeight > maxHeight) {
      imgHeight = maxHeight;
      imgWidth = maxHeight * aspectRatio;
    }
    
    pdf.addImage(chartImage, 'PNG', 20, yPos + 25, imgWidth, imgHeight);
    
    // Footer (positioned at bottom of page with proper margin)
    pdf.setFontSize(8);
    pdf.setTextColor(100, 100, 100);
    pdf.text('Generated by Espresso - The Good Shots Coffee Management System', 20, 285);
    
    // Download the PDF
    const filename = `${data.title.replace(/\s+/g, '_')}_Report_${new Date().getFullYear()}.pdf`;
    pdf.save(filename);
    
  } catch (error) {
    console.error('Error generating PDF:', error);
    alert('Error generating PDF. Please try again.');
  } finally {
    // Restore button state
    downloadBtn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <polyline points="7,10 12,15 17,10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <line x1="12" y1="15" x2="12" y2="3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      </svg>
      Download PDF
    `;
    downloadBtn.disabled = false;
  }
}