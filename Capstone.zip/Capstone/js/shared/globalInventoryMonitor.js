// Global Inventory Monitoring - Starts when website loads
// This ensures inventory notifications work across all modules

(function() {
  'use strict';

  // Wait for DOM to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeGlobalInventoryMonitoring);
  } else {
    initializeGlobalInventoryMonitoring();
  }

  function initializeGlobalInventoryMonitoring() {
    // Only initialize if we haven't already and if the service is available
    if (window.globalInventoryServiceInitialized || !window.InventoryNotificationService) {
      return;
    }

    console.log('🔍 Initializing Global Inventory Monitoring...');
    
    // Create global instance if it doesn't exist, or reuse existing one
    if (!window.inventoryNotificationService) {
      window.inventoryNotificationService = new InventoryNotificationService();
      console.log('✅ Global inventory notification service created');
    } else {
      console.log('♻️ Reusing existing inventory notification service');
    }

    // Set up notification handler for chat integration
    if (window.inventoryNotificationService && !window.globalInventoryServiceInitialized) {
      // Only start if not already running
      if (!window.inventoryNotificationService.isRunning) {
        window.inventoryNotificationService.start();
        console.log('🚀 Started inventory notification service');
      } else {
        console.log('📍 Inventory notification service already running');
      }
      
      // Add a notification handler that works even outside chat
      window.inventoryNotificationService.onNotification((notification) => {
        console.log('📢 Global notification received:', notification);
        
        // If chat is available, send notification there
        if (window.handleGlobalInventoryNotification) {
          window.handleGlobalInventoryNotification(notification);
        } else {
          // Store notification for when chat becomes available
          if (!window.pendingInventoryNotifications) {
            window.pendingInventoryNotifications = [];
          }
          window.pendingInventoryNotifications.push(notification);
          // Persist to localStorage so it survives navigation between modules/pages
          try {
            const key = 'inventory.pendingNotifications';
            const existing = JSON.parse(localStorage.getItem(key) || '[]');
            existing.push(notification);
            localStorage.setItem(key, JSON.stringify(existing));
          } catch (e) {
            console.warn('Failed to persist pending notification:', e);
          }
          console.log('💾 Notification queued for chat module');
        }
      });

      window.globalInventoryServiceInitialized = true;
      console.log('✅ Global inventory monitoring is now active across all modules');
    }
  }

  // Make service accessible globally
  window.getInventoryService = function() {
    return window.inventoryNotificationService;
  };

  // Method to manually trigger immediate check (for testing)
  window.triggerInventoryCheck = async function() {
    if (window.inventoryNotificationService) {
      console.log('🔄 Manual inventory check triggered');
      await window.inventoryNotificationService.forceCheck();
    } else {
      console.log('❌ Inventory service not available');
    }
  };

})();