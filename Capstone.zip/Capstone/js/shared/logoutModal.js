// Global Logout Modal functionality
// This file provides a consistent logout confirmation modal across all modules

function showLogoutModal() {
  const existingModal = document.querySelector('.logout-modal');
  if (existingModal) {
    existingModal.remove();
  }

  const modal = document.createElement('div');
  modal.className = 'logout-modal';
  modal.innerHTML = `
    <div class="logout-modal-overlay">
      <div class="logout-modal-content">
        <div class="logout-modal-text">
          <div class="logout-modal-message">Are you sure you want to log out?</div>
        </div>
        <div class="logout-modal-buttons">
          <button class="logout-confirm-btn">OK</button>
          <button class="logout-cancel-btn">Cancel</button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // Add modal styles
  if (!document.querySelector('#logout-modal-styles')) {
    const styles = document.createElement('style');
    styles.id = 'logout-modal-styles';
    styles.textContent = `
      .logout-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 10000;
      }
      
      .logout-modal-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.6);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
      }
      
      .logout-modal-content {
        background: #ffffff;
        border-radius: 8px;
        max-width: 400px;
        width: 100%;
        overflow: hidden;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        animation: logoutModalSlideIn 0.2s ease-out;
      }
      
      @keyframes logoutModalSlideIn {
        from {
          transform: scale(0.9);
          opacity: 0;
        }
        to {
          transform: scale(1);
          opacity: 1;
        }
      }
      
      .logout-modal-text {
        padding: 20px 20px 15px 20px;
        color: white;
      }
      
      .logout-modal-title {
        font-size: 14px;
        font-weight: normal;
        margin-bottom: 10px;
        color: #e0e0e0;
      }
      
      .logout-modal-message {
        font-size: 20px;
        color: #1a3557;
        line-height: 1.4;
      }
      
      .logout-modal-buttons {
        padding: 15px 20px 20px 20px;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
      }
      
      .logout-modal-buttons button {
        padding: 8px 16px;
        border: none;
        border-radius: 4px;
        font-size: 13px;
        cursor: pointer;
        min-width: 70px;
        transition: background-color 0.2s;
      }
      
      .logout-confirm-btn {
        background-color: #345c97;
        color: white;
      }
      
      .logout-confirm-btn:hover {
        background-color: #1b3e72;
      }
      
      .logout-cancel-btn {
        background-color: #bfc9d9;
        color: #1a3557;
      }
      
      .logout-cancel-btn:hover {
        background-color: #a3b1c6;
      }
    `;
    document.head.appendChild(styles);
  }

  // Handle button clicks
  const confirmBtn = modal.querySelector('.logout-confirm-btn');
  const cancelBtn = modal.querySelector('.logout-cancel-btn');

  const closeModal = () => {
    modal.remove();
  };

  const performLogout = async () => {
    try {
      // Call the logout API to clear the cookie
      await fetch('http://localhost:3000/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
    
    // Clear session storage
    sessionStorage.clear();
    
    // Clear local storage if used
    localStorage.clear();
    
    // Redirect to login page
    window.location.href = '../index.html';
    
    closeModal();
  };

  confirmBtn.addEventListener('click', performLogout);
  cancelBtn.addEventListener('click', closeModal);

  // Close modal when clicking outside
  modal.querySelector('.logout-modal-overlay').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) {
      closeModal();
    }
  });

  // Handle escape key
  const handleEscape = (e) => {
    if (e.key === 'Escape') {
      closeModal();
      document.removeEventListener('keydown', handleEscape);
    }
  };
  document.addEventListener('keydown', handleEscape);
}

// Make function globally available
if (typeof window !== 'undefined') {
  window.showLogoutModal = showLogoutModal;
}

// Alternative function for replacing existing logout calls
function logout() {
  showLogoutModal();
}

// Make logout function globally available too
if (typeof window !== 'undefined') {
  window.logout = logout;
}