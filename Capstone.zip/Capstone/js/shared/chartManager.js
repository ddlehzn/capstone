// Chart.js Configuration for Dashboard and Sales
// This file contains all chart configurations for your application
// Version 34 - Removed upload feedback pop-ups, silent refresh

class ChartManager {
  constructor() {
    console.log('ChartManager v34 loaded - Removed upload feedback pop-ups, silent refresh');
    this.charts = {};
    this.API_BASE = 'http://localhost:3000';
    this.defaultColors = {
      primary: '#0D3C69',
      secondary: '#6D89AD',
      accent: '#4a90e2',
      light: '#a8c0e0',
      success: '#28a745',
      warning: '#ffc107',
      danger: '#dc3545'
    };
  }

  // Auth headers like other modules
  getAuthHeaders() {
    const token = sessionStorage.getItem('auth.token');
    const headers = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    return headers;
  }

  // Sales Overview Line Chart (Dashboard)
  createSalesOverviewChart(canvasId, data = null) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
      return null;
    }

    // Destroy existing chart if it exists
    if (this.charts[canvasId]) {
      this.charts[canvasId].destroy();
      delete this.charts[canvasId];
    }

    const defaultData = {
      labels: ['10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM'],
      datasets: [{
        label: 'Sales',
        data: [16, 43, 32, 43, 49, 78, 97],
        borderColor: this.defaultColors.primary,
        backgroundColor: 'rgba(13, 60, 105, 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: this.defaultColors.primary,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8
      }]
    };

    this.charts[canvasId] = new Chart(ctx, {
      type: 'line',
      data: data || defaultData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
          padding: {
            top: 10,
            bottom: 10,
            left: 10,
            right: 10
          }
        },
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleColor: '#fff',
            bodyColor: '#fff',
            borderColor: this.defaultColors.primary,
            borderWidth: 1
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              color: '#666'
            }
          },
          y: {
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            },
            ticks: {
              color: '#666'
            },
            beginAtZero: true
          }
        },
        elements: {
          point: {
            hoverBorderWidth: 3
          }
        }
      }
    });

    return this.charts[canvasId];
  }

  // Monthly Sales Trends Line Chart (Sales Page)
  createMonthlySalesTrendsChart(canvasId, data = null) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
      return null;
    }

    // Destroy existing chart on this canvas if present
    if (this.charts[canvasId]) {
      this.charts[canvasId].destroy();
      delete this.charts[canvasId];
    }

    const defaultData = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
        label: 'Monthly Sales',
        data: [65, 78, 82, 89, 95, 88, 92, 98, 105, 112, 118, 125],
        borderColor: this.defaultColors.primary,
        backgroundColor: 'rgba(13, 60, 105, 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.3,
        pointBackgroundColor: this.defaultColors.primary,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4
      }]
    };

    this.charts[canvasId] = new Chart(ctx, {
      type: 'line',
      data: data || defaultData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            },
            beginAtZero: true
          }
        }
      }
    });

    return this.charts[canvasId];
  }

  // Weekly Sales Chart
  async createWeeklySalesChart(canvasId, data = null) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
      return null;
    }

    // Destroy existing chart on this canvas if present
    if (this.charts[canvasId]) {
      this.charts[canvasId].destroy();
      delete this.charts[canvasId];
    }

    // If no data provided and this is for Sales Management, fetch real data
    if (!data && canvasId === 'weeklySalesChart') {
      try {
        const apiData = await this.fetchWeeklySalesApi();
        if (apiData) {
          data = apiData;
        }
      } catch (error) {
        console.error('Error fetching weekly data for Sales Management:', error);
      }
    }

    const defaultData = {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'Weekly Sales',
        data: [120, 145, 160, 140, 180, 215, 190],
        borderColor: this.defaultColors.primary,
        backgroundColor: 'rgba(13, 60, 105, 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.3,
        pointBackgroundColor: this.defaultColors.primary,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4
      }]
    };
    
    this.charts[canvasId] = new Chart(ctx, {
      type: 'line',
      data: data || defaultData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            }
          },
          y: {
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            },
            beginAtZero: true
          }
        }
      }
    });

    return this.charts[canvasId];
  }

  // Daily Sales Chart
  async createDailySalesChart(canvasId, data = null) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) {
      return null;
    }

    // Destroy existing chart on this canvas if present
    if (this.charts[canvasId]) {
      this.charts[canvasId].destroy();
      delete this.charts[canvasId];
    }

    // If no data provided, fetch real data
    if (!data) {
      try {
        const apiData = await this.fetchDailySalesApi();
        if (apiData) {
          data = apiData;
        }
      } catch (error) {
        console.error('Error fetching daily data:', error);
      }
    }

    const defaultData = {
      labels: ['6 AM', '8 AM', '10 AM', '12 PM', '2 PM', '4 PM', '6 PM', '8 PM'],
      datasets: [{
        label: 'Daily Sales',
        data: [45, 120, 180, 220, 160, 140, 200, 90],
        borderColor: this.defaultColors.primary,
        backgroundColor: 'rgba(13, 60, 105, 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: this.defaultColors.primary,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4
      }]
    };
    
    this.charts[canvasId] = new Chart(ctx, {
      type: 'line',
      data: data || defaultData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 12
              }
            }
          },
          y: {
            beginAtZero: true,
            grid: {
              color: '#f0f0f0'
            },
            ticks: {
              font: {
                size: 12
              }
            }
          }
        }
      }
    });

    return this.charts[canvasId];
  }

  // Performance Pie Chart (Sales Page)
  createPerformancePieChart(canvasId, data = null) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return null;

    const defaultData = {
      labels: ['Excellent', 'Good', 'Average'],
      datasets: [{
        data: [65, 25, 10],
        backgroundColor: [
          this.defaultColors.primary,
          this.defaultColors.secondary,
          this.defaultColors.light
        ],
        borderWidth: 0,
        hoverOffset: 4
      }]
    };

    this.charts[canvasId] = new Chart(ctx, {
      type: 'pie',
      data: data || defaultData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return context.label + ': ' + context.parsed + '%';
              }
            }
          }
        }
      }
    });

    return this.charts[canvasId];
  }

  // Sales by Product Bar Chart (Sales Page)
  createSalesByProductChart(canvasId, data = null) {
    console.log(`=== Creating Sales by Product Chart ===`);
    console.log('Canvas ID:', canvasId);
    console.log('Data provided:', data);
    
    const ctx = document.getElementById(canvasId);
    console.log('Canvas context found:', ctx);
    if (!ctx) {
      console.error('Canvas element not found for ID:', canvasId);
      return null;
    }

    // Destroy existing chart on this canvas if present
    if (this.charts[canvasId]) {
      console.log('Destroying existing chart for:', canvasId);
      this.charts[canvasId].destroy();
      delete this.charts[canvasId];
    }

    const defaultData = {
      labels: ['Caramel Macchiato', 'Spanish Latte', 'White Mocha', 'Dirty Matcha', 'Americano', 'Cappuccino'],
      datasets: [{
        label: 'Sales',
        data: [2000, 1800, 1600, 1400, 1200, 1000],
        backgroundColor: [
          this.defaultColors.primary,
          this.defaultColors.secondary,
          this.defaultColors.primary,
          this.defaultColors.secondary,
          this.defaultColors.primary,
          this.defaultColors.secondary
        ],
        borderRadius: 4,
        borderSkipped: false
      }]
    };

    console.log('Creating Chart.js instance...');
    this.charts[canvasId] = new Chart(ctx, {
      type: 'bar',
      data: data || defaultData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            beginAtZero: true
          },
          y: {
            grid: {
              display: false
            }
          }
        }
      }
    });

    console.log('Chart created successfully:', this.charts[canvasId]);
    console.log('Chart data:', this.charts[canvasId].data);
    return this.charts[canvasId];
  }

  // Update chart data
  updateChartData(chartId, newData) {
    if (this.charts[chartId]) {
      this.charts[chartId].data = newData;
      this.charts[chartId].update();
    }
  }

  // Destroy chart
  destroyChart(chartId) {
    if (this.charts[chartId]) {
      this.charts[chartId].destroy();
      delete this.charts[chartId];
    }
  }

  // Initialize all charts based on page
  initializeCharts(page = 'dashboard') {
    // Clear any existing charts first
    this.destroyAllCharts();
    
    if (page === 'dashboard') {
      // Create the sales overview chart on dashboard
      this.createSalesOverviewChart('salesOverviewChart');
      this.attachSalesOverviewFilter();
      
      // Create the sales by product chart on dashboard
      this.initializeDashboardSalesByProduct();
      
      // Set up auto-refresh for inventory (every 5 minutes)
      this.setupInventoryAutoRefresh();
    } else if (page === 'sales') {
      // For sales page, fetch real data from database
      this.initializeSalesChartsWithData();
    }
  }

  // Initialize Sales by Product chart for Dashboard
  async initializeDashboardSalesByProduct() {
    try {
      console.log('=== Initializing Dashboard Sales by Product Chart ===');
      
      // Check if canvas element exists
      const canvas = document.getElementById('salesByProductChart');
      console.log('Canvas element found:', canvas);
      if (!canvas) {
        console.error('Canvas element with id "salesByProductChart" not found!');
        return;
      }
      
      // Check canvas parent container
      const container = canvas.parentElement;
      console.log('Canvas parent container:', container);
      console.log('Container computed styles:', window.getComputedStyle(container));
      
      // Fetch sales by product data from database
      const productData = await this.fetchSalesByProductApi();
      console.log('Product data fetched:', productData);
      
      if (productData) {
        this.createSalesByProductChart('salesByProductChart', productData);
        console.log('Dashboard Sales by Product chart created with real data');
      } else {
        this.createSalesByProductChart('salesByProductChart');
        console.log('Dashboard Sales by Product chart created with default data');
      }
      
      // Verify chart was created
      if (this.charts['salesByProductChart']) {
        console.log('Chart successfully created and stored in this.charts');
      } else {
        console.error('Chart was not created or stored properly');
      }
    } catch (error) {
      console.error('Error initializing dashboard sales by product chart:', error);
      // Fallback to default chart
      this.createSalesByProductChart('salesByProductChart');
    }
  }

  // Attach dropdown filter for Sales Overview
  attachSalesOverviewFilter() {
    const select = document.getElementById('salesOverviewSelect');
    if (!select) {
      return;
    }

    // Restore saved selection from localStorage
    const savedSelection = localStorage.getItem('salesOverviewSelection');
    if (savedSelection && savedSelection !== select.value) {
      select.value = savedSelection;
      // Trigger change event to load the correct chart
      setTimeout(() => select.dispatchEvent(new Event('change')), 100);
    } else if (savedSelection === 'weekly') {
      // If weekly is selected, make sure we fetch the latest data from database
      setTimeout(async () => {
        try {
          const apiData = await this.fetchWeeklySalesApi();
          if (apiData) {
            this.createSalesOverviewChart('salesOverviewChart', apiData);
          }
        } catch (err) {
          console.error('Error loading weekly data on init:', err);
        }
      }, 200);
    }

    select.addEventListener('change', async () => {
      const value = select.value; // current, monthly, product, weekly
      // Save selection to localStorage
      localStorage.setItem('salesOverviewSelection', value);
      
      try {
        let data;
        if (value === 'current') {
          // Keep default demo data or fetch current day sales
          data = null; // uses default inside createSalesOverviewChart
          this.createSalesOverviewChart('salesOverviewChart', data);
        } else if (value === 'monthly') {
          // Prefer API when available
          const apiData = await this.fetchMonthlySalesApi();
          if (apiData) {
            this.createMonthlySalesTrendsChart('salesOverviewChart', apiData);
          } else {
            const monthlyData = {
              labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
              datasets: [{
                label: 'Monthly Sales',
                data: [65, 78, 82, 89, 95, 88, 92, 98, 105, 112, 118, 125],
                borderColor: this.defaultColors.primary,
                backgroundColor: 'rgba(13, 60, 105, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: this.defaultColors.primary,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4
              }]
            };
            this.createMonthlySalesTrendsChart('salesOverviewChart', monthlyData);
          }
        } else if (value === 'daily') {
          // Fetch daily data from database
          const apiData = await this.fetchDailySalesApi();
          if (apiData && apiData.labels && apiData.labels.length > 0) {
            this.createDailySalesChart('salesOverviewChart', apiData);
          } else {
            // Show empty chart with "No data uploaded yet" message
            const emptyData = {
              labels: ['No data uploaded yet'],
              datasets: [{
                label: 'Daily Sales',
                data: [0],
                borderColor: this.defaultColors.primary,
                backgroundColor: 'rgba(13, 60, 105, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
              }]
            };
            this.createDailySalesChart('salesOverviewChart', emptyData);
          }
        } else if (value === 'weekly') {
          // Fetch weekly data from database
          const apiData = await this.fetchWeeklySalesApi();
          if (apiData) {
            this.createSalesOverviewChart('salesOverviewChart', apiData);
          } else {
            // Fallback to demo data if API fails
            const weeklyData = {
              labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
              datasets: [{
                label: 'Weekly Sales',
                data: [120, 150, 130, 170, 200, 220, 180],
                borderColor: this.defaultColors.primary,
                backgroundColor: 'rgba(13, 60, 105, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
              }]
            };
            this.createSalesOverviewChart('salesOverviewChart', weeklyData);
          }
        }
      } catch (err) {
        console.error('Error switching Sales Overview chart:', err);
      }
    });

  }

  // Update chart after successful upload - use upload data directly
  updateChartAfterUpload(selectValue, uploadResponse) {
    console.log('=== updateChartAfterUpload called ===');
    console.log('selectValue:', selectValue);
    console.log('uploadResponse:', uploadResponse);
    console.log('uploadResponse.labels:', uploadResponse.labels);
    console.log('uploadResponse.sales:', uploadResponse.sales);
    
    try {
      if (selectValue === 'monthly' && uploadResponse.labels && uploadResponse.sales) {
        console.log('Creating monthly chart with upload data');
        console.log('Labels from upload:', uploadResponse.labels);
        console.log('Sales data from upload:', uploadResponse.sales);
        
        const ds = {
          labels: uploadResponse.labels,
          datasets: [{
            label: 'Monthly Sales',
            data: uploadResponse.sales,
            borderColor: this.defaultColors.primary,
            backgroundColor: 'rgba(13, 60, 105, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.3,
            pointBackgroundColor: this.defaultColors.primary,
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 4
          }]
        };
        console.log('Dataset created:', ds);
        this.createMonthlySalesTrendsChart('salesOverviewChart', ds);
        console.log('Monthly chart updated successfully');
        
      } else if (selectValue === 'product' && uploadResponse.labels && uploadResponse.sales) {
        console.log('Creating product chart with upload data');
        const ds = {
          labels: uploadResponse.labels,
          datasets: [{
            label: 'Sales',
            data: uploadResponse.sales,
            backgroundColor: uploadResponse.labels.map((_, idx) => (idx % 2 === 0 ? this.defaultColors.primary : this.defaultColors.secondary)),
            borderRadius: 4,
            borderSkipped: false
          }]
        };
        this.createSalesByProductChart('salesOverviewChart', ds);
        console.log('Product chart updated successfully');
        
      } else if (selectValue === 'weekly' && uploadResponse.type === 'weekly' && uploadResponse.labels && uploadResponse.data) {
        console.log('Creating weekly chart with upload data');
        const ds = {
          labels: uploadResponse.labels,
          datasets: [{
            label: 'Weekly Sales',
            data: uploadResponse.data,
            borderColor: this.defaultColors.primary,
            backgroundColor: 'rgba(13, 60, 105, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.3,
            pointBackgroundColor: this.defaultColors.primary,
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 4
          }]
        };
        this.createSalesOverviewChart('salesOverviewChart', ds);
        console.log('Weekly chart updated successfully');
      } else {
        console.warn('No valid data found in upload response for chart update');
      }
    } catch (error) {
      console.error('Error updating chart after upload:', error);
    }
  }

  // Initialize Sales Management charts with real data from database
  // Initialize sales page with new structure (merged charts)
  async initializeSalesPage() {
    try {
      // Initialize the combined monthly/weekly chart with monthly data by default
      const monthlyData = await this.fetchMonthlySalesApi();
      if (monthlyData) {
        this.createMonthlySalesTrendsChart('monthlySalesTrendsChart', monthlyData);
        console.log('Sales Management combined chart created with real monthly data');
      } else {
        this.createMonthlySalesTrendsChart('monthlySalesTrendsChart');
        console.log('Sales Management combined chart created with default monthly data');
      }
      
      // Initialize sales by product chart
      const productData = await this.fetchSalesByProductApi();
      if (productData) {
        this.createSalesByProductChart('salesByProductChart', productData);
        console.log('Sales Management product chart created with real data');
      } else {
        this.createSalesByProductChart('salesByProductChart');
        console.log('Sales Management product chart created with default data');
      }
      
    } catch (error) {
      console.error('Error initializing sales page:', error);
    }
  }

  async initializeSalesChartsWithData() {
    try {
      // Fetch monthly sales data from database
      const monthlyData = await this.fetchMonthlySalesApi();
      if (monthlyData) {
        this.createMonthlySalesTrendsChart('monthlySalesTrendsChart', monthlyData);
        console.log('Sales Management monthly chart created with real data');
      } else {
        this.createMonthlySalesTrendsChart('monthlySalesTrendsChart');
        console.log('Sales Management monthly chart created with default data');
      }
      
      // Fetch weekly sales data from database
      await this.createWeeklySalesChart('weeklySalesChart');
      
      // Fetch sales by product data from database
      const productData = await this.fetchSalesByProductApi();
      if (productData) {
        this.createSalesByProductChart('salesByProductChart', productData);
        console.log('Sales Management product chart created with real data');
      } else {
        this.createSalesByProductChart('salesByProductChart');
        console.log('Sales Management product chart created with default data');
      }
    } catch (error) {
      console.error('Error initializing sales charts with data:', error);
      // Fallback to default charts
      this.createMonthlySalesTrendsChart('monthlySalesTrendsChart');
      await this.createWeeklySalesChart('weeklySalesChart');
      this.createSalesByProductChart('salesByProductChart');
    }
  }

  // Helpers to fetch API data and convert into Chart.js datasets
  async fetchMonthlySalesApi() {
    try {
      const res = await fetch(`${this.API_BASE}/api/sales/monthly`, { credentials: 'include', headers: this.getAuthHeaders() });
      if (!res.ok) return null;
      const j = await res.json();
      return {
        labels: j.labels,
        datasets: [{
          label: 'Monthly Sales',
          data: j.data,
          borderColor: this.defaultColors.primary,
          backgroundColor: 'rgba(13, 60, 105, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.3
        }]
      };
    } catch (e) { console.warn('Monthly API error', e); return null; }
  }

  async fetchSalesByProductApi() {
    try {
      const res = await fetch(`${this.API_BASE}/api/sales/by-product`, { credentials: 'include', headers: this.getAuthHeaders() });
      if (!res.ok) return null;
      const j = await res.json();
      return {
        labels: j.labels,
        datasets: [{
          label: 'Sales',
          data: j.data,
          backgroundColor: j.labels.map((_, idx) => (idx % 2 === 0 ? this.defaultColors.primary : this.defaultColors.secondary)),
          borderRadius: 4,
          borderSkipped: false
        }]
      };
    } catch (e) { console.warn('By-product API error', e); return null; }
  }

  async fetchWeeklySalesApi() {
    try {
      const res = await fetch(`${this.API_BASE}/api/sales/weekly`, { credentials: 'include', headers: this.getAuthHeaders() });
      if (!res.ok) return null;
      const j = await res.json();
      return {
        labels: j.labels,
        datasets: [{
          label: 'Weekly Sales',
          data: j.data,
          borderColor: this.defaultColors.primary,
          backgroundColor: 'rgba(13, 60, 105, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.3,
          pointBackgroundColor: this.defaultColors.primary,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4
        }]
      };
    } catch (e) { console.warn('Weekly API error', e); return null; }
  }

  async fetchDailySalesApi() {
    try {
      const res = await fetch(`${this.API_BASE}/api/sales/daily`, { credentials: 'include', headers: this.getAuthHeaders() });
      if (!res.ok) return null;
      const j = await res.json();
      return {
        labels: j.labels,
        datasets: [{
          label: 'Daily Sales',
          data: j.data,
          borderColor: this.defaultColors.primary,
          backgroundColor: 'rgba(13, 60, 105, 0.1)',
          borderWidth: 2,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: this.defaultColors.primary,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4
        }]
      };
    } catch (e) { console.warn('Daily API error', e); return null; }
  }

  // Destroy all existing charts
  destroyAllCharts() {
    Object.keys(this.charts).forEach(chartId => {
      if (this.charts[chartId]) {
        this.charts[chartId].destroy();
        delete this.charts[chartId];
      }
    });
  }

  // Set up automatic inventory refresh
  setupInventoryAutoRefresh() {
    console.log('Setting up inventory auto-refresh...');
    
    // Initial load
    this.fetchAndUpdateInventoryStatus();
    
    // Auto-refresh every 5 minutes (300000ms)
    this.inventoryRefreshInterval = setInterval(() => {
      this.fetchAndUpdateInventoryStatus();
    }, 300000);
  }

  // Clear auto-refresh when leaving dashboard
  clearInventoryAutoRefresh() {
    if (this.inventoryRefreshInterval) {
      clearInterval(this.inventoryRefreshInterval);
      this.inventoryRefreshInterval = null;
    }
  }

  // Fetch real data from API and update charts
  async fetchAndUpdateCharts() {
    try {
      // This endpoint doesn't exist, so we'll skip this call
      console.log('fetchAndUpdateCharts called but endpoint not implemented');
      // const response = await fetch('/api/dashboard/charts-data');
      // const data = await response.json();
      
      // Update charts with real data
      // if (data.salesOverview) {
      //   this.updateChartData('salesOverviewChart', data.salesOverview);
      // }
      // if (data.monthlySales) {
      //   this.updateChartData('monthlySalesTrendsChart', data.monthlySales);
      // }
      // Add more data updates as needed
    } catch (error) {
      console.error('Error fetching chart data:', error);
    }
  }

  // Fetch and update inventory status on dashboard
  async fetchAndUpdateInventoryStatus() {
    try {
      console.log('Fetching inventory data...');
      const response = await fetch(`${this.API_BASE}/api/products`, {
        credentials: 'include',
        headers: this.getAuthHeaders()
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const products = await response.json();
      console.log('Inventory data fetched successfully:', products);
      console.log('Number of products:', products.length);
      if (products.length > 0) {
        console.log('Sample product:', products[0]);
      }
      this.updateInventoryDisplay(products);
      
    } catch (error) {
      console.error('Error fetching inventory data:', error);
      this.showInventoryError();
    }
  }

  // Refresh inventory with animation
  async refreshInventoryWithAnimation() {
    const refreshBtn = document.querySelector('.refresh-btn');
    const refreshIcon = document.querySelector('.refresh-icon');
    
    if (!refreshBtn || !refreshIcon) return;
    
    // Disable button and start animation
    refreshBtn.disabled = true;
    refreshBtn.classList.add('refreshing');
    
    // Show loading state
    this.showInventoryLoading();
    
    // Update the SVG to the second variant during animation
    const originalPath = refreshIcon.querySelector('path');
    const originalD = originalPath.getAttribute('d');
    
    // Change to second SVG path during animation
    setTimeout(() => {
      originalPath.setAttribute('d', 'M14 16H19V21M10 8H5V3M19.4176 9.0034C18.8569 7.61566 17.9181 6.41304 16.708 5.53223C15.4979 4.65141 14.0652 4.12752 12.5723 4.02051C11.0794 3.9135 9.58606 4.2274 8.2627 4.92661C6.93933 5.62582 5.83882 6.68254 5.08594 7.97612M4.58203 14.9971C5.14272 16.3848 6.08146 17.5874 7.29157 18.4682C8.50169 19.3491 9.93588 19.8723 11.4288 19.9793C12.9217 20.0863 14.4138 19.7725 15.7371 19.0732C17.0605 18.374 18.1603 17.3175 18.9131 16.0239');
    }, 500);
    
    try {
      // Fetch and update inventory data
      console.log('Refreshing inventory data...');
      await this.fetchAndUpdateInventoryStatus();
    } catch (error) {
      console.error('Error refreshing inventory:', error);
    } finally {
      // Restore original icon and re-enable button after animation
      setTimeout(() => {
        originalPath.setAttribute('d', originalD);
        refreshBtn.classList.remove('refreshing');
        refreshBtn.disabled = false;
      }, 1000);
    }
  }

  // Update the inventory display with real data as a Chart.js bar chart
  updateInventoryDisplay(products) {
    const inventoryList = document.querySelector('.inventory-list');
    if (!inventoryList) return;

    // Clear existing items
    inventoryList.innerHTML = '';

    if (products.length === 0) {
      inventoryList.innerHTML = `
        <div class="inventory-item">
          <span>No products found</span>
          <span class="inventory-value">0 items</span>
        </div>
      `;
      return;
    }

    // Prepare data for Chart.js first
    // Separate out-of-stock products and other products
    const outOfStockProducts = products.filter(p => p.quantity === 0);
    const inStockProducts = products.filter(p => p.quantity > 0);
    
    // Sort in-stock products by quantity (highest first)
    const sortedInStock = inStockProducts.sort((a, b) => b.quantity - a.quantity);
    
    // Combine: show all in-stock products first, then all out-of-stock products at the end
    // This ensures all products are visible with proper ordering
    const sortedProducts = [
      ...sortedInStock,
      ...outOfStockProducts
    ];

    // Create container for chart with horizontal scroll
    const chartContainer = document.createElement('div');
    chartContainer.className = 'inventory-chart-container';
    chartContainer.style.cssText = `
      width: 100%;
      overflow-x: auto;
      overflow-y: hidden;
      padding: 10px 0;
    `;
    
    // Create canvas element for Chart.js
    const canvas = document.createElement('canvas');
    canvas.id = 'inventoryBarChart';
    
    // Set canvas size based on number of products
    const minWidthPerBar = 80; // Minimum width per bar
    const chartWidth = Math.max(400, sortedProducts.length * minWidthPerBar);
    canvas.width = chartWidth;
    canvas.height = 300;
    
    chartContainer.appendChild(canvas);
    inventoryList.appendChild(chartContainer);
    
    // Add wheel event listener for horizontal scrolling
    chartContainer.addEventListener('wheel', (e) => {
      e.preventDefault();
      chartContainer.scrollLeft += e.deltaY;
    }, { passive: false });

    const labels = sortedProducts.map(product => product.name);
    const data = sortedProducts.map(product => product.quantity);
    const backgroundColors = sortedProducts.map(product => {
      const status = this.getStockStatus(product.quantity);
      switch (status) {
        case 'high-stock': return '#28a745';
        case 'medium-stock': return '#ffc107';
        case 'low-stock': return '#dc3545';
        case 'out-of-stock': return '#6c757d';
        default: return '#0d3c69';
      }
    });

    // Create Chart.js bar chart
    const ctx = canvas.getContext('2d');
    
    // Destroy existing chart if it exists
    if (this.charts['inventoryBarChart']) {
      this.charts['inventoryBarChart'].destroy();
      delete this.charts['inventoryBarChart'];
    }

    this.charts['inventoryBarChart'] = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Stock Quantity',
          data: data,
          backgroundColor: backgroundColors,
          borderColor: backgroundColors.map(color => color),
          borderWidth: 1,
          borderRadius: 4,
          borderSkipped: false,
        }]
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            enabled: true,
            mode: 'nearest',
            intersect: false,
            backgroundColor: 'rgba(0, 0, 0, 0.9)',
            titleColor: '#fff',
            bodyColor: '#fff',
            borderColor: '#0d3c69',
            borderWidth: 1,
            cornerRadius: 6,
            displayColors: false,
            titleFont: {
              size: 13,
              weight: 'bold'
            },
            bodyFont: {
              size: 12
            },
            padding: 10,
            callbacks: {
              title: function(context) {
                return context[0].label;
              },
              label: function(context) {
                const product = sortedProducts[context.dataIndex];
                const unit = chartManager.getProductUnit(product.name);
                if (product.quantity === 0) {
                  return `${product.name}: OUT OF STOCK`;
                }
                return `${product.name}: ${product.quantity} ${unit}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              maxRotation: 45,
              minRotation: 0,
              font: {
                size: 11
              }
            },
            offset: false
          },
          y: {
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.1)'
            },
            ticks: {
              font: {
                size: 11
              }
            },
            offset: false
          }
        },
        layout: {
          padding: {
            bottom: 0,
            top: 0,
            left: 0,
            right: 0
          }
        },
        interaction: {
          mode: 'nearest',
          intersect: false,
        },
        // Make all bars exactly the same width
        categoryPercentage: 0.7,
        barPercentage: 0.8,
      }
    });

    // Store reference to chartManager for tooltip callback
    const chartManager = this;
  }

  // Show loading state during refresh
  showInventoryLoading() {
    const inventoryList = document.querySelector('.inventory-list');
    if (!inventoryList) return;

    inventoryList.innerHTML = `
      <div class="inventory-loading">
        <div class="loading-spinner"></div>
        <span>Loading inventory data...</span>
      </div>
    `;
  }

  // Determine appropriate unit for product
  getProductUnit(productName) {
    const name = productName.toLowerCase();
    if (name.includes('bean') || name.includes('coffee')) return 'lbs';
    if (name.includes('milk') || name.includes('cream')) return 'gallons';
    if (name.includes('sugar') || name.includes('syrup')) return 'lbs';
    if (name.includes('cup') || name.includes('lid')) return 'units';
    return 'items';
  }

  // Get stock status class based on quantity
  getStockStatus(quantity) {
    if (quantity === 0) return 'out-of-stock';
    if (quantity < 10) return 'low-stock';
    if (quantity < 50) return 'medium-stock';
    return 'high-stock';
  }

  // Show error message in inventory section
  showInventoryError() {
    const inventoryList = document.querySelector('.inventory-list');
    if (!inventoryList) return;

    inventoryList.innerHTML = `
      <div class="inventory-error">
        <div class="error-icon">⚠️</div>
        <span>Unable to load inventory data</span>
        <button onclick="chartManager.fetchAndUpdateInventoryStatus()" class="retry-btn">Retry</button>
      </div>
    `;
  }
}

// Global chart manager instance
const chartManager = new ChartManager();

// Export for use in other files
if (typeof window !== 'undefined') {
  window.chartManager = chartManager;
}

// Auto-initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Detect which page we're on
  const currentPage = window.location.pathname.includes('sales') ? 'sales' : 'dashboard';
  
  // PROTECTION: Actively prevent Chart.js from creating charts in wrong places
  if (currentPage === 'dashboard') {
    // Remove any canvas elements that shouldn't be there
    const productSoldSection = document.getElementById('product-sold-section');
    const recentOrdersSection = document.getElementById('recent-orders-section');
    
    if (productSoldSection) {
      const unwantedCanvases = productSoldSection.querySelectorAll('canvas');
      unwantedCanvases.forEach(canvas => {
        console.warn('Removing unwanted canvas from Product Sold section:', canvas);
        canvas.remove();
      });
    }
    
    if (recentOrdersSection) {
      const unwantedCanvases = recentOrdersSection.querySelectorAll('canvas');
      unwantedCanvases.forEach(canvas => {
        console.warn('Removing unwanted canvas from Recent Orders section:', canvas);
        canvas.remove();
      });
    }
    
    // Override Chart constructor to prevent unauthorized chart creation
    const originalChart = window.Chart;
    window.Chart = function(ctx, config) {
      // Check if this is being created in the wrong place
      if (ctx && ctx.closest && (ctx.closest('#product-sold-section') || ctx.closest('#recent-orders-section'))) {
        console.error('BLOCKED: Attempt to create chart in bottom sections');
        return null;
      }
      return new originalChart(ctx, config);
    };
    
    // Copy all static methods and properties
    Object.setPrototypeOf(window.Chart, originalChart);
    Object.getOwnPropertyNames(originalChart).forEach(prop => {
      if (prop !== 'length' && prop !== 'name' && prop !== 'prototype') {
        window.Chart[prop] = originalChart[prop];
      }
    });
  }
  
  // Small delay to ensure DOM is fully ready
  setTimeout(() => {
    chartManager.initializeCharts(currentPage);
  }, 100);
});

// Clean up intervals when leaving the page
window.addEventListener('beforeunload', function() {
  chartManager.clearInventoryAutoRefresh();
});

// Custom confirmation modal functions for chart uploads
function showChartConfirmationModal(fileName, filterType, onConfirm, onCancel) {
  // Create modal if it doesn't exist
  let modal = document.getElementById('chartConfirmationModal');
  if (!modal) {
    modal = createChartConfirmationModal();
  }
  
  const message = document.getElementById('chartConfirmationMessage');
  const details = document.getElementById('chartConfirmationDetails');
  
  // Update the message with file name and filter type
  message.textContent = `Are you sure you want to upload "${fileName}" for ${filterType} sales data?`;
  
  // Update details based on filter type
  const detailsList = details.querySelector('ul');
  detailsList.innerHTML = `
    <li>Replace the current ${filterType} data</li>
    <li>Update the ${filterType} chart display</li>
    <li>Save the data to the database</li>
  `;
  
  // Store the callbacks globally for the modal buttons
  window.chartConfirmationCallbacks = { onConfirm, onCancel };
  
  // Show the modal
  modal.classList.add('show');
}

function createChartConfirmationModal() {
  const modal = document.createElement('div');
  modal.id = 'chartConfirmationModal';
  modal.className = 'confirmation-modal';
  modal.innerHTML = `
    <div class="confirmation-card">
      <div class="confirmation-header">
        <div class="confirmation-icon">📊</div>
        <h3 class="confirmation-title">Confirm Chart Upload</h3>
      </div>
      <div class="confirmation-body">
        <p class="confirmation-message" id="chartConfirmationMessage">
          Are you sure you want to upload this file?
        </p>
        <div class="confirmation-details" id="chartConfirmationDetails">
          <ul>
            <li>Replace the current data</li>
            <li>Update the chart display</li>
            <li>Save the data to the database</li>
          </ul>
        </div>
        <div class="confirmation-actions">
          <button class="confirmation-btn confirmation-btn-cancel" onclick="closeChartConfirmationModal()">
            Cancel
          </button>
          <button class="confirmation-btn confirmation-btn-confirm" onclick="confirmChartUpload()">
            Upload
          </button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  return modal;
}

function closeChartConfirmationModal() {
  const modal = document.getElementById('chartConfirmationModal');
  if (modal) {
    modal.classList.remove('show');
  }
  
  // Call cancel callback if it exists
  if (window.chartConfirmationCallbacks && window.chartConfirmationCallbacks.onCancel) {
    window.chartConfirmationCallbacks.onCancel();
  }
  
  // Clear callbacks
  window.chartConfirmationCallbacks = null;
}

function confirmChartUpload() {
  const modal = document.getElementById('chartConfirmationModal');
  if (modal) {
    modal.classList.remove('show');
  }
  
  // Call confirm callback if it exists
  if (window.chartConfirmationCallbacks && window.chartConfirmationCallbacks.onConfirm) {
    window.chartConfirmationCallbacks.onConfirm();
  }
  
  // Clear callbacks
  window.chartConfirmationCallbacks = null;
}

// Refactored chart upload function
async function proceedWithChartUpload(file, filterType, select, uploadInput) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('type', filterType);
  
  try {
    console.log('Starting upload request...');
    console.log('File:', file.name, 'Type:', file.type);
    console.log('Upload type:', filterType);
    
    // Add timeout and retry mechanism for upload
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
    
    const response = await fetch('http://localhost:3000/api/sales/upload', {
      method: 'POST',
      body: formData,
      credentials: 'include',
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('auth.token')}`
      },
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server error: ${response.status} ${errorText}`);
    }
    
    const result = await response.json();
    console.log('Upload response:', result);
    
    if (result.success) {
      console.log('Upload successful');
      
      // Update chart after successful upload
      setTimeout(() => {
        updateChartAfterUpload(select.value, result);
        saveFilterSelection(select.value); // Ensure filter selection is maintained after upload
      }, 500);
      
    } else {
      throw new Error(result.error || 'Upload failed');
    }
    
  } catch (error) {
    console.error('Upload error:', error);
    
    if (error.name === 'AbortError') {
      alert('Upload timed out. Please try again with a smaller file.');
    } else if (error.message.includes('Failed to fetch')) {
      alert('Network connection issue. Please check your connection and try again.');
    } else {
      alert('Upload failed: ' + error.message);
    }
  } finally {
    uploadInput.value = '';
  }
}