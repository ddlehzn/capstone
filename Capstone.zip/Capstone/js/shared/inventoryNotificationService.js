// Inventory Notification Service for Chat System
class InventoryNotificationService {
  constructor(options) {
    options = options || {};
    this.API_BASE = 'http://localhost:3000/api';
    this.checkInterval = options.checkInterval || 10000; // 10 seconds default
    this.lowStockThreshold = 10;
    this.outOfStockThreshold = 0;
    this.notifiedProducts = new Set(); // Track which products we've already notified about
    this.productStockLevels = new Map(); // Track previous stock levels to detect changes
    this.notificationHistory = new Map(); // Track what notifications we've sent
    this.isRunning = false;
    this.intervalId = null;
    this.lastCheckTime = null;
    this.callbacks = [];
    this.isInitialized = false; // Track if we've done initial setup
    this.lastNotified = new Map(); // productId -> { type, timestamp, quantity }
      // Singleton guard
      if (InventoryNotificationService._instance) {
        return InventoryNotificationService._instance;
      }
      InventoryNotificationService._instance = this;
      // Restore persisted stock levels to prevent duplicate notifications on refresh
      try {
        const persisted = typeof window !== 'undefined' ? window.localStorage.getItem('inventory.stockLevels') : null;
        if (persisted) {
          const parsed = JSON.parse(persisted);
          Object.keys(parsed).forEach(pid => {
            this.productStockLevels.set(Number(pid), Number(parsed[pid]));
          });
          console.log(`Restored ${this.productStockLevels.size} persisted stock levels`);
        }
        const notifiedRaw = window.localStorage.getItem('inventory.lastNotified');
        if (notifiedRaw) {
          const map = JSON.parse(notifiedRaw);
          Object.keys(map).forEach(pid => {
            this.lastNotified.set(Number(pid), map[pid]);
          });
        }
      } catch (e) {
        console.warn('Failed to restore persisted stock levels:', e);
      }

      // Listen for global inventory update events
      if (typeof window !== 'undefined') {
        window.addEventListener('inventory-updated', () => {
          this.onInventoryUpdate();
        });
      }
  }

  // Get authentication headers
  getAuthHeaders() {
    const token = sessionStorage.getItem('auth.token');
    return {
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    };
  }

  // Add callback function to be called when notifications are triggered
  onNotification(callback) {
    this.callbacks.push(callback);
  }

  // Remove callback function
  offNotification(callback) {
    const index = this.callbacks.indexOf(callback);
    if (index > -1) {
      this.callbacks.splice(index, 1);
    }
  }

  // Trigger all registered callbacks with notification data
  triggerCallbacks(notification) {
    this.callbacks.forEach(callback => {
      try {
        callback(notification);
      } catch (error) {
        console.error('Error in notification callback:', error);
      }
    });
  }

  // Fetch current inventory data
  async fetchInventoryData() {
    try {
      const response = await fetch(`${this.API_BASE}/products`, {
        method: 'GET',
        headers: this.getAuthHeaders(),
        credentials: 'include'
      });

      if (response.ok) {
        return await response.json();
      } else {
        console.error('Failed to fetch inventory data:', response.statusText);
        return [];
      }
    } catch (error) {
      console.error('Error fetching inventory data:', error);
      return [];
    }
  }

  // Check inventory levels and generate notifications
  async checkInventoryLevels() {
    const products = await this.fetchInventoryData();
    const notifications = [];

    products.forEach(product => {
      const quantity = Number(product.quantity) || 0;
      const productId = product.id;
      const previousQuantity = this.productStockLevels.get(productId);
      
      // Update the stock level tracking
      this.productStockLevels.set(productId, quantity);
      
      // Notify on ANY inventory change
      let shouldNotify = false;
      let notificationType = null;
      let changeDirection = '';

      if (previousQuantity !== undefined) { 
        // Not first time checking - notify on any change
        if (previousQuantity !== quantity) {
          shouldNotify = true;
          
          if (quantity === 0) {
            notificationType = 'out-of-stock';
            changeDirection = 'decreased to 0';
          } else if (quantity <= this.lowStockThreshold) {
            notificationType = 'low-stock';
            changeDirection = previousQuantity > quantity ? 'decreased to' : 'increased to';
          } else if (previousQuantity <= this.lowStockThreshold && quantity > this.lowStockThreshold) {
            notificationType = 'stock-recovered';
            changeDirection = 'increased to';
          } else {
            notificationType = 'stock-changed';
            changeDirection = previousQuantity > quantity ? 'decreased to' : 'increased to';
          }
        } else {
          // Quantity didn't change since last check.
          // If the product remains in a critical band but the absolute quantity changed earlier
          // in the same band (we persist last notified quantity), re-notify immediately.
          const last = this.lastNotified.get(productId);
          const isCritical = quantity === 0 || quantity <= this.lowStockThreshold;
          if (isCritical) {
            const currentType = quantity === 0 ? 'out-of-stock' : 'low-stock';
            if (!last || last.type !== currentType || last.quantity !== quantity) {
              shouldNotify = true;
              notificationType = currentType;
              changeDirection = quantity === 0 ? 'is at 0' : 'is at';
            }
          }
        }
        console.log(`Product ${product.name}: ${previousQuantity} → ${quantity}, shouldNotify: ${shouldNotify}, type: ${notificationType}`);
      } else {
        // First time checking - notify about current status if it's problematic
        if (quantity === 0) {
          shouldNotify = true;
          notificationType = 'out-of-stock';
          changeDirection = 'is currently out of stock';
        } else if (quantity <= this.lowStockThreshold) {
          shouldNotify = true;
          notificationType = 'low-stock';
          changeDirection = 'is currently low on stock';
        }
        console.log(`Product ${product.name}: First check, quantity: ${quantity}, shouldNotify: ${shouldNotify}, type: ${notificationType}`);
      }

      if (!shouldNotify) {
        return;
      }

      let notification = null;

      if (notificationType === 'out-of-stock') {
        notification = {
          type: 'out-of-stock',
          severity: 'critical',
          product: product,
          message: `CRITICAL: "${product.name}" ${changeDirection}!`,
          description: 'This product is out of stock and needs immediate restocking to avoid sales disruption.',
          timestamp: new Date(),
          id: `out-of-stock-${productId}-${Date.now()}`
        };
      } else if (notificationType === 'low-stock') {
        notification = {
          type: 'low-stock',
          severity: 'warning',
          product: product,
          message: `LOW STOCK: "${product.name}" ${changeDirection} ${quantity} units!`,
          description: 'This product is low on stock. Consider restocking soon to avoid running out.',
          timestamp: new Date(),
          id: `low-stock-${productId}-${Date.now()}`
        };
      } else if (notificationType === 'stock-recovered') {
        notification = {
          type: 'stock-recovered',
          severity: 'info',
          product: product,
          message: `STOCK RECOVERED: "${product.name}" ${changeDirection} ${quantity} units!`,
          description: 'This product has recovered from low stock status.',
          timestamp: new Date(),
          id: `stock-recovered-${productId}-${Date.now()}`
        };
      } else if (notificationType === 'stock-changed') {
        notification = {
          type: 'stock-changed',
          severity: 'info',
          product: product,
          message: `STOCK UPDATE: "${product.name}" ${changeDirection} ${quantity} units`,
          description: `Stock level changed from ${previousQuantity} to ${quantity} units.`,
          timestamp: new Date(),
          id: `stock-changed-${productId}-${Date.now()}`
        };
      }

      if (notification) {
        notifications.push(notification);
        this.lastNotified.set(productId, { type: notification.type, timestamp: Date.now(), quantity });
        console.log('Generated inventory notification:', notification);
      }
    });

    // Clean up notification history for products that are no longer problematic
    this.cleanupNotificationHistory(products);

    // Trigger callbacks for each notification
    notifications.forEach(notification => {
      this.triggerCallbacks(notification);
    });

    // Persist latest stock levels so reloads do not re-trigger baselines
    try {
      if (typeof window !== 'undefined') {
        const toPersist = {};
        this.productStockLevels.forEach((qty, pid) => { toPersist[pid] = qty; });
        window.localStorage.setItem('inventory.stockLevels', JSON.stringify(toPersist));
        const notifiedPersist = {};
        this.lastNotified.forEach((val, pid) => { notifiedPersist[pid] = val; });
        window.localStorage.setItem('inventory.lastNotified', JSON.stringify(notifiedPersist));
      }
    } catch (e) {
      console.warn('Failed to persist stock levels:', e);
    }

    this.lastCheckTime = new Date();
    return notifications;
  }

  // Clean up notification history for products that have recovered
  cleanupNotificationHistory(currentProducts) {
    const keysToRemove = [];
    
    this.notificationHistory.forEach((notificationData, key) => {
      const product = currentProducts.find(p => p.id == notificationData.productId);
      if (product) {
        const currentQuantity = Number(product.quantity) || 0;
        
        // If product recovered from the problem, remove the notification history
        if (notificationData.type === 'out-of-stock' && currentQuantity > 0) {
          keysToRemove.push(key);
          console.log(`Product ${product.name} recovered from out-of-stock, clearing notification history`);
        } else if (notificationData.type === 'low-stock' && currentQuantity > this.lowStockThreshold) {
          keysToRemove.push(key);
          console.log(`Product ${product.name} recovered from low stock, clearing notification history`);
        }
      }
    });

    keysToRemove.forEach(key => {
      this.notificationHistory.delete(key);
    });
  }

  // Initialize stock levels without sending notifications (for page load)
  async initializeStockLevels() {
    try {
      const products = await this.fetchInventoryData();
      
      // Just record current stock levels without sending notifications
      products.forEach(product => {
        const quantity = Number(product.quantity) || 0;
        const productId = product.id;
        this.productStockLevels.set(productId, quantity);
      });
      
      console.log('Initialized stock levels for', products.length, 'products');
      return true;
    } catch (error) {
      console.error('Error initializing stock levels:', error);
      return false;
    }
  }

  // Start the notification service
  start() {
    if (this.isRunning) {
      console.log('Inventory notification service is already running');
      return;
    }

    console.log('Starting inventory notification service...');
    this.isRunning = true;
    
    // Do initial check immediately to notify about current status
    this.checkInventoryLevels().then(() => {
      console.log('Initial inventory check completed, starting monitoring...');
      this.isInitialized = true;
      
      // Set up interval for periodic checks
      this.intervalId = setInterval(() => {
        console.log('Periodic inventory check...');
        this.checkInventoryLevels();
      }, this.checkInterval);
      
      console.log(`🔄 Inventory monitoring active - checking every ${this.checkInterval/1000} seconds`);
    });
  }

  // Stop the notification service
  stop() {
    if (!this.isRunning) {
      return;
    }

    console.log('Stopping inventory notification service...');
    this.isRunning = false;

    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  // Reset tracking (useful for testing or when you want fresh notifications)
  reset() {
    this.productStockLevels.clear();
    this.notifiedProducts.clear();
    this.notificationHistory.clear();
    this.isInitialized = false;
    console.log('Inventory notification tracking reset - will re-establish baselines');
  }

  // Manually check inventory once (for testing)
  async checkOnce() {
    console.log('Manual inventory check triggered');
    return await this.checkInventoryLevels();
  }

  // Force immediate check (for when inventory is updated)
  async forceCheck() {
    console.log('Forced inventory check - checking for immediate changes');
    return await this.checkInventoryLevels();
  }

  // Add method to be called when inventory is updated elsewhere
  async onInventoryUpdate() {
    console.log('Inventory update detected - performing immediate check');
    // Event-driven: always notify immediately
    await this.checkInventoryLevels({forceNotify: true});
  }

  // Test method to simulate a stock level and trigger notifications
  async testNotification(productId, simulatedPreviousQuantity) {
    console.log(`Testing notification for product ${productId} with simulated previous quantity ${simulatedPreviousQuantity}`);
    // Temporarily set a previous quantity to test notifications
    this.productStockLevels.set(productId, simulatedPreviousQuantity);
    await this.forceCheck();
  }

  // Get service status
  getStatus() {
    return {
      isRunning: this.isRunning,
      lastCheckTime: this.lastCheckTime,
      checkInterval: this.checkInterval,
      notifiedProductsCount: this.notifiedProducts.size,
      callbacksCount: this.callbacks.length
    };
  }

  // Manual trigger for testing
  async triggerManualCheck() {
    console.log('Manual inventory check triggered');
    return await this.checkInventoryLevels();
  }

  // Update thresholds
  updateThresholds(lowStock = 10, outOfStock = 0) {
    this.lowStockThreshold = lowStock;
    this.outOfStockThreshold = outOfStock;
    console.log(`Thresholds updated: Low Stock = ${lowStock}, Out of Stock = ${outOfStock}`);
  }

  // Reset notification history (for testing)
  resetNotifications() {
    this.notifiedProducts.clear();
    console.log('Notification history reset');
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = InventoryNotificationService;
} else {
  window.InventoryNotificationService = InventoryNotificationService;
}