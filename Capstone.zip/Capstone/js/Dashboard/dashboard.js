// Logout function now uses the global logout modal
// The actual logout functionality is handled by logoutModal.js
async function logout() {
    showLogoutModal();
}

// Burger menu functionality
document.addEventListener('DOMContentLoaded', function() {
    const burgerMenu = document.getElementById('burgerMenu');
    const mobileNavOverlay = document.getElementById('mobileNavOverlay');
    
    function openMobileMenu() {
        burgerMenu.classList.add('open');
        mobileNavOverlay.classList.add('active');
        // Only prevent body scroll when mobile menu is open
        if (window.innerWidth <= 768) {
            document.body.style.overflow = 'hidden';
        }
    }
    
    function closeMobileMenu() {
        burgerMenu.classList.remove('open');
        mobileNavOverlay.classList.remove('active');
        // Restore body scroll
        document.body.style.overflow = '';
    }
    
    if (burgerMenu && mobileNavOverlay) {
        // Toggle mobile menu
        burgerMenu.addEventListener('click', function() {
            if (mobileNavOverlay.classList.contains('active')) {
                closeMobileMenu();
            } else {
                openMobileMenu();
            }
        });
        
        // Close menu when clicking on overlay
        mobileNavOverlay.addEventListener('click', function(e) {
            if (e.target === mobileNavOverlay) {
                closeMobileMenu();
            }
        });
        
        // Close menu when clicking on a link
        const mobileNavLinks = mobileNavOverlay.querySelectorAll('a');
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });
        
        // Close menu on window resize if it gets too large
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768 && mobileNavOverlay.classList.contains('active')) {
                closeMobileMenu();
            }
            // Ensure body scroll is restored on resize
            if (window.innerWidth > 768) {
                document.body.style.overflow = '';
            }
        });
    }
});