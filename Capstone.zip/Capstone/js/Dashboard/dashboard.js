// Logout function now uses the global logout modal
// The actual logout functionality is handled by logoutModal.js
async function logout() {
    showLogoutModal();
}