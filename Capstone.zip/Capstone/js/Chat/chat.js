document.addEventListener('DOMContentLoaded', function() {
  // --- EMAIL INTEGRATION ---
  // This chat module now includes email functionality alongside SMS for notifications.
  // Email features include:
  // - Supplier communication via email (inquiries, order confirmations)
  // - User notifications via email (payment requirements, alerts)
  // - HTML email templates for better formatting
  // - Fallback to SMS if email fails
  // 
  // Test functions available in console:
  // - testEmailFunction() - Test user email functionality
  // - testSupplierEmail() - Test supplier email functionality
  //
  // Email configuration required in .env:
  // - EMAIL_USER: Gmail address for sending emails
  // - EMAIL_PASS: Gmail app password (not regular password)
  
  // --- API Functions for Database Integration ---
  const API_BASE = 'http://localhost:3000/api';
  
  // Get authentication token from sessionStorage
  function getAuthToken() {
    return sessionStorage.getItem('auth.token');
  }
  
  // Get authentication headers
  function getAuthHeaders() {
    const token = getAuthToken();
    console.log('Auth token check:', { 
      hasToken: !!token, 
      tokenLength: token ? token.length : 0,
      tokenStart: token ? token.substring(0, 20) + '...' : 'none'
    });
    return {
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    };
  }
  
  // Create new chat session
  async function createNewSession(title = 'New Chat') {
    try {
      const response = await fetch(`${API_BASE}/chat/sessions`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({ title })
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.session;
      } else {
        console.error('Failed to create session:', response.status);
        return null;
      }
    } catch (error) {
      console.error('Error creating session:', error);
      return null;
    }
  }
  
  // Load chat sessions (history)
  async function loadChatSessions() {
    try {
      const response = await fetch(`${API_BASE}/chat/sessions`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.sessions || [];
      } else {
        console.error('Failed to load sessions:', response.status);
        return [];
      }
    } catch (error) {
      console.error('Error loading sessions:', error);
      return [];
    }
  }
  
  // Load messages for a specific session
  async function loadSessionMessages(sessionId) {
    try {
      const response = await fetch(`${API_BASE}/chat/sessions/${sessionId}/messages`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.messages || [];
      } else {
        console.error('Failed to load session messages:', response.status);
        return [];
      }
    } catch (error) {
      console.error('Error loading session messages:', error);
      return [];
    }
  }
  
  // Load chat messages from database (latest session)
  async function loadMessagesFromDB() {
    try {
      const response = await fetch(`${API_BASE}/chat/messages?limit=50`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        return { messages: data.messages || [], sessionId: data.sessionId };
      } else {
        console.error('Failed to load messages:', response.status);
        return { messages: [], sessionId: null };
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      return { messages: [], sessionId: null };
    }
  }
  
  // Save message to database
  async function saveMessageToDB(message, messageType = 'user') {
    if (!currentChatId) {
      console.error('No active session to save message to');
      return null;
    }
    
    try {
      const response = await fetch(`${API_BASE}/chat/messages`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          message: message,
          message_type: messageType,
          session_id: currentChatId
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.data; // Returns the saved message object
      } else {
        console.error('Failed to save message:', response.status);
        return null;
      }
    } catch (error) {
      console.error('Error saving message:', error);
      return null;
    }
  }

  // Rename chat session
  async function renameSession(sessionId, newTitle) {
    try {
      const response = await fetch(`${API_BASE}/chat/sessions/${sessionId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({ title: newTitle })
      });
      
      if (response.ok) {
        return true;
      } else {
        console.error('Failed to rename session:', response.status);
        return false;
      }
    } catch (error) {
      console.error('Error renaming session:', error);
      return false;
    }
  }

  // Delete chat session
  async function deleteSession(sessionId) {
    try {
      const response = await fetch(`${API_BASE}/chat/sessions/${sessionId}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        return true;
      } else {
        console.error('Failed to delete session:', response.status);
        return false;
      }
    } catch (error) {
      console.error('Error deleting session:', error);
      return false;
    }
  }

  const sidebar = document.getElementById('sidebar');
  const sidebarToggle = document.getElementById('sidebarToggle');
  const mobileToggle = document.getElementById('mobileToggle');
  const overlay = document.getElementById('overlay');
  const chatForm = document.getElementById('chatForm');
  const chatInput = document.getElementById('chatInput');
  const chatMessages = document.getElementById('chatMessages');
  const welcomeMessage = document.querySelector('.welcome-message');
  const chatContainer = document.querySelector('.chat-container');
  const newChatBtn = document.getElementById('newChatBtn');
  const collapsedNewChatBtn = document.getElementById('collapsedNewChatBtn');
  const sendBtn = document.querySelector('.send-btn');
  let historyItems = document.querySelectorAll('.history-item');

  // Initialize Inventory Notification Service
  // Use global service if available, otherwise create local one
  const inventoryNotificationService = window.inventoryNotificationService || new InventoryNotificationService();
  
  // Make it globally accessible so other pages can trigger immediate checks
  window.inventoryNotificationService = inventoryNotificationService;
  
  // Set up global notification handler for chat
  window.handleGlobalInventoryNotification = handleInventoryNotification;
  
  // (moved below after notificationChats is defined)
  
  // Register notification handler
  inventoryNotificationService.onNotification(handleInventoryNotification);

  // Persistent chat state
  let messages = [];
  let chatHistory = []; // Will be loaded from database sessions
  let currentChatId = null; // Will store current session ID
  let isSidebarCollapsed = false;
  let isMobileSidebarOpen = false;
  let isTyping = false;
  
  // Track notification chats to prevent duplicates
  let notificationChats = new Map(); // productId -> chatId
  // Process any pending notifications that arrived before chat was ready
  // Include notifications persisted to localStorage (survive module navigation)
  try {
    const storedKey = 'inventory.pendingNotifications';
    const stored = JSON.parse(localStorage.getItem(storedKey) || '[]');
    const queued = window.pendingInventoryNotifications || [];
    const all = [...queued, ...stored];
    if (all.length > 0) {
      console.log(`Processing ${all.length} pending notifications`);
      // Ensure chatHistory is loaded first so mapping works
      updateChatHistoryDisplay().then(() => {
        all.forEach(notification => {
          handleInventoryNotification(notification);
        });
      });
    }
    window.pendingInventoryNotifications = [];
    localStorage.removeItem(storedKey);
  } catch (e) {
    console.warn('Failed to process persisted pending notifications:', e);
  }

  // --- Supplier workflow state helpers (persist across reloads) ---
  function getWorkflowKey(productId) {
    return `supplierWorkflow:${productId}`;
  }
  function getWorkflowStatus(productId) {
    try {
      const key = getWorkflowKey(productId);
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function setWorkflowStatus(productId, statusObj) {
    try {
      const key = getWorkflowKey(productId);
      localStorage.setItem(key, JSON.stringify({ ...statusObj, updatedAt: Date.now() }));
    } catch (e) {}
  }
  function clearWorkflowStatus(productId) {
    try { localStorage.removeItem(getWorkflowKey(productId)); } catch (e) {}
  }

  // --- Inventory Notification Handler ---
  async function handleInventoryNotification(notification) {
    const productId = notification.product.id;
    const productName = notification.product.name;
    
    // Check if we already have a notification chat for this product
    let notificationChatId = notificationChats.get(productId);
    let existingChat = null;
    
    // Verify the chat still exists in our chat history
    if (notificationChatId) {
      existingChat = chatHistory.find(chat => chat.id === notificationChatId);
      if (!existingChat) {
        // Chat was deleted, remove from our tracking
        notificationChats.delete(productId);
        notificationChatId = null;
      }
    }
    
    // Create new chat only if we don't have one for this product
    if (!notificationChatId) {
      const newSession = await createNewSession(`Inventory Alert: ${productName}`);
      if (!newSession) {
        console.error('Failed to create new session for notification');
        return;
      }
      
      notificationChatId = newSession.id;
      notificationChats.set(productId, notificationChatId);
      
      // Update chat history display
      await updateChatHistoryDisplay();
    }
    
    // Add notification message to the existing or new chat
    const notificationMessage = createNotificationMessage(notification);
    await addNotificationToChat(notificationChatId, notificationMessage);
    
    // Handle stock recovery - clear workflow status when stock is restored
    if (notification.type === 'stock-recovered' || notification.type === 'stock-changed') {
      const currentStock = notification.product.quantity;
      if (currentStock > 10) { // Stock is now well above low stock threshold
        clearWorkflowStatus(productId);
        console.log(`Stock recovered for product ${productId} (${currentStock} units) - cleared workflow status`);
      }
    }
    
    // Start the automated supplier communication workflow only for low stock and out of stock
    if (notification.type === 'low-stock' || notification.type === 'out-of-stock') {
      const wf = getWorkflowStatus(productId);
      
      // Check if this is a new stock level change or if workflow should be retriggered
      const shouldStartWorkflow = !wf || 
        wf.state === 'pending' || 
        wf.state === 'awaiting_suppliers' ||
        (wf.state === 'completed' && wf.lastStockLevel !== notification.product.quantity) ||
        (wf.state === 'failed' && wf.lastStockLevel !== notification.product.quantity);
      
      if (shouldStartWorkflow) {
        console.log(`Starting supplier workflow for product ${productId} (${notification.type}) - Stock: ${notification.product.quantity}`);
        setWorkflowStatus(productId, { 
          state: 'in_progress', 
          chatId: notificationChatId,
          lastStockLevel: notification.product.quantity,
          lastNotificationType: notification.type
        });
        await startSupplierCommunicationWorkflow(notification, notificationChatId);
      } else {
        console.log(`Supplier workflow for product ${productId} already ${wf.state} with same stock level (${wf.lastStockLevel}), not retriggering`);
      }
    }
  }

  // Create formatted notification message
  function createNotificationMessage(notification) {
    // Strip emojis from upstream message
    const plainTitle = notification.message.replace(/[\u{1F300}-\u{1FAFF}\u{2700}-\u{27BF}]/gu, '').trim();
    let message = plainTitle + '\n\n';
    message += notification.description + '\n\n';
    
    if (notification.type === 'out-of-stock') {
      message += `Product Details:\n`;
      message += `• Name: ${notification.product.name}\n`;
      message += `• Current Stock: 0 units\n`;
      message += `• Price: ₱${Number(notification.product.price || 0).toLocaleString()}\n\n`;
      message += `Recommendation: Order new stock immediately to avoid losing sales.`;
    } else if (notification.type === 'low-stock') {
      message += `Product Details:\n`;
      message += `• Name: ${notification.product.name}\n`;
      message += `• Current Stock: ${notification.product.quantity} units\n`;
      message += `• Price: ₱${Number(notification.product.price || 0).toLocaleString()}\n\n`;
      message += `Recommendation: Consider restocking to maintain availability.`;
    } else if (notification.type === 'stock-recovered') {
      message += `Product Details:\n`;
      message += `• Name: ${notification.product.name}\n`;
      message += `• Current Stock: ${notification.product.quantity} units\n`;
      message += `• Price: ₱${Number(notification.product.price || 0).toLocaleString()}\n\n`;
      message += `Status: Product has recovered from low stock status.`;
    } else if (notification.type === 'stock-changed') {
      message += `Product Details:\n`;
      message += `• Name: ${notification.product.name}\n`;
      message += `• Current Stock: ${notification.product.quantity} units\n`;
      message += `• Price: ₱${Number(notification.product.price || 0).toLocaleString()}\n\n`;
      message += `Status: Stock level has been updated.`;
    }
    
    return message;
  }

  // Add notification message to chat
  async function addNotificationMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ai';
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    
    // Format the message with line breaks
    const formattedMessage = message.replace(/\n/g, '<br>');
    bubble.innerHTML = formattedMessage;
    
    messageDiv.appendChild(bubble);
    chatMessages.appendChild(messageDiv);

    // Scroll to bottom
    const chatContent = document.querySelector('.chat-content');
    if (chatContent) {
      chatContent.scrollTop = chatContent.scrollHeight;
    }

    // Save notification to database as AI message
    await saveMessageToDB(message, 'ai');
    
    // Update local messages array
    const messageObj = { sender: 'ai', text: message, timestamp: new Date(), isNotification: true };
    messages.push(messageObj);
  }

  // Add notification to a specific chat (without switching to it)
  async function addNotificationToChat(chatId, message) {
    try {
      // Save the notification message to the specified chat in the database
      const response = await fetch(`${API_BASE}/chat/messages`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          message: message,
          message_type: 'ai',
          session_id: chatId
        })
      });
      
      if (!response.ok) {
        console.error('Failed to save notification to chat:', response.status);
        return;
      }
      
      // If this is the currently active chat, add the message to the display
      if (currentChatId === chatId && chatMessages) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message ai';
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        
        // Format the message with line breaks
        const formattedMessage = message.replace(/\n/g, '<br>');
        bubble.innerHTML = formattedMessage;
        
        messageDiv.appendChild(bubble);
        chatMessages.appendChild(messageDiv);

        // Scroll to bottom
        const chatContent = document.querySelector('.chat-content');
        if (chatContent) {
          chatContent.scrollTop = chatContent.scrollHeight;
        }

        // Update local messages array
        const messageObj = { sender: 'ai', text: message, timestamp: new Date(), isNotification: true };
        messages.push(messageObj);
      }
      
      console.log(`Added notification to chat ${chatId}:`, message.substring(0, 50) + '...');
    } catch (error) {
      console.error('Error adding notification to chat:', error);
    }
  }

  // --- Supplier Communication Workflow ---
  async function startSupplierCommunicationWorkflow(notification, chatId) {
    try {
      const product = notification.product;
      const productName = product.name;
      const currentStock = product.quantity;
      const productId = product.id || productName;
      
      // Add initial workflow message to chat
      const workflowMessage = `Automated Reorder Process Started\n\n` +
        `I'm now contacting suppliers to restock "${productName}". ` +
        `Current stock: ${currentStock} units.\n\n` +
        `Please wait while I process this automatically...`;
      
      await addNotificationToChat(chatId, workflowMessage);
      
      // Get available suppliers for this product
      const suppliers = await getAvailableSuppliers(productName);
      
      if (suppliers.length === 0) {
        const noSuppliersMessage = `❌ **No suppliers found** for "${productName}". ` +
          `Please add suppliers for this product in the system.\n\n` +
          `💡 **Tip:** Type "contact suppliers" to retry when suppliers are available.`;
        await addNotificationToChat(chatId, noSuppliersMessage);
        
        // Store the product info for potential retry
        window.pendingSupplierContact = {
          productName: productName,
          currentStock: currentStock,
          chatId: chatId
        };
        setWorkflowStatus(productId, { 
          state: 'awaiting_suppliers', 
          chatId,
          lastStockLevel: currentStock,
          lastNotificationType: 'low-stock'
        });
        return;
      }
      
      // Contact suppliers in priority order
      let orderConfirmed = false;
      let confirmedSupplier = null;
      
      for (const supplier of suppliers) {
        const inquiryResult = await contactSupplierForInquiry(supplier, productName, currentStock, chatId);
        
        if (inquiryResult.success && inquiryResult.hasStock) {
          // Supplier confirmed they have stock
          const confirmationResult = await confirmOrderWithSupplier(supplier, productName, inquiryResult.quantity, inquiryResult.price, chatId);
          
          if (confirmationResult.success) {
            orderConfirmed = true;
            confirmedSupplier = supplier;
            break;
          }
        }
        
        // Add delay between supplier contacts
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
      
      if (orderConfirmed && confirmedSupplier) {
        // Order confirmed, notify user about payment
        await notifyUserAboutPayment(confirmedSupplier, productName, chatId);
        setWorkflowStatus(productId, { 
          state: 'completed', 
          chatId, 
          supplierId: confirmedSupplier.id || confirmedSupplier.name,
          lastStockLevel: currentStock,
          lastNotificationType: 'low-stock'
        });
      } else {
        // No supplier could fulfill the order
        const noStockMessage = `❌ **Unable to restock** "${productName}". ` +
          `None of the contacted suppliers have sufficient stock available. ` +
          `Please try again later or contact suppliers manually.`;
        await addNotificationToChat(chatId, noStockMessage);
        setWorkflowStatus(productId, { 
          state: 'failed', 
          chatId,
          lastStockLevel: currentStock,
          lastNotificationType: 'low-stock'
        });
      }
      
    } catch (error) {
      console.error('Error in supplier communication workflow:', error);
      const errorMessage = `❌ **Error in automated reorder process**: ${error.message}`;
      await addNotificationToChat(chatId, errorMessage);
      try { 
        setWorkflowStatus((notification.product && notification.product.id) || notification.product?.name, { 
          state: 'failed',
          lastStockLevel: notification.product?.quantity,
          lastNotificationType: 'low-stock'
        }); 
      } catch(e){}
    }
  }

  // Get available suppliers for a product
  async function getAvailableSuppliers(productName) {
    try {
      const response = await fetch(`${API_BASE}/suppliers/available?product=${encodeURIComponent(productName)}`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        const suppliers = data.suppliers || [];
        
        // If no suppliers found, return a default supplier for testing
        if (suppliers.length === 0) {
          return [{
            id: 'default-supplier-1',
            name: 'Premium Coffee Supplier',
            email: 'spaacey8@gmail.com',
            phone: '+1234567890',
            priority: 1,
            products: [productName]
          }];
        }
        
        // Ensure all suppliers have email addresses, use substitute if missing
        return suppliers.map(supplier => ({
          ...supplier,
          email: supplier.email || 'spaacey8@gmail.com'
        }));
      } else {
        console.error('Failed to fetch suppliers:', response.status);
        // Return default supplier for testing
        return [{
          id: 'default-supplier-1',
          name: 'Premium Coffee Supplier',
          email: 'spaacey8@gmail.com',
          phone: '+1234567890',
          priority: 1,
          products: [productName]
        }];
      }
    } catch (error) {
      console.error('Error fetching suppliers:', error);
      // Return default supplier for testing
      return [{
        id: 'default-supplier-1',
        name: 'Premium Coffee Supplier',
        email: 'spaacey8@gmail.com',
        phone: '+1234567890',
        priority: 1,
        products: [productName]
      }];
    }
  }

  // Contact supplier for stock inquiry
  async function contactSupplierForInquiry(supplier, productName, currentStock, chatId) {
    try {
      // Generate inquiry message
      const inquiryMessage = `Hello ${supplier.name},\n\n` +
        `We need to restock "${productName}" (current stock: ${currentStock} units). ` +
        `Do you have this product available? Please confirm quantity and price.\n\n` +
        `Thank you,\n` +
        `Automated Inventory System`;
      
      // Generate HTML email content
      const emailSubject = `Stock Inquiry: ${productName} - ${supplier.name}`;
      const emailHTML = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Stock Inquiry Request</h2>
          <p>Hello ${supplier.name},</p>
          <p>We need to restock <strong>"${productName}"</strong> (current stock: ${currentStock} units).</p>
          <p>Do you have this product available? Please confirm quantity and price.</p>
          <div style="background-color: #f5f5f5; padding: 15px; margin: 20px 0; border-radius: 5px;">
            <h3 style="margin-top: 0;">Product Details:</h3>
            <ul>
              <li><strong>Product:</strong> ${productName}</li>
              <li><strong>Current Stock:</strong> ${currentStock} units</li>
              <li><strong>Status:</strong> Low stock - needs restocking</li>
            </ul>
          </div>
          <p>Please respond with:</p>
          <ul>
            <li>Available quantity</li>
            <li>Price per unit</li>
            <li>Estimated delivery time</li>
          </ul>
          <p>Thank you,<br>Automated Inventory System</p>
        </div>
      `;
      
      // Send both SMS and Email to supplier
      const smsResult = await sendSMSToSupplier(supplier.phone, inquiryMessage);
      const emailResult = await sendEmailToSupplier(supplier.email, emailSubject, emailHTML, true);
      
      // Add status message to chat
      const statusMessage = `Contacting ${supplier.name}\n` +
        `SMS sent to: ${supplier.phone} - ${smsResult.success ? 'Success' : 'Failed'}\n` +
        `Email sent to: ${supplier.email} - ${emailResult.success ? 'Success' : 'Failed'}`;
      
      await addNotificationToChat(chatId, statusMessage);
      
      // Simulate supplier response (in real implementation, this would be handled by webhook or polling)
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // For demo purposes, simulate a response based on supplier priority
      const hasStock = Math.random() > 0.3; // 70% chance of having stock
      const quantity = hasStock ? Math.floor(Math.random() * 100) + 50 : 0;
      const price = hasStock ? (Math.random() * 50 + 10).toFixed(2) : 0;
      
      const responseMessage = `Response from ${supplier.name}:\n` +
        `Stock available: ${hasStock ? 'Yes' : 'No'}\n` +
        `Quantity: ${quantity} units\n` +
        `Price per unit: ₱${price}`;
      
      await addNotificationToChat(chatId, responseMessage);
      
      return {
        success: smsResult.success || emailResult.success, // Success if either method worked
        hasStock: hasStock,
        quantity: quantity,
        price: price
      };
      
    } catch (error) {
      console.error('Error contacting supplier:', error);
      return { success: false, hasStock: false };
    }
  }

  // Confirm order with supplier
  async function confirmOrderWithSupplier(supplier, productName, quantity, price, chatId) {
    try {
      const orderMessage = `Thank you for confirming availability. ` +
        `We would like to proceed with ordering ${quantity} units of "${productName}" ` +
        `at ₱${price} per unit (Total: ₱${(quantity * price).toFixed(2)}). ` +
        `Please confirm this order.`;
      
      // Generate HTML email content for order confirmation
      const emailSubject = `Order Confirmation: ${productName} - ${supplier.name}`;
      const emailHTML = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Order Confirmation Request</h2>
          <p>Hello ${supplier.name},</p>
          <p>Thank you for confirming availability. We would like to proceed with the following order:</p>
          <div style="background-color: #f5f5f5; padding: 15px; margin: 20px 0; border-radius: 5px;">
            <h3 style="margin-top: 0;">Order Details:</h3>
            <ul>
              <li><strong>Product:</strong> ${productName}</li>
              <li><strong>Quantity:</strong> ${quantity} units</li>
              <li><strong>Price per unit:</strong> ₱${price}</li>
              <li><strong>Total Amount:</strong> ₱${(quantity * price).toFixed(2)}</li>
            </ul>
          </div>
          <p>Please confirm this order and provide:</p>
          <ul>
            <li>Order confirmation number</li>
            <li>Expected delivery date</li>
            <li>Payment terms</li>
          </ul>
          <p>Thank you,<br>Automated Inventory System</p>
        </div>
      `;
      
      // Send both SMS and Email confirmation
      const smsResult = await sendSMSToSupplier(supplier.phone, orderMessage);
      const emailResult = await sendEmailToSupplier(supplier.email, emailSubject, emailHTML, true);
      
      // Add confirmation message to chat
      const confirmationMessage = `Order Confirmation Sent to ${supplier.name}\n` +
        `Product: ${productName}\n` +
        `Quantity: ${quantity} units\n` +
        `Price per unit: ₱${price}\n` +
        `Total: ₱${(quantity * price).toFixed(2)}\n` +
        `SMS Status: ${smsResult.success ? 'Sent' : 'Failed'}\n` +
        `Email Status: ${emailResult.success ? 'Sent' : 'Failed'}`;
      
      await addNotificationToChat(chatId, confirmationMessage);
      
      // Simulate order confirmation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const orderConfirmed = Math.random() > 0.1; // 90% chance of confirmation
      
      const resultMessage = `Order ${orderConfirmed ? 'CONFIRMED' : 'REJECTED'} by ${supplier.name}`;
      await addNotificationToChat(chatId, resultMessage);
      
      return { success: orderConfirmed };
      
    } catch (error) {
      console.error('Error confirming order:', error);
      return { success: false };
    }
  }

  // Send SMS to supplier
  async function sendSMSToSupplier(phoneNumber, message) {
    try {
      const response = await fetch(`${API_BASE}/notifications/sms`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          phoneNumber: phoneNumber,
          message: message,
          type: 'supplier_inquiry'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return { success: true, messageId: data.messageId };
      } else {
        console.error('Failed to send SMS:', response.status);
        return { success: false };
      }
    } catch (error) {
      console.error('Error sending SMS:', error);
      return { success: false };
    }
  }

  // Send Email to supplier
  async function sendEmailToSupplier(emailAddress, subject, message, isHTML = false) {
    try {
      // Use substitute email for testing if no specific email provided
      const supplierEmail = emailAddress || 'spaacey8@gmail.com';
      
      const response = await fetch(`${API_BASE}/notifications/email`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          to: supplierEmail,
          subject: subject,
          message: message,
          isHTML: isHTML,
          type: 'supplier_inquiry'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return { success: true, messageId: data.messageId };
      } else {
        console.error('Failed to send email:', response.status);
        return { success: false };
      }
    } catch (error) {
      console.error('Error sending email:', error);
      return { success: false };
    }
  }

  // Notify user about payment requirement
  async function notifyUserAboutPayment(supplier, productName, chatId) {
    try {
      // Get user's contact information from the system
      const userPhone = await getUserPhoneNumber();
      const userEmail = await getUserEmailAddress();
      
      if (!userPhone && !userEmail) {
        const noContactMessage = `Payment notification failed: User contact information not found in system.`;
        await addNotificationToChat(chatId, noContactMessage);
        return;
      }
      
      const paymentMessage = `Payment Required: Order confirmed with ${supplier.name} for ${productName}. ` +
        `Please process payment to complete the order. Check your dashboard for details.`;
      
      // Generate HTML email content for payment notification
      const emailSubject = `Payment Required: Order Confirmed - ${productName}`;
      const emailHTML = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Payment Required - Order Confirmed</h2>
          <p>Hello,</p>
          <p>Your order has been confirmed and payment is now required to complete the transaction.</p>
          <div style="background-color: #f5f5f5; padding: 15px; margin: 20px 0; border-radius: 5px;">
            <h3 style="margin-top: 0;">Order Details:</h3>
            <ul>
              <li><strong>Product:</strong> ${productName}</li>
              <li><strong>Supplier:</strong> ${supplier.name}</li>
              <li><strong>Status:</strong> Confirmed - Payment Required</li>
            </ul>
          </div>
          <div style="background-color: #fff3cd; padding: 15px; margin: 20px 0; border-radius: 5px; border-left: 4px solid #ffc107;">
            <p><strong>Action Required:</strong> Please process payment to complete the order. Check your dashboard for payment details and instructions.</p>
          </div>
          <p>Thank you,<br>Automated Inventory System</p>
        </div>
      `;
      
      let smsResult = { success: false };
      let emailResult = { success: false };
      
      // Send SMS to user if phone number is available
      if (userPhone) {
        smsResult = await sendSMSToUser(userPhone, paymentMessage);
      }
      
      // Send Email to user if email address is available
      if (userEmail) {
        emailResult = await sendEmailToUser(userEmail, emailSubject, emailHTML, true);
      }
      
      // Add payment notification to chat
      const chatMessage = `Payment Notification Sent\n` +
        `Order confirmed with: ${supplier.name}\n` +
        `Product: ${productName}\n` +
        `${userPhone ? `SMS sent to: ${userPhone} - ${smsResult.success ? 'Success' : 'Failed'}\n` : ''}` +
        `${userEmail ? `Email sent to: ${userEmail} - ${emailResult.success ? 'Success' : 'Failed'}` : ''}`;
      
      await addNotificationToChat(chatId, chatMessage);
      
    } catch (error) {
      console.error('Error notifying user about payment:', error);
      const errorMessage = `❌ **Payment notification error**: ${error.message}`;
      await addNotificationToChat(chatId, errorMessage);
    }
  }

  // Send SMS to user
  async function sendSMSToUser(phoneNumber, message) {
    try {
      const response = await fetch(`${API_BASE}/notifications/sms`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          phoneNumber: phoneNumber,
          message: message,
          type: 'user_notification'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return { success: true, messageId: data.messageId };
      } else {
        console.error('Failed to send user SMS:', response.status);
        return { success: false };
      }
    } catch (error) {
      console.error('Error sending user SMS:', error);
      return { success: false };
    }
  }

  // Send Email to user
  async function sendEmailToUser(emailAddress, subject, message, isHTML = false) {
    try {
      const response = await fetch(`${API_BASE}/notifications/email`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({
          to: emailAddress,
          subject: subject,
          message: message,
          isHTML: isHTML,
          type: 'user_notification'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return { success: true, messageId: data.messageId };
      } else {
        console.error('Failed to send user email:', response.status);
        return { success: false };
      }
    } catch (error) {
      console.error('Error sending user email:', error);
      return { success: false };
    }
  }

  // Get user's phone number
  async function getUserPhoneNumber() {
    try {
      const response = await fetch(`${API_BASE}/user/profile`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.user.phone;
      } else {
        console.error('Failed to get user profile:', response.status);
        return null;
      }
    } catch (error) {
      console.error('Error getting user phone:', error);
      return null;
    }
  }

  // Get user's email address
  async function getUserEmailAddress() {
    try {
      const response = await fetch(`${API_BASE}/user/profile`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        // Use substitute email for testing instead of admin@company.com
        return data.user.email && data.user.email !== 'admin@company.com' 
          ? data.user.email 
          : 'sheanmendoza5@gmail.com';
      } else {
        console.error('Failed to get user profile:', response.status);
        // Return substitute email as fallback
        return 'sheanmendoza5@gmail.com';
      }
    } catch (error) {
      console.error('Error getting user email:', error);
      // Return substitute email as fallback
      return 'sheanmendoza5@gmail.com';
    }
  }

  // Handle supplier contact retry when user types "contact suppliers"
  async function handleSupplierContactRetry() {
    if (!window.pendingSupplierContact) {
      return "No pending supplier contact requests. This command is used to retry contacting suppliers when none were available initially.";
    }

    const { productName, currentStock, chatId } = window.pendingSupplierContact;
    
    // Add retry message to chat
    const retryMessage = `🔄 **Retrying supplier contact for "${productName}"**\n\n` +
      `Attempting to contact suppliers again...`;
    await addNotificationToChat(chatId, retryMessage);
    
    // Try to get suppliers again
    const suppliers = await getAvailableSuppliers(productName);
    
    if (suppliers.length === 0) {
      const stillNoSuppliersMessage = `❌ **Still no suppliers found** for "${productName}". ` +
        `Please add suppliers for this product in the system before retrying.`;
      await addNotificationToChat(chatId, stillNoSuppliersMessage);
      return "No suppliers are available for this product. Please add suppliers to the system first.";
    }
    
    // Clear the pending contact since we found suppliers
    window.pendingSupplierContact = null;
    
    // Start the supplier communication workflow
    const notification = {
      product: { name: productName, quantity: currentStock },
      type: 'low-stock'
    };
    
    await startSupplierCommunicationWorkflow(notification, chatId);
    
    return `Successfully retried contacting suppliers for "${productName}". Check the chat for updates.`;
  }

  // Clear pending supplier contact
  async function clearPendingSupplierContact() {
    if (!window.pendingSupplierContact) {
      return "No pending supplier contact requests to clear.";
    }

    const { productName } = window.pendingSupplierContact;
    window.pendingSupplierContact = null;
    
    return `Cleared pending supplier contact request for "${productName}". You can retry later by typing "contact suppliers".`;
  }

  // Get supplier contact status
  async function getSupplierContactStatus() {
    if (!window.pendingSupplierContact) {
      return "No pending supplier contact requests. All supplier communications are up to date.";
    }

    const { productName, currentStock } = window.pendingSupplierContact;
    
    return `📋 **Pending Supplier Contact**\n\n` +
      `Product: ${productName}\n` +
      `Current Stock: ${currentStock} units\n` +
      `Status: Waiting for suppliers to be added to system\n\n` +
      `💡 **Available Commands:**\n` +
      `• Type "contact suppliers" to retry\n` +
      `• Type "clear supplier contact" to cancel`;
  }

  // --- Sidebar toggle functionality ---
  function toggleSidebar() {
    if (window.innerWidth <= 768) {
      isMobileSidebarOpen = !isMobileSidebarOpen;
      sidebar.classList.toggle('open', isMobileSidebarOpen);
      overlay.classList.toggle('show', isMobileSidebarOpen);
      document.body.style.overflow = isMobileSidebarOpen ? 'hidden' : '';
    } else {
      isSidebarCollapsed = !isSidebarCollapsed;
      sidebar.classList.toggle('collapsed', isSidebarCollapsed);
      chatContainer.classList.toggle('sidebar-collapsed', isSidebarCollapsed);
      localStorage.setItem('sidebarCollapsed', isSidebarCollapsed);
    }
  }

  // --- Close sidebar when overlay is clicked (mobile) ---
  if (overlay) {
    overlay.addEventListener('click', function() {
      closeMobileSidebar();
    });
  }

  function closeMobileSidebar() {
    isMobileSidebarOpen = false;
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
    document.body.style.overflow = '';
  }

  // --- Sidebar toggle event listeners ---
  if (sidebarToggle) sidebarToggle.addEventListener('click', toggleSidebar);
  if (mobileToggle) mobileToggle.addEventListener('click', toggleSidebar);

  // --- New Chat Button (expanded) ---
  if (newChatBtn) newChatBtn.addEventListener('click', startNewChat);

  // --- New Chat Button (collapsed) ---
  if (collapsedNewChatBtn) collapsedNewChatBtn.addEventListener('click', startNewChat);

  // --- Chat form submission ---
  if (chatForm) {
    chatForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const message = chatInput.value.trim();
      if (message) {
        sendMessage(message);
        chatInput.value = '';
        resetInputHeight();
      }
    });
  }

  // --- Auto-resize textarea ---
  if (chatInput) {
    chatInput.addEventListener('input', function() {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
  }

  // --- Handle Enter key for sending ---
  if (chatInput) {
    chatInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (chatForm) chatForm.dispatchEvent(new Event('submit'));
      }
    });
  }

  // --- Window resize handling ---
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
      sidebar.classList.remove('open');
      overlay.classList.remove('show');
      isMobileSidebarOpen = false;
      sidebar.classList.toggle('collapsed', isSidebarCollapsed);
      chatContainer.classList.toggle('sidebar-collapsed', isSidebarCollapsed);
      document.body.style.overflow = '';
    } else {
      sidebar.classList.remove('collapsed');
      chatContainer.classList.remove('sidebar-collapsed');
    }
  });

  // --- Keyboard shortcuts ---
  document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
      e.preventDefault();
      startNewChat();
    }
    if ((e.ctrlKey || e.metaKey) && e.key === '/' && window.innerWidth > 768) {
      e.preventDefault();
      toggleSidebar();
    }
    if (e.key === 'Escape') {
      if (window.innerWidth <= 768) {
        closeMobileSidebar();
      } else {
        // Close delete modal if open
        const deleteModal = document.getElementById('deleteModal');
        if (deleteModal && deleteModal.style.display === 'flex') {
          deleteModal.style.display = 'none';
          window.pendingDeleteData = null;
        }
      }
    }
  });

  // --- Delete Modal Event Listeners ---
  const deleteModal = document.getElementById('deleteModal');
  const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
  const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');

  // Cancel delete
  if (cancelDeleteBtn) {
    cancelDeleteBtn.addEventListener('click', function() {
      deleteModal.style.display = 'none';
      window.pendingDeleteData = null;
      window.pendingBulkDeleteData = null;
    });
  }

  // Confirm delete
  if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener('click', async function() {
      deleteModal.style.display = 'none';
      
      // Check if this is a bulk delete or single delete
      if (window.pendingBulkDeleteData) {
        await executeBulkDelete();
      } else {
        await executeDelete();
      }
    });
  }

  // Close modal when clicking on overlay
  if (deleteModal) {
    deleteModal.addEventListener('click', function(e) {
      if (e.target === deleteModal) {
        deleteModal.style.display = 'none';
        window.pendingDeleteData = null;
        window.pendingBulkDeleteData = null;
      }
    });
  }

  // --- Send message logic ---
  async function sendMessage(message) {
    // If no current chat session, create one now (when user actually sends a message)
    if (!currentChatId) {
      const newSession = await createNewSession('New Chat');
      if (!newSession) {
        console.error('Failed to create new chat session');
        return;
      }
      currentChatId = newSession.id;
      await updateChatHistoryDisplay();
    }
    
    if (welcomeMessage) welcomeMessage.style.display = 'none';
    if (chatMessages) chatMessages.style.display = 'block';
    await addMessage('user', message, true);

    // Check if message is inventory-related and provide appropriate response
    await handleAIResponse(message);
  }

  // Handle AI responses including inventory queries
  async function handleAIResponse(userMessage) {
    // Simulate AI typing indicator
    showTypingIndicator();
    
    setTimeout(async () => {
      hideTypingIndicator();
      
      const message = userMessage.toLowerCase();
      let aiResponse = '';
      
      // Analyze the specific question and provide targeted responses
      if ((message.includes('no stock') || message.includes('out of stock') || message.includes('no stocks'))) {
        aiResponse = await getOutOfStockProducts();
      }
      else if ((message.includes('how many') || message.includes('count')) && (message.includes('no stock') || message.includes('out of stock'))) {
        const products = await inventoryNotificationService.fetchInventoryData();
        const outOfStockItems = products.filter(p => (Number(p.quantity) || 0) === 0);
        aiResponse = `There ${outOfStockItems.length === 1 ? 'is' : 'are'} ${outOfStockItems.length} product${outOfStockItems.length === 1 ? '' : 's'} out of stock.`;
      }
      else if (message.includes('what products') && message.includes('in stock')) {
        aiResponse = await getInStockProducts();
      }
      else if (message.includes('what products') || message.includes('which products') || message.includes('list products')) {
        aiResponse = await getAllProductsList();
      }
      else if (message.includes('current stock') || message.includes('our stock')) {
        aiResponse = await getInventoryStatusResponse();
      }
      else if (message.includes('out of stock') || message.includes('empty') || message.includes('sold out')) {
        aiResponse = await getOutOfStockProducts();
      }
      else if ((message.includes('low') && message.includes('stock')) || message.includes('low stock')) {
        aiResponse = await getLowStockProducts();
      }
      else if (message.includes('how much') || message.includes('how many')) {
        aiResponse = await getQuantityInfo(userMessage);
      }
      else if (message.includes('inventory status') || message.includes('inventory overview') || 
               (message.includes('current') && message.includes('inventory'))) {
        aiResponse = await getInventoryStatusResponse();
      }
      else if (message.includes('total') && (message.includes('units') || message.includes('quantity'))) {
        aiResponse = await getTotalUnits();
      }
      else if (message.includes('contact suppliers') || message.includes('retry suppliers') || message.includes('try suppliers again') || message.includes('retry supplier contact')) {
        aiResponse = await handleSupplierContactRetry();
      }
      else if (message.includes('clear supplier contact') || message.includes('cancel supplier contact')) {
        aiResponse = await clearPendingSupplierContact();
      }
      else if (message.includes('supplier status') || message.includes('pending suppliers')) {
        aiResponse = await getSupplierContactStatus();
      }
      else if (message.includes('business') || message.includes('coffee shop') || message.includes('operations')) {
        aiResponse = "I can help you with various aspects of your coffee business including inventory management, stock monitoring, and product information. What specific area would you like to know about?";
      }
      else if (message.includes('hello') || message.includes('hi') || message.includes('help')) {
        aiResponse = "Hello! I'm here to assist you with your coffee business. I can help you check inventory levels, monitor stock, and provide information about your products. What would you like to know?";
      }
      else {
        // Check for specific product queries (dynamic detection)
        const productInfo = await checkForProductQuery(userMessage);
        if (productInfo) {
          aiResponse = productInfo;
        } else {
          aiResponse = "I'd be happy to help! I can provide information about your inventory, stock levels, specific products, or other business operations. Could you please be more specific about what you'd like to know?";
        }
      }
      
      await addMessage('ai', aiResponse, true);
    }, 1000 + Math.random() * 1000);
  }

  // Get inventory status for AI response
  async function getInventoryStatusResponse() {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now. Please try again later.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      
      if (products.length === 0) {
        return "I couldn't find any products in the inventory system. Please make sure the inventory is properly set up.";
      }

      const totalProducts = products.length;
      const lowStockItems = products.filter(p => {
        const qty = Number(p.quantity) || 0;
        return qty > 0 && qty <= 10;
      });
      const outOfStockItems = products.filter(p => (Number(p.quantity) || 0) === 0);
      const inStockItems = products.filter(p => (Number(p.quantity) || 0) > 10);

      let response = `Here's the current inventory status:\n\n`;
      response += `Total Products: ${totalProducts}\n`;
      response += `In Stock (>10 units): ${inStockItems.length}\n`;
      response += `Low Stock (1-10 units): ${lowStockItems.length}\n`;
      response += `Out of Stock: ${outOfStockItems.length}\n\n`;

      if (outOfStockItems.length > 0) {
        response += `Products Out of Stock:\n`;
        outOfStockItems.slice(0, 5).forEach(product => {
          response += `• ${product.name} - ₱${Number(product.price || 0).toLocaleString()}\n`;
        });
        if (outOfStockItems.length > 5) {
          response += `... and ${outOfStockItems.length - 5} more\n`;
        }
        response += `\n`;
      }

      if (lowStockItems.length > 0) {
        response += `Products Low on Stock:\n`;
        lowStockItems.slice(0, 5).forEach(product => {
          response += `• ${product.name} - ${product.quantity} units - ₱${Number(product.price || 0).toLocaleString()}\n`;
        });
        if (lowStockItems.length > 5) {
          response += `... and ${lowStockItems.length - 5} more\n`;
        }
      }

      if (outOfStockItems.length === 0 && lowStockItems.length === 0) {
        response += `Good news! All products are well-stocked.`;
      }

      return response;
    } catch (error) {
      console.error('Error getting inventory status:', error);
      return "I'm having trouble accessing the inventory data right now. Please try again in a moment.";
    }
  }

  // Generate generic AI responses
  function generateGenericResponse(message) {
    const responses = [
      "That's interesting! How can I help you with your coffee business today?",
      "I understand. Is there anything specific about your coffee shop operations you'd like to know?",
      "Great question! I'm here to assist you with your business needs.",
      "I see. Would you like me to check on anything related to your inventory or sales?",
      "Thanks for sharing that with me. What would you like to know about your coffee shop?",
      "I'm here to help! Feel free to ask about inventory, sales, or anything else related to your business.",
      "That makes sense. Is there anything I can help you with regarding your coffee shop management?"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  }

  // Check if user message contains any product names from database
  async function checkForProductQuery(userMessage) {
    if (!inventoryNotificationService) {
      return null;
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      const message = userMessage.toLowerCase();
      
      // Find products that match any part of the user's message
      const matchingProducts = products.filter(product => {
        const productName = product.name.toLowerCase();
        // Check if the product name or parts of it are mentioned in the message
        const productWords = productName.split(' ');
        return productWords.some(word => word.length > 2 && message.includes(word)) ||
               message.includes(productName);
      });
      
      if (matchingProducts.length === 0) {
        return null; // No products found in the query
      }
      
      let response = "Here's what I found:\n\n";
      matchingProducts.forEach(product => {
        const qty = Number(product.quantity) || 0;
        const status = qty === 0 ? "Out of Stock" : qty <= 10 ? "Low Stock" : "In Stock";
        response += `• ${product.name}\n`;
        response += `  - Quantity: ${qty} units\n`;
        response += `  - Price: ₱${Number(product.price || 0).toLocaleString()}\n`;
        response += `  - Status: ${status}\n\n`;
      });
      
      return response;
    } catch (error) {
      console.error('Error checking for product query:', error);
      return null;
    }
  }

  // Get specific product information (updated to work with dynamic detection)
  async function getSpecificProductInfo(userMessage) {
    return await checkForProductQuery(userMessage);
  }

  // Get low stock products
  async function getLowStockProducts() {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      const lowStockItems = products.filter(p => {
        const qty = Number(p.quantity) || 0;
        return qty > 0 && qty <= 10;
      });

      if (lowStockItems.length === 0) {
        return "Great news! No products are currently low on stock.";
      }

      let response = `Found ${lowStockItems.length} products with low stock:\n\n`;
      lowStockItems.forEach((product, index) => {
        response += `${index + 1}. ${product.name} - ${product.quantity} units - ₱${Number(product.price || 0).toLocaleString()}\n`;
      });
      
      return response;
    } catch (error) {
      console.error('Error getting low stock products:', error);
      return "I'm having trouble accessing the low stock information right now.";
    }
  }

  // Get quantity information for specific queries
  async function getQuantityInfo(userMessage) {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      const message = userMessage.toLowerCase();
      
      // First check if asking about a specific product using dynamic detection
      const matchingProducts = products.filter(product => {
        const productName = product.name.toLowerCase();
        const productWords = productName.split(' ');
        return productWords.some(word => word.length > 2 && message.includes(word)) ||
               message.includes(productName);
      });
      
      if (matchingProducts.length > 0) {
        let response = "Here are the quantities:\n\n";
        matchingProducts.forEach(product => {
          response += `• ${product.name}: ${product.quantity} units\n`;
        });
        return response;
      }
      
      // If no specific product, show total units
      const totalUnits = products.reduce((sum, product) => sum + (Number(product.quantity) || 0), 0);
      return `We currently have a total of ${totalUnits} units across all products in our inventory.`;
      
    } catch (error) {
      console.error('Error getting quantity info:', error);
      return "I'm having trouble accessing the quantity information right now.";
    }
  }

  // Get all products list
  async function getAllProductsList() {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      
      if (products.length === 0) {
        return "We don't have any products in the inventory system.";
      }

      let response = `We have ${products.length} products in our inventory:\n\n`;
      products.forEach((product, index) => {
        const qty = Number(product.quantity) || 0;
        const status = qty === 0 ? "Out of Stock" : qty <= 10 ? "Low Stock" : "In Stock";
        response += `${index + 1}. ${product.name} - ${qty} units (${status})\n`;
      });
      
      return response;
    } catch (error) {
      console.error('Error getting products list:', error);
      return "I'm having trouble accessing the products list right now.";
    }
  }

  // Get products that are in stock (>10 units)
  async function getInStockProducts() {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      const inStockItems = products.filter(p => (Number(p.quantity) || 0) > 10);

      if (inStockItems.length === 0) {
        return "We don't have any products that are well-stocked (>10 units) right now.";
      }

      let response = `Products in stock (>10 units):\n\n`;
      inStockItems.forEach((product, index) => {
        response += `${index + 1}. ${product.name} - ${product.quantity} units\n`;
      });
      
      return response;
    } catch (error) {
      console.error('Error getting in stock products:', error);
      return "I'm having trouble accessing the stock information right now.";
    }
  }

  // Get total units across all products
  async function getTotalUnits() {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      const totalUnits = products.reduce((sum, product) => sum + (Number(product.quantity) || 0), 0);
      
      return `We currently have a total of ${totalUnits} units across all products in our inventory.`;
    } catch (error) {
      console.error('Error getting total units:', error);
      return "I'm having trouble accessing the inventory information right now.";
    }
  }

  // Get out of stock products
  async function getOutOfStockProducts() {
    if (!inventoryNotificationService) {
      return "I'm sorry, I can't access the inventory system right now.";
    }

    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      const outOfStockItems = products.filter(p => (Number(p.quantity) || 0) === 0);

      if (outOfStockItems.length === 0) {
        return "Good news! No products are currently out of stock.";
      }

      let response = `Found ${outOfStockItems.length} products that are out of stock:\n\n`;
      outOfStockItems.forEach((product, index) => {
        response += `${index + 1}. ${product.name} - ₱${Number(product.price || 0).toLocaleString()}\n`;
      });
      
      return response;
    } catch (error) {
      console.error('Error getting out of stock products:', error);
      return "I'm having trouble accessing the stock information right now.";
    }
  }

  // --- Update chat layout based on message presence ---
  function updateChatLayout() {
    const chatContent = document.querySelector('.chat-content');
    const hasMessages = chatMessages.children.length > 0;
    
    if (chatContent) {
      if (hasMessages) {
        chatContent.classList.add('has-messages');
      } else {
        chatContent.classList.remove('has-messages');
      }
    }
  }

  // --- Add message to chat and persist ---
  async function addMessage(sender, text, save = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    
    // Format the message to preserve line breaks
    const formattedText = text.replace(/\n/g, '<br>');
    bubble.innerHTML = formattedText;
    
    messageDiv.appendChild(bubble);
    chatMessages.appendChild(messageDiv);

    // Update layout based on whether messages are present
    updateChatLayout();

    // Scroll to bottom of chat content
    const chatContent = document.querySelector('.chat-content');
    if (chatContent) chatContent.scrollTop = chatContent.scrollHeight;

    // Store message locally for immediate display
    const messageObj = { sender, text, timestamp: new Date() };
    messages.push(messageObj);

    // Save to database if needed
    if (save) {
      const messageType = sender === 'user' ? 'user' : 'ai';
      await saveMessageToDB(text, messageType);
    }
  }

  // --- Typing indicator ---
  function showTypingIndicator() {
    if (isTyping) return;
    isTyping = true;
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message ai typing-indicator';
    typingDiv.id = 'typing-indicator';
    const typingBubble = document.createElement('div');
    typingBubble.className = 'message-bubble';
    typingBubble.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
    typingDiv.appendChild(typingBubble);
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function hideTypingIndicator() {
    isTyping = false;
    const typingIndicator = document.getElementById('typing-indicator');
    if (typingIndicator) typingIndicator.remove();
  }

  // --- Start new chat ---
  async function startNewChat() {
    // Create a new session in the database
    const newSession = await createNewSession('New Chat');
    if (!newSession) {
      console.error('Failed to create new chat session');
      return;
    }
    
    currentChatId = newSession.id;
    messages = [];
    
    if (chatMessages) {
      chatMessages.innerHTML = '';
      chatMessages.style.display = 'none';
    }
    if (welcomeMessage) welcomeMessage.style.display = 'block';
    
    // Update layout
    updateChatLayout();
    
    // Update history display
    await updateChatHistoryDisplay();
    
    // Clear and focus input
    if (chatInput) chatInput.value = '';
    resetInputHeight();
    chatInput?.focus();
    closeMobileSidebar();
  }

  // --- Load chat from history ---
  async function loadChat(sessionId) {
    if (currentChatId === sessionId) return; // Already loaded
    
    currentChatId = sessionId;
    messages = [];
    
    // Load messages for this session
    const sessionMessages = await loadSessionMessages(sessionId);
    
    chatMessages.innerHTML = '';
    if (sessionMessages.length > 0) {
      welcomeMessage.style.display = 'none';
      chatMessages.style.display = 'block';
      
      // Display each message
      for (const dbMsg of sessionMessages) {
        const sender = dbMsg.message_type === 'user' ? 'user' : 'ai';
        await addMessage(sender, dbMsg.message, false); // false = don't save to DB again
      }
      
      setTimeout(() => { 
        const chatContent = document.querySelector('.chat-content');
        if (chatContent) chatContent.scrollTop = chatContent.scrollHeight; 
      }, 100);
    } else {
      welcomeMessage.style.display = 'block';
      chatMessages.style.display = 'none';
    }
    
    // Update layout
    updateChatLayout();
    
    // Update active state in sidebar
    document.querySelectorAll('.history-item').forEach(item => {
      item.classList.toggle('active', item.dataset.chatId == sessionId);
    });
    
    closeMobileSidebar();
  }

  // --- Save chat to history ---
  function saveChatToHistory() {
    if (!currentChatId || messages.length === 0) return;
    const existingChatIndex = chatHistory.findIndex(chat => chat.id === currentChatId);
    const chatData = {
      id: currentChatId,
      title: generateChatTitle(messages[0]?.text || 'New Chat'),
      messages: [...messages],
      timestamp: Date.now(),
      date: new Date().toDateString()
    };
    if (existingChatIndex >= 0) {
      chatHistory[existingChatIndex] = chatData;
    } else {
      chatHistory.unshift(chatData);
    }
    if (chatHistory.length > 50) chatHistory = chatHistory.slice(0, 50);
    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    updateChatHistoryDisplay();
  }

  // --- Generate chat title from first message ---
  function generateChatTitle(firstMessage) {
    if (!firstMessage) return 'New Chat';
    const title = firstMessage.trim();
    return title.length > 30 ? title.substring(0, 30) + '...' : title;
  }

  // --- Update chat history display ---
  // Update chat history display with database sessions
  async function updateChatHistoryDisplay() {
    const historyList = document.querySelector('.history-list');
    if (!historyList) return;
    
    // Load sessions from database
    chatHistory = await loadChatSessions();
    
    historyList.innerHTML = '';
    
    if (chatHistory.length === 0) {
      const newChatItem = document.createElement('div');
      newChatItem.className = 'history-item new-chat-item';
      newChatItem.textContent = 'Start your first chat!';
      newChatItem.style.fontStyle = 'italic';
      newChatItem.style.opacity = '0.7';
      historyList.appendChild(newChatItem);
    } else {
      const groupedChats = groupChatsByDate(chatHistory);
      Object.keys(groupedChats).forEach(dateGroup => {
        if (Object.keys(groupedChats).length > 1) {
          const dateHeader = document.createElement('div');
          dateHeader.className = 'history-date-header';
          
          // Create date text
          const dateText = document.createElement('span');
          dateText.textContent = dateGroup;
          dateText.className = 'date-text';
          
          // Create select all button
          const selectAllBtn = document.createElement('button');
          selectAllBtn.className = 'date-select-all-btn';
          selectAllBtn.innerHTML = 'Select All';
          selectAllBtn.title = `Select all chats from ${dateGroup}`;
          selectAllBtn.setAttribute('data-date-group', dateGroup);
          
          dateHeader.appendChild(dateText);
          dateHeader.appendChild(selectAllBtn);
          historyList.appendChild(dateHeader);
        }
        groupedChats[dateGroup].forEach(session => {
          const historyItem = document.createElement('div');
          historyItem.className = 'history-item';
          historyItem.setAttribute('data-chat-id', session.id);
          if (session.id === currentChatId) historyItem.classList.add('active');
          
          // Create text element
          const textElement = document.createElement('div');
          textElement.className = 'history-item-text';
          textElement.textContent = session.title;
          
          // Create options element
          const optionsElement = document.createElement('div');
          optionsElement.className = 'history-item-options';
          optionsElement.innerHTML = '⋮';
          optionsElement.title = 'Chat options';
          
          // Create options menu
          const optionsMenu = document.createElement('div');
          optionsMenu.className = 'options-menu';
          optionsMenu.innerHTML = `<div class="options-menu-item rename" data-action="rename"><span>✏️</span> Rename</div><div class="options-menu-item delete" data-action="delete"><span>🗑️</span> Delete</div>`;
          
          optionsElement.appendChild(optionsMenu);
          
          historyItem.appendChild(textElement);
          historyItem.appendChild(optionsElement);
          
          historyList.appendChild(historyItem);
        });
      });
    }
    
    // Update historyItems NodeList for new elements
    historyItems = document.querySelectorAll('.history-item');
    
    // Add event listeners for history items and options
    setupHistoryEventListeners();
  }

  // Setup event listeners for history items and options
  function setupHistoryEventListeners() {
    const historyList = document.querySelector('.history-list');
    if (!historyList) return;

    // Remove existing listener to prevent duplicates
    historyList.removeEventListener('click', handleHistoryClick);
    
    // Add the click handler
    historyList.addEventListener('click', handleHistoryClick);
    
    // Add event listeners for date group select all buttons
    historyList.addEventListener('click', handleDateGroupClick);

    // Close options menus when clicking outside (only add once)
    if (!document.hasHistoryClickListener) {
      document.addEventListener('click', function(e) {
        if (!e.target.closest('.history-item-options') && !e.target.closest('.options-menu')) {
          document.querySelectorAll('.options-menu.show').forEach(menu => {
            menu.classList.remove('show');
            // Also remove menu-open class from the options button and history item
            const parentItem = menu.closest('.history-item');
            if (parentItem) {
              const optionsBtn = parentItem.querySelector('.history-item-options');
              if (optionsBtn) {
                optionsBtn.classList.remove('menu-open');
              }
              parentItem.classList.remove('menu-open');
            }
          });
        }
      });
      document.hasHistoryClickListener = true;
    }
  }

  // Separate click handler function
  async function handleHistoryClick(e) {
    const historyItem = e.target.closest('.history-item');
    const optionsButton = e.target.closest('.history-item-options');
    const optionsMenu = e.target.closest('.options-menu');
    const menuItem = e.target.closest('.options-menu-item');
    
    if (menuItem && optionsMenu) {
      // Handle menu item clicks
      e.stopPropagation();
      const action = menuItem.getAttribute('data-action');
      const sessionId = historyItem.getAttribute('data-chat-id');
      
      // Hide the menu
      optionsMenu.classList.remove('show');
      // Remove menu-open class from the options button and history item
      const optionsButton = historyItem.querySelector('.history-item-options');
      if (optionsButton) {
        optionsButton.classList.remove('menu-open');
      }
      historyItem.classList.remove('menu-open');
      
      if (action === 'rename') {
        await handleRenameChat(sessionId, historyItem);
      } else if (action === 'delete') {
        await handleDeleteChat(sessionId, historyItem);
      }
      
    } else if (optionsButton) {
      // Handle options button click
      e.stopPropagation();
      const menu = optionsButton.querySelector('.options-menu');
      const isVisible = menu.classList.contains('show');
      
      // Hide all other open menus
      document.querySelectorAll('.options-menu.show').forEach(m => {
        m.classList.remove('show');
        // Also remove menu-open class from all options buttons and history items
        const parentItem = m.closest('.history-item');
        if (parentItem) {
          const optionsBtn = parentItem.querySelector('.history-item-options');
          if (optionsBtn) {
            optionsBtn.classList.remove('menu-open');
          }
          parentItem.classList.remove('menu-open');
        }
      });
      
      if (!isVisible) {
        // Position the menu using fixed positioning
        const rect = optionsButton.getBoundingClientRect();
        menu.style.left = `${rect.left - 120 + rect.width}px`; // Align right edge
        menu.style.top = `${rect.bottom + 8}px`; // Increased gap for better hover detection
        menu.classList.add('show');
        // Add menu-open class to keep options button visible and disable history item hover
        optionsButton.classList.add('menu-open');
        historyItem.classList.add('menu-open');
      }
      
    } else if (historyItem && !optionsMenu) {
      // Handle history item click (load chat)
      if (historyItem.classList.contains('new-chat-item')) {
        startNewChat();
      } else {
        const chatId = historyItem.getAttribute('data-chat-id');
        if (chatId) {
          // Update active state
          document.querySelectorAll('.history-item').forEach(i => i.classList.remove('active'));
          historyItem.classList.add('active');
          
          // Load the chat
          await loadChat(chatId);
          
          // Close mobile sidebar
          closeMobileSidebar();
        }
      }
    }
  }

  // Handle rename chat
  async function handleRenameChat(sessionId, historyItem) {
    const textElement = historyItem.querySelector('.history-item-text');
    const currentTitle = textElement.textContent;
    
    // Create input element
    const inputElement = document.createElement('input');
    inputElement.type = 'text';
    inputElement.className = 'history-item-input';
    inputElement.value = currentTitle;
    
    // Replace text with input
    historyItem.insertBefore(inputElement, textElement);
    textElement.style.display = 'none';
    
    // Focus and select the text
    inputElement.focus();
    inputElement.select();
    
    // Function to save changes
    const saveChanges = async () => {
      const newTitle = inputElement.value.trim();
      if (newTitle && newTitle !== currentTitle) {
        const success = await renameSession(sessionId, newTitle);
        if (success) {
          textElement.textContent = newTitle;
          // Update the current chat title if this is the active chat
          if (sessionId == currentChatId) {
            console.log('Chat renamed successfully');
          }
        } else {
          // Revert on failure
          inputElement.value = currentTitle;
          alert('Failed to rename chat. Please try again.');
          return; // Don't finish editing on failure
        }
      }
      finishEditing();
    };
    
    // Function to cancel changes
    const cancelChanges = () => {
      finishEditing();
    };
    
    // Function to finish editing
    const finishEditing = () => {
      if (inputElement.parentNode) {
        historyItem.removeChild(inputElement);
      }
      textElement.style.display = '';
    };
    
    // Handle Enter key to save
    inputElement.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        saveChanges();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        cancelChanges();
      }
    });
    
    // Handle blur to save
    inputElement.addEventListener('blur', () => {
      saveChanges();
    });
  }

  // Handle delete chat
  async function handleDeleteChat(sessionId, historyItem) {
    const textElement = historyItem.querySelector('.history-item-text');
    const chatTitle = textElement.textContent;
    
    // Store the session data for modal confirmation
    window.pendingDeleteData = { sessionId, historyItem, chatTitle };
    
    // Update modal content with chat title
    const modalBody = document.querySelector('.delete-modal-body p');
    modalBody.textContent = `Are you sure you want to delete "${chatTitle}"? This action cannot be undone.`;
    
    // Show the modal
    const deleteModal = document.getElementById('deleteModal');
    deleteModal.style.display = 'flex';
  }

  // Execute the actual deletion after confirmation
  async function executeDelete() {
    const { sessionId, historyItem } = window.pendingDeleteData;
    
    const success = await deleteSession(sessionId);
    if (success) {
      // Remove from UI immediately
      historyItem.remove();
      
      // If this was the current chat, start a new one
      if (sessionId == currentChatId) {
        currentChatId = null;
        if (welcomeMessage) welcomeMessage.style.display = 'block';
        if (chatMessages) {
          chatMessages.innerHTML = '';
          chatMessages.style.display = 'none';
        }
        messages = [];
        
        // Update layout
        updateChatLayout();
      }
      
      // Check if there are any chats left, if not show the "start first chat" message
      const remainingChats = document.querySelectorAll('.history-item[data-chat-id]');
      if (remainingChats.length === 0) {
        const historyList = document.querySelector('.history-list');
        const newChatItem = document.createElement('div');
        newChatItem.className = 'history-item new-chat-item';
        newChatItem.textContent = 'Start your first chat!';
        newChatItem.style.fontStyle = 'italic';
        newChatItem.style.opacity = '0.7';
        historyList.appendChild(newChatItem);
      }
    } else {
      alert('Failed to delete chat. Please try again.');
    }
    
    // Clean up
    window.pendingDeleteData = null;
  }

  // --- Group chats by date ---
  function groupChatsByDate(sessions) {
    const groups = {};
    const today = new Date().toDateString();
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    
    sessions.forEach(session => {
      const sessionDate = new Date(session.updated_at || session.created_at).toDateString();
      let groupName;
      if (sessionDate === today) groupName = 'Today';
      else if (sessionDate === yesterday) groupName = 'Yesterday';
      else groupName = formatDate(new Date(sessionDate));
      if (!groups[groupName]) groups[groupName] = [];
      groups[groupName].push(session);
    });
    return groups;
  }

  // --- Handle date group select all clicks ---
  function handleDateGroupClick(e) {
    const selectAllBtn = e.target.closest('.date-select-all-btn');
    if (!selectAllBtn) return;
    
    e.stopPropagation();
    const dateGroup = selectAllBtn.getAttribute('data-date-group');
    selectAllChatsInDateGroup(dateGroup);
  }

  // --- Select all chats in a date group ---
  function selectAllChatsInDateGroup(dateGroup) {
    const historyList = document.querySelector('.history-list');
    if (!historyList) return;
    
    // Find all chat items in this date group
    const dateHeader = historyList.querySelector(`[data-date-group="${dateGroup}"]`).parentElement;
    const chatItems = [];
    let currentElement = dateHeader.nextElementSibling;
    
    // Collect all chat items until we hit another date header or end of list
    while (currentElement && !currentElement.classList.contains('history-date-header')) {
      if (currentElement.classList.contains('history-item') && currentElement.getAttribute('data-chat-id')) {
        chatItems.push(currentElement);
      }
      currentElement = currentElement.nextElementSibling;
    }
    
    if (chatItems.length === 0) return;
    
    // Show bulk action controls
    showBulkActionControls(dateGroup, chatItems);
  }

  // --- Show bulk action controls ---
  function showBulkActionControls(dateGroup, chatItems) {
    // Remove any existing bulk controls
    hideBulkActionControls();
    
    // Create bulk action container
    const bulkContainer = document.createElement('div');
    bulkContainer.className = 'bulk-action-container';
    bulkContainer.setAttribute('data-date-group', dateGroup);
    
    // Create selected count
    const selectedCount = document.createElement('span');
    selectedCount.className = 'selected-count';
    selectedCount.textContent = `${chatItems.length} selected`;
    
    // Create action buttons
    const actionsContainer = document.createElement('div');
    actionsContainer.className = 'bulk-actions';
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'bulk-delete-btn';
    deleteBtn.innerHTML = '🗑️ Delete All';
    deleteBtn.title = 'Delete all selected chats';
    
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'bulk-cancel-btn';
    cancelBtn.innerHTML = '✕ Cancel';
    cancelBtn.title = 'Cancel selection';
    
    actionsContainer.appendChild(deleteBtn);
    actionsContainer.appendChild(cancelBtn);
    
    bulkContainer.appendChild(selectedCount);
    bulkContainer.appendChild(actionsContainer);
    
    // Insert after the date header
    const dateHeader = document.querySelector(`[data-date-group="${dateGroup}"]`).parentElement;
    dateHeader.insertAdjacentElement('afterend', bulkContainer);
    
    // Add event listeners
    deleteBtn.addEventListener('click', () => handleBulkDelete(dateGroup, chatItems));
    cancelBtn.addEventListener('click', hideBulkActionControls);
    
    // Highlight selected items
    chatItems.forEach(item => {
      item.classList.add('bulk-selected');
    });
  }

  // --- Hide bulk action controls ---
  function hideBulkActionControls() {
    const existingBulk = document.querySelector('.bulk-action-container');
    if (existingBulk) {
      existingBulk.remove();
    }
    
    // Remove selection highlighting
    document.querySelectorAll('.bulk-selected').forEach(item => {
      item.classList.remove('bulk-selected');
    });
  }

  // --- Handle bulk delete ---
  async function handleBulkDelete(dateGroup, chatItems) {
    const chatTitles = chatItems.map(item => {
      const textElement = item.querySelector('.history-item-text');
      return textElement ? textElement.textContent : 'Unknown Chat';
    });
    
    // Store the bulk delete data
    window.pendingBulkDeleteData = { dateGroup, chatItems, chatTitles };
    
    // Update modal content
    const modalBody = document.querySelector('.delete-modal-body p');
    const count = chatItems.length;
    modalBody.textContent = `Are you sure you want to delete ${count} chat${count > 1 ? 's' : ''} from ${dateGroup}? This action cannot be undone.`;
    
    // Show the modal
    const deleteModal = document.getElementById('deleteModal');
    deleteModal.style.display = 'flex';
  }

  // --- Execute bulk delete ---
  async function executeBulkDelete() {
    const { dateGroup, chatItems } = window.pendingBulkDeleteData;
    
    try {
      // Check authentication first
      const token = getAuthToken();
      if (!token) {
        alert('You are not logged in. Please refresh the page and log in again.');
        return;
      }
      
      const sessionIds = chatItems.map(item => {
        const id = item.getAttribute('data-chat-id');
        console.log('Extracted session ID:', id, 'from element:', item);
        return id;
      }).filter(id => id); // Remove any null/undefined IDs
      
      console.log('Attempting bulk delete:', { 
        dateGroup, 
        sessionIds, 
        count: sessionIds.length,
        hasAuthToken: !!token,
        chatItemsCount: chatItems.length
      });
      
      // Call bulk delete API
      console.log('Making bulk delete request to:', `${API_BASE}/chat/sessions/bulk`);
      console.log('Request headers:', getAuthHeaders());
      console.log('Request body:', { sessionIds });
      
      const response = await fetch(`${API_BASE}/chat/sessions/bulk`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify({ sessionIds })
      });
      
      console.log('Bulk delete response:', { 
        status: response.status, 
        ok: response.ok 
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('Bulk delete successful:', result);
        
        // Remove the chat items from DOM
        chatItems.forEach(item => item.remove());
        
        // Hide bulk controls
        hideBulkActionControls();
        
        // Update chat history display
        await updateChatHistoryDisplay();
        
        // If current chat was deleted, start a new one
        if (sessionIds.includes(currentChatId)) {
          await startNewChat();
        }
      } else {
        const errorData = await response.json();
        console.error('Bulk delete failed:', { 
          status: response.status, 
          error: errorData,
          responseText: await response.text()
        });
        
        // Provide more specific error messages
        let errorMessage = 'Unknown error';
        if (response.status === 401) {
          errorMessage = 'Authentication failed. Please log in again.';
        } else if (response.status === 403) {
          errorMessage = 'Access denied. You do not have permission to delete these chats.';
        } else if (response.status === 404) {
          errorMessage = 'Some chats were not found or may have already been deleted.';
        } else if (errorData.error) {
          errorMessage = errorData.error;
        }
        
        alert(`Failed to delete chats: ${errorMessage}`);
      }
    } catch (error) {
      console.error('Error deleting chats:', error);
      alert('Failed to delete chats. Please try again.');
    }
    
    // Clean up
    window.pendingBulkDeleteData = null;
  }

  // --- Generate unique chat ID ---
  function generateChatId() {
    return 'chat_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  // --- Format date for history headers ---
  function formatDate(date) {
    return date.toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: date.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
    });
  }

  // --- Debounce utility ---
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }
  const debouncedSave = debounce(saveChatToHistory, 2000);

  // --- Reset input height ---
  function resetInputHeight() {
    if (chatInput) chatInput.style.height = 'auto';
  }

  // Initialize notification chats mapping from existing sessions
  async function initializeNotificationChats() {
    if (!chatHistory) return;
    
    // Look for existing inventory alert chats and map them to products
    try {
      const products = await inventoryNotificationService.fetchInventoryData();
      
      chatHistory.forEach(chat => {
        if (chat.title && chat.title.startsWith('Inventory Alert: ')) {
          const productName = chat.title.replace('Inventory Alert: ', '');
          const matchingProduct = products.find(p => p.name === productName);
          
          if (matchingProduct) {
            notificationChats.set(matchingProduct.id, chat.id);
            console.log(`Mapped notification chat ${chat.id} to product ${matchingProduct.id} (${productName})`);
          }
        }
      });
      
      console.log(`Initialized ${notificationChats.size} notification chat mappings`);
    } catch (error) {
      console.error('Error loading products for notification chat mapping:', error);
    }
  }

  // --- Initialize chat history and sidebar state ---
  async function initializeChatHistory() {
    // First, load all existing sessions
    await updateChatHistoryDisplay();
    
    // Load sessions to see if user has any existing chats
    const sessions = await loadChatSessions();
    chatHistory = sessions; // Make sure chatHistory is set
    
    // Initialize notification chats mapping
    await initializeNotificationChats();

    if (sessions.length > 0) {
      // User has existing chats, load the most recent one
      const latestSession = sessions[0]; // Sessions are ordered by updated_at DESC
      currentChatId = latestSession.id;
      
      // Load messages for the latest session
      const sessionMessages = await loadSessionMessages(latestSession.id);
      
      if (sessionMessages.length > 0) {
        if (welcomeMessage) welcomeMessage.style.display = 'none';
        if (chatMessages) chatMessages.style.display = 'block';
        
        // Display each message without saving (they're already in DB)
        for (const dbMsg of sessionMessages) {
          const sender = dbMsg.message_type === 'user' ? 'user' : 'ai';
          await addMessage(sender, dbMsg.message, false); // false = don't save to DB again
        }
        
        // Update active state
        document.querySelectorAll('.history-item').forEach(item => {
          item.classList.toggle('active', item.dataset.chatId == currentChatId);
        });
      }
    } else {
      // User has no existing chats - don't auto-create one, just show welcome screen
      currentChatId = null;
      if (welcomeMessage) welcomeMessage.style.display = 'block';
      if (chatMessages) chatMessages.style.display = 'none';
    }
    
    // Update layout
    updateChatLayout();
    
    // Handle sidebar state
    const savedCollapsedState = localStorage.getItem('sidebarCollapsed');
    if (savedCollapsedState === 'true' && window.innerWidth > 768) {
      isSidebarCollapsed = true;
      sidebar.classList.add('collapsed');
      chatContainer.classList.add('sidebar-collapsed');
    }
    
    // Start new chat if no active session
    if (!currentChatId) {
      await startNewChat();
    }
    
    // Start inventory notification service if not already started globally
    if (inventoryNotificationService && !inventoryNotificationService.isRunning) {
      inventoryNotificationService.start();
      console.log('Inventory notification service started from chat module');
    } else if (inventoryNotificationService && inventoryNotificationService.isRunning) {
      console.log('Inventory notification service already running globally');
    }
    
    // Add test methods to window for debugging
    if (inventoryNotificationService) {
      window.testNotifications = async function() {
        console.log('Testing notifications...');
        const products = await inventoryNotificationService.fetchInventoryData();
        console.log('Current products:', products);
        
        // Test by simulating a high previous quantity for a low stock product
        const lowStockProduct = products.find(p => Number(p.quantity) <= 10);
        if (lowStockProduct) {
          await inventoryNotificationService.testNotification(lowStockProduct.id, 20);
        } else {
          console.log('No low stock products found to test with');
        }
      };
      
      window.forceInventoryCheck = async function() {
        console.log('Forcing inventory check...');
        await inventoryNotificationService.forceCheck();
      };
      
      window.resetNotificationTracking = function() {
        console.log('Resetting notification tracking...');
        inventoryNotificationService.reset();
      };
    }
  }

  // --- Save chat before unload ---
  window.addEventListener('beforeunload', function() {
    // Stop inventory notification service
    if (inventoryNotificationService) {
      inventoryNotificationService.stop();
    }
    // Messages are now saved to database in real-time
    console.log('Chat session ending - messages saved to database');
  });

  // --- Focus input on load ---
  if (chatInput) chatInput.focus();

  // --- Initialize ---
  initializeChatHistory();

  // --- Add manual notification test (for development/testing) ---
  window.testInventoryNotification = function() {
    if (inventoryNotificationService) {
      inventoryNotificationService.triggerManualCheck();
      console.log('Manual inventory notification check triggered');
    }
  };

  // --- Add function to get notification service status ---
  window.getNotificationStatus = function() {
    if (inventoryNotificationService) {
      return inventoryNotificationService.getStatus();
    }
    return null;
  };

  // --- Add function to force immediate inventory check ---
  window.forceInventoryCheck = async function() {
    if (inventoryNotificationService) {
      console.log('🔄 Forcing immediate inventory check...');
      const notifications = await inventoryNotificationService.forceCheck();
      console.log(`Generated ${notifications.length} notifications`);
      return notifications;
    }
    console.log('❌ Inventory service not available');
    return [];
  };

  // --- Add function to reset notification tracking ---
  window.resetNotificationTracking = function() {
    if (inventoryNotificationService) {
      console.log('🔄 Resetting notification tracking...');
      inventoryNotificationService.reset();
      console.log('✅ Notification tracking reset - will re-establish baselines');
    } else {
      console.log('❌ Inventory service not available');
    }
  };

  // --- Add function to check supplier contact status ---
  window.getSupplierContactStatus = function() {
    if (window.pendingSupplierContact) {
      console.log('📋 Pending supplier contact:', window.pendingSupplierContact);
      return window.pendingSupplierContact;
    } else {
      console.log('✅ No pending supplier contacts');
      return null;
    }
  };

  // --- Add function to clear pending supplier contact ---
  window.clearPendingSupplierContact = function() {
    if (window.pendingSupplierContact) {
      const productName = window.pendingSupplierContact.productName;
      window.pendingSupplierContact = null;
      console.log(`✅ Cleared pending supplier contact for: ${productName}`);
      return true;
    } else {
      console.log('ℹ️ No pending supplier contact to clear');
      return false;
    }
  };

  // --- Add email testing functions ---
  window.testEmailFunction = async function(emailAddress = 'your-email@gmail.com') {
    console.log('🧪 Testing email functionality...');
    console.log(`📧 Sending test email to: ${emailAddress}`);
    
    try {
      // Test sending email to the specified address
      const testSubject = 'Test Email from Chat Module - Inventory System';
      const testMessage = 'This is a test email from the chat module to verify email functionality is working correctly. If you receive this, the email integration is working!';
      
      const result = await sendEmailToUser(emailAddress, testSubject, testMessage, false);
      
      if (result.success) {
        console.log('✅ Email test successful!', result);
        return `Email test completed successfully! Check ${emailAddress} for the test email.`;
      } else {
        console.log('❌ Email test failed:', result);
        return `Email test failed: ${result.error || 'Unknown error'}`;
      }
    } catch (error) {
      console.error('❌ Email test error:', error);
      return `Email test error: ${error.message}`;
    }
  };

  // --- Add function to test supplier email ---
  window.testSupplierEmail = async function(emailAddress = 'supplier-test@gmail.com') {
    console.log('🧪 Testing supplier email functionality...');
    console.log(`📧 Sending test supplier email to: ${emailAddress}`);
    
    try {
      const testSubject = 'Test Supplier Email from Chat Module - Inventory System';
      const testMessage = 'This is a test email to a supplier from the chat module. If you receive this, the supplier email integration is working!';
      
      const result = await sendEmailToSupplier(emailAddress, testSubject, testMessage, false);
      
      if (result.success) {
        console.log('✅ Supplier email test successful!', result);
        return `Supplier email test completed successfully! Check ${emailAddress} for the test email.`;
      } else {
        console.log('❌ Supplier email test failed:', result);
        return `Supplier email test failed: ${result.error || 'Unknown error'}`;
      }
    } catch (error) {
      console.error('❌ Supplier email test error:', error);
      return `Supplier email test error: ${error.message}`;
    }
  };

  // --- Add function to test HTML email ---
  window.testHTMLEmail = async function(emailAddress = 'html-test@gmail.com') {
    console.log('🧪 Testing HTML email functionality...');
    console.log(`📧 Sending test HTML email to: ${emailAddress}`);
    
    try {
      const testSubject = 'Test HTML Email from Chat Module - Inventory System';
      const testHTML = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #333; text-align: center;">🎉 HTML Email Test</h2>
          <div style="background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3 style="color: #0066cc; margin-top: 0;">Test Results</h3>
            <p>If you can see this styled email, the HTML email functionality is working correctly!</p>
            <ul>
              <li>✅ HTML formatting is working</li>
              <li>✅ Styling is applied</li>
              <li>✅ Email integration is functional</li>
            </ul>
          </div>
          <p style="text-align: center; color: #666;">
            This is a test email from your Inventory Management System
          </p>
        </div>
      `;
      
      const result = await sendEmailToUser(emailAddress, testSubject, testHTML, true);
      
      if (result.success) {
        console.log('✅ HTML email test successful!', result);
        return `HTML email test completed successfully! Check ${emailAddress} for the styled test email.`;
      } else {
        console.log('❌ HTML email test failed:', result);
        return `HTML email test failed: ${result.error || 'Unknown error'}`;
      }
    } catch (error) {
      console.error('❌ HTML email test error:', error);
      return `HTML email test error: ${error.message}`;
    }
  };
});

// --- Logout function ---
function logout() {
  showLogoutModal();
}